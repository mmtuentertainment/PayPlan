#!/usr/bin/env python3
"""
GitHub Integration for PayPlan

Fetches PRs, issues, CI status, and review comments from GitHub.
Uses gh CLI for authentication and API access.
"""

import subprocess
import json
import re
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class PullRequest:
    number: int
    title: str
    state: str
    author: str
    created_at: str
    merged_at: Optional[str]
    url: str
    feature_id: Optional[str]
    labels: List[str]
    review_comments: List[Dict]
    ci_status: str


@dataclass
class Issue:
    number: int
    title: str
    state: str
    author: str
    created_at: str
    labels: List[str]
    url: str
    feature_id: Optional[str]


class GitHubIntegration:
    def __init__(self, repo_path: str = "."):
        self.repo_path = Path(repo_path)
        self._check_gh_cli()

    def _check_gh_cli(self):
        """Check if gh CLI is installed and authenticated."""
        try:
            result = subprocess.run(
                ['gh', 'auth', 'status'],
                capture_output=True,
                text=True
            )
            if result.returncode != 0:
                print("⚠️  gh CLI not authenticated. Run: gh auth login")
        except FileNotFoundError:
            print("❌ gh CLI not installed. Install from: https://cli.github.com/")

    def get_feature_prs(self, feature_id: str) -> List[PullRequest]:
        """Get all PRs related to a feature."""
        prs = []

        try:
            # Search PRs by feature ID
            cmd = [
                'gh', 'pr', 'list',
                '--search', feature_id,
                '--state', 'all',
                '--json', 'number,title,state,author,createdAt,mergedAt,url,labels',
                '--limit', '50'
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                pr_data = json.loads(result.stdout)

                for pr in pr_data:
                    # Get review comments
                    comments = self._get_pr_comments(pr['number'])

                    # Get CI status
                    ci_status = self._get_pr_ci_status(pr['number'])

                    prs.append(PullRequest(
                        number=pr['number'],
                        title=pr['title'],
                        state=pr['state'],
                        author=pr['author']['login'],
                        created_at=pr['createdAt'],
                        merged_at=pr.get('mergedAt'),
                        url=pr['url'],
                        feature_id=self._extract_feature_id(pr['title']),
                        labels=[l['name'] for l in pr.get('labels', [])],
                        review_comments=comments,
                        ci_status=ci_status
                    ))

        except Exception as e:
            print(f"⚠️  Error fetching PRs: {e}")

        return prs

    def get_feature_issues(self, feature_id: str) -> List[Issue]:
        """Get all issues related to a feature."""
        issues = []

        try:
            cmd = [
                'gh', 'issue', 'list',
                '--search', feature_id,
                '--state', 'all',
                '--json', 'number,title,state,author,createdAt,labels,url',
                '--limit', '50'
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                issue_data = json.loads(result.stdout)

                for issue in issue_data:
                    issues.append(Issue(
                        number=issue['number'],
                        title=issue['title'],
                        state=issue['state'],
                        author=issue['author']['login'],
                        created_at=issue['createdAt'],
                        labels=[l['name'] for l in issue.get('labels', [])],
                        url=issue['url'],
                        feature_id=self._extract_feature_id(issue['title'])
                    ))

        except Exception as e:
            print(f"⚠️  Error fetching issues: {e}")

        return issues

    def get_pr_details(self, pr_number: int) -> Dict:
        """Get detailed PR information including diffs and checks."""
        details = {}

        try:
            # Get PR details
            cmd = [
                'gh', 'pr', 'view', str(pr_number),
                '--json', 'number,title,body,state,author,createdAt,mergedAt,url,labels,reviews,files'
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                details = json.loads(result.stdout)

                # Add CI checks
                details['ci_checks'] = self._get_pr_checks(pr_number)

                # Add review summary
                details['review_summary'] = self._summarize_reviews(details.get('reviews', []))

        except Exception as e:
            print(f"⚠️  Error fetching PR details: {e}")

        return details

    def get_ci_status(self) -> Dict:
        """Get current CI/CD status for the repo."""
        status = {
            "workflow_runs": [],
            "latest_run": None,
            "success_rate": 0.0
        }

        try:
            # Get recent workflow runs
            cmd = [
                'gh', 'run', 'list',
                '--json', 'databaseId,name,status,conclusion,createdAt,url',
                '--limit', '10'
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                runs = json.loads(result.stdout)
                status['workflow_runs'] = runs

                if runs:
                    status['latest_run'] = runs[0]

                    # Calculate success rate
                    completed = [r for r in runs if r['status'] == 'completed']
                    if completed:
                        successful = [r for r in completed if r['conclusion'] == 'success']
                        status['success_rate'] = len(successful) / len(completed)

        except Exception as e:
            print(f"⚠️  Error fetching CI status: {e}")

        return status

    def get_linear_issues(self, feature_id: str) -> List[Dict]:
        """
        Get Linear issues mentioned in commits/PRs.
        Looks for patterns like MMT-48, PROJ-123, etc.
        """
        linear_issues = []

        # Search git log for Linear issue references
        try:
            cmd = [
                'git', 'log', '--all',
                '--grep', feature_id, '-i',
                '--pretty=format:%H|%s'
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')

                for line in lines:
                    if '|' in line:
                        commit_hash, message = line.split('|', 1)

                        # Extract Linear issue IDs (e.g., MMT-48, PROJ-123)
                        linear_refs = re.findall(r'\b([A-Z]{2,}-\d+)\b', message)

                        for issue_id in linear_refs:
                            if issue_id not in [i['id'] for i in linear_issues]:
                                linear_issues.append({
                                    "id": issue_id,
                                    "commit": commit_hash[:7],
                                    "mentioned_in": message
                                })

        except Exception as e:
            print(f"⚠️  Error finding Linear issues: {e}")

        return linear_issues

    def _get_pr_comments(self, pr_number: int) -> List[Dict]:
        """Get review comments for a PR."""
        comments = []

        try:
            cmd = [
                'gh', 'pr', 'view', str(pr_number),
                '--json', 'reviews'
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                data = json.loads(result.stdout)
                reviews = data.get('reviews', [])

                for review in reviews:
                    comments.append({
                        "author": review['author']['login'],
                        "state": review['state'],
                        "body": review.get('body', '')[:200],  # Truncate
                        "created_at": review['submittedAt']
                    })

        except Exception:
            pass

        return comments

    def _get_pr_ci_status(self, pr_number: int) -> str:
        """Get CI status for a PR."""
        try:
            cmd = [
                'gh', 'pr', 'checks', str(pr_number),
                '--json', 'state,conclusion'
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                checks = json.loads(result.stdout)

                if not checks:
                    return "no_checks"

                # Determine overall status
                if all(c.get('conclusion') == 'success' for c in checks):
                    return "passing"
                elif any(c.get('conclusion') == 'failure' for c in checks):
                    return "failing"
                else:
                    return "pending"

        except Exception:
            pass

        return "unknown"

    def _get_pr_checks(self, pr_number: int) -> List[Dict]:
        """Get detailed CI checks for a PR."""
        checks = []

        try:
            cmd = [
                'gh', 'pr', 'checks', str(pr_number)
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                # Parse output (format: "✓ check-name")
                for line in result.stdout.strip().split('\n'):
                    if line.strip():
                        status = "✓" if "✓" in line else "✗"
                        name = line.replace("✓", "").replace("✗", "").strip()
                        checks.append({
                            "name": name,
                            "status": "success" if status == "✓" else "failure"
                        })

        except Exception:
            pass

        return checks

    def _summarize_reviews(self, reviews: List[Dict]) -> Dict:
        """Summarize PR reviews."""
        summary = {
            "total": len(reviews),
            "approved": 0,
            "changes_requested": 0,
            "commented": 0
        }

        for review in reviews:
            state = review.get('state', '').upper()
            if state == 'APPROVED':
                summary['approved'] += 1
            elif state == 'CHANGES_REQUESTED':
                summary['changes_requested'] += 1
            elif state == 'COMMENTED':
                summary['commented'] += 1

        return summary

    def _extract_feature_id(self, text: str) -> Optional[str]:
        """Extract feature ID from text (e.g., "feat: Feature 019 - ...")."""
        match = re.search(r'\b(0\d{2})-[\w-]+|\bFeature (\d{3})\b', text, re.IGNORECASE)
        if match:
            return match.group(1) or match.group(2)
        return None

    def generate_report(
        self,
        feature_id: str,
        output_format: str = "markdown"
    ) -> str:
        """Generate comprehensive GitHub integration report."""
        print(f"🔍 Fetching GitHub data for {feature_id}...")

        prs = self.get_feature_prs(feature_id)
        issues = self.get_feature_issues(feature_id)
        linear_issues = self.get_linear_issues(feature_id)
        ci_status = self.get_ci_status()

        if output_format == "json":
            return json.dumps({
                "pull_requests": [asdict(pr) for pr in prs],
                "issues": [asdict(issue) for issue in issues],
                "linear_issues": linear_issues,
                "ci_status": ci_status
            }, indent=2, default=str)

        # Markdown format
        lines = [f"# GitHub Integration Report: {feature_id}\n\n"]

        # Pull Requests
        if prs:
            lines.append(f"## Pull Requests ({len(prs)})\n\n")
            for pr in prs:
                status_emoji = "✅" if pr.state == "MERGED" else "🔄" if pr.state == "OPEN" else "❌"
                ci_emoji = "✅" if pr.ci_status == "passing" else "❌" if pr.ci_status == "failing" else "⏳"

                lines.append(f"### {status_emoji} #{pr.number}: {pr.title}\n")
                lines.append(f"- **Author**: {pr.author}\n")
                lines.append(f"- **State**: {pr.state}\n")
                lines.append(f"- **CI**: {ci_emoji} {pr.ci_status}\n")
                lines.append(f"- **URL**: {pr.url}\n")

                if pr.labels:
                    lines.append(f"- **Labels**: {', '.join(pr.labels)}\n")

                if pr.review_comments:
                    lines.append(f"- **Reviews**: {len(pr.review_comments)}\n")

                lines.append("\n")

        # Issues
        if issues:
            lines.append(f"## Issues ({len(issues)})\n\n")
            for issue in issues:
                status_emoji = "✅" if issue.state == "CLOSED" else "🔄"

                lines.append(f"### {status_emoji} #{issue.number}: {issue.title}\n")
                lines.append(f"- **Author**: {issue.author}\n")
                lines.append(f"- **State**: {issue.state}\n")
                lines.append(f"- **URL**: {issue.url}\n")

                if issue.labels:
                    lines.append(f"- **Labels**: {', '.join(issue.labels)}\n")

                lines.append("\n")

        # Linear Issues
        if linear_issues:
            lines.append(f"## Linear Issues ({len(linear_issues)})\n\n")
            for linear in linear_issues:
                lines.append(f"- **{linear['id']}** (commit {linear['commit']})\n")
                lines.append(f"  - Mentioned in: {linear['mentioned_in'][:100]}...\n\n")

        # CI Status
        if ci_status['latest_run']:
            lines.append("## CI/CD Status\n\n")
            latest = ci_status['latest_run']
            lines.append(f"- **Latest Run**: {latest['name']} ({latest['status']})\n")
            lines.append(f"- **Success Rate**: {ci_status['success_rate']:.1%} (last 10 runs)\n")
            lines.append(f"- **URL**: {latest['url']}\n\n")

        return ''.join(lines)


def main():
    import argparse

    parser = argparse.ArgumentParser(description="GitHub integration for PayPlan")
    parser.add_argument('feature_id', help='Feature ID (e.g., 019-pii-pattern-refinement)')
    parser.add_argument('--repo', default='.', help='Repository path')
    parser.add_argument('--prs-only', action='store_true', help='Show only PRs')
    parser.add_argument('--issues-only', action='store_true', help='Show only issues')
    parser.add_argument('--ci-status', action='store_true', help='Show CI status')
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown')
    parser.add_argument('--output', help='Output file path')

    args = parser.parse_args()

    integration = GitHubIntegration(args.repo)

    output = integration.generate_report(args.feature_id, args.format)

    if args.output:
        with open(args.output, 'w') as f:
            f.write(output)
        print(f"✅ Report written to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
