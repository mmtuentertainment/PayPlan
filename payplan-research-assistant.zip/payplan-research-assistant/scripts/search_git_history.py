#!/usr/bin/env python3
"""
Git History Search for PayPlan

Analyzes git commits, PRs, and feature progression to understand
the evolution of the codebase and implementation patterns.
"""

import subprocess
import re
import json
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class Commit:
    hash: str
    short_hash: str
    author: str
    date: str
    message: str
    files_changed: int
    insertions: int
    deletions: int


@dataclass
class FeatureHistory:
    feature_id: str
    commits: List[Commit]
    pr_numbers: List[str]
    first_commit_date: Optional[str]
    last_commit_date: Optional[str]
    total_commits: int


class GitHistorySearcher:
    def __init__(self, repo_path: str = "."):
        self.repo_path = Path(repo_path)

    def search_feature_history(self, feature_id: str) -> FeatureHistory:
        """Get complete git history for a feature."""
        commits = self._get_feature_commits(feature_id)
        pr_numbers = self._extract_pr_numbers(commits)

        first_date = commits[0].date if commits else None
        last_date = commits[-1].date if commits else None

        return FeatureHistory(
            feature_id=feature_id,
            commits=commits,
            pr_numbers=pr_numbers,
            first_commit_date=first_date,
            last_commit_date=last_date,
            total_commits=len(commits)
        )

    def _get_feature_commits(self, feature_id: str) -> List[Commit]:
        """Get all commits related to a feature."""
        try:
            # Search for commits mentioning the feature ID
            cmd = [
                'git', 'log', '--all',
                '--grep', feature_id, '-i',
                '--pretty=format:%H|%h|%an|%ai|%s',
                '--shortstat'
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                return []

            commits = []
            lines = result.stdout.strip().split('\n')

            i = 0
            while i < len(lines):
                if '|' in lines[i]:
                    parts = lines[i].split('|')
                    if len(parts) >= 5:
                        commit_hash, short_hash, author, date, message = parts[0], parts[1], parts[2], parts[3], '|'.join(parts[4:])

                        # Parse stats from next line if available
                        files_changed, insertions, deletions = 0, 0, 0
                        if i + 1 < len(lines) and ('file' in lines[i + 1] or 'insertion' in lines[i + 1]):
                            stats_line = lines[i + 1]
                            files_match = re.search(r'(\d+) file', stats_line)
                            insert_match = re.search(r'(\d+) insertion', stats_line)
                            delete_match = re.search(r'(\d+) deletion', stats_line)

                            if files_match:
                                files_changed = int(files_match.group(1))
                            if insert_match:
                                insertions = int(insert_match.group(1))
                            if delete_match:
                                deletions = int(delete_match.group(1))

                            i += 1  # Skip stats line

                        commits.append(Commit(
                            hash=commit_hash,
                            short_hash=short_hash,
                            author=author,
                            date=date,
                            message=message.strip(),
                            files_changed=files_changed,
                            insertions=insertions,
                            deletions=deletions
                        ))

                i += 1

            return commits

        except Exception as e:
            print(f"⚠️  Error getting commits for {feature_id}: {e}")
            return []

    def _extract_pr_numbers(self, commits: List[Commit]) -> List[str]:
        """Extract PR numbers from commit messages."""
        pr_numbers = set()

        for commit in commits:
            # Look for PR references like (#123) or PR #123
            matches = re.findall(r'#(\d+)', commit.message)
            pr_numbers.update(matches)

        return sorted(pr_numbers)

    def search_commits_by_pattern(
        self,
        pattern: str,
        max_results: int = 50
    ) -> List[Commit]:
        """Search commits by pattern in message."""
        try:
            cmd = [
                'git', 'log', '--all',
                '--grep', pattern, '-i',
                '--pretty=format:%H|%h|%an|%ai|%s',
                '--shortstat',
                f'-{max_results}'
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                return []

            commits = []
            lines = result.stdout.strip().split('\n')

            i = 0
            while i < len(lines):
                if '|' in lines[i]:
                    parts = lines[i].split('|')
                    if len(parts) >= 5:
                        commit_hash, short_hash, author, date, message = parts[0], parts[1], parts[2], parts[3], '|'.join(parts[4:])

                        files_changed, insertions, deletions = 0, 0, 0
                        if i + 1 < len(lines) and ('file' in lines[i + 1] or 'insertion' in lines[i + 1]):
                            stats_line = lines[i + 1]
                            files_match = re.search(r'(\d+) file', stats_line)
                            insert_match = re.search(r'(\d+) insertion', stats_line)
                            delete_match = re.search(r'(\d+) deletion', stats_line)

                            if files_match:
                                files_changed = int(files_match.group(1))
                            if insert_match:
                                insertions = int(insert_match.group(1))
                            if delete_match:
                                deletions = int(delete_match.group(1))

                            i += 1

                        commits.append(Commit(
                            hash=commit_hash,
                            short_hash=short_hash,
                            author=author,
                            date=date,
                            message=message.strip(),
                            files_changed=files_changed,
                            insertions=insertions,
                            deletions=deletions
                        ))

                i += 1

            return commits

        except Exception as e:
            print(f"⚠️  Error searching commits: {e}")
            return []

    def get_file_history(self, file_path: str, max_results: int = 20) -> List[Commit]:
        """Get commit history for a specific file."""
        try:
            cmd = [
                'git', 'log', '--all',
                '--pretty=format:%H|%h|%an|%ai|%s',
                '--shortstat',
                f'-{max_results}',
                '--', file_path
            ]

            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                return []

            commits = []
            lines = result.stdout.strip().split('\n')

            i = 0
            while i < len(lines):
                if '|' in lines[i]:
                    parts = lines[i].split('|')
                    if len(parts) >= 5:
                        commit_hash, short_hash, author, date, message = parts[0], parts[1], parts[2], parts[3], '|'.join(parts[4:])

                        files_changed, insertions, deletions = 0, 0, 0
                        if i + 1 < len(lines) and ('file' in lines[i + 1] or 'insertion' in lines[i + 1]):
                            stats_line = lines[i + 1]
                            files_match = re.search(r'(\d+) file', stats_line)
                            insert_match = re.search(r'(\d+) insertion', stats_line)
                            delete_match = re.search(r'(\d+) deletion', stats_line)

                            if files_match:
                                files_changed = int(files_match.group(1))
                            if insert_match:
                                insertions = int(insert_match.group(1))
                            if delete_match:
                                deletions = int(delete_match.group(1))

                            i += 1

                        commits.append(Commit(
                            hash=commit_hash,
                            short_hash=short_hash,
                            author=author,
                            date=date,
                            message=message.strip(),
                            files_changed=files_changed,
                            insertions=insertions,
                            deletions=deletions
                        ))

                i += 1

            return commits

        except Exception as e:
            print(f"⚠️  Error getting file history: {e}")
            return []

    def generate_report(
        self,
        target: str,
        search_type: str = "feature",
        output_format: str = "markdown"
    ) -> str:
        """Generate history report."""
        if search_type == "feature":
            history = self.search_feature_history(target)

            if output_format == "json":
                return json.dumps(asdict(history), indent=2)

            lines = [f"# Git History: {history.feature_id}\n\n"]
            lines.append(f"**Total Commits**: {history.total_commits}\n")

            if history.pr_numbers:
                lines.append(f"**Pull Requests**: {', '.join(f'#{pr}' for pr in history.pr_numbers)}\n")

            if history.first_commit_date:
                lines.append(f"**First Commit**: {history.first_commit_date}\n")
            if history.last_commit_date:
                lines.append(f"**Last Commit**: {history.last_commit_date}\n")

            lines.append("\n## Commits\n\n")

            for commit in history.commits:
                lines.append(f"### {commit.short_hash} - {commit.author}\n")
                lines.append(f"**Date**: {commit.date}\n\n")
                lines.append(f"**Message**: {commit.message}\n\n")
                lines.append(f"**Changes**: {commit.files_changed} files, ")
                lines.append(f"+{commit.insertions} / -{commit.deletions}\n\n")
                lines.append("---\n\n")

            return ''.join(lines)

        elif search_type == "pattern":
            commits = self.search_commits_by_pattern(target)

            if output_format == "json":
                return json.dumps([asdict(c) for c in commits], indent=2)

            lines = [f"# Commits Matching: {target}\n\n"]
            lines.append(f"**Total Results**: {len(commits)}\n\n")

            for commit in commits:
                lines.append(f"### {commit.short_hash} - {commit.author}\n")
                lines.append(f"**Date**: {commit.date}\n\n")
                lines.append(f"**Message**: {commit.message}\n\n")
                lines.append("---\n\n")

            return ''.join(lines)

        return ""


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Search PayPlan git history")
    parser.add_argument('target', help='Feature ID, pattern, or file path to search')
    parser.add_argument('--type', choices=['feature', 'pattern', 'file'], default='feature',
                        help='Type of search')
    parser.add_argument('--repo', default='.', help='Repository path')
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown')
    parser.add_argument('--output', help='Output file path')

    args = parser.parse_args()

    searcher = GitHistorySearcher(args.repo)

    print(f"🔍 Searching git history for: {args.target}")

    output = searcher.generate_report(args.target, args.type, args.format)

    if args.output:
        with open(args.output, 'w') as f:
            f.write(output)
        print(f"✅ Report written to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
