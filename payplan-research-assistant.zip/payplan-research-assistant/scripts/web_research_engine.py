#!/usr/bin/env python3
"""
Web Research Engine - Multi-format data fetching and analysis

Provides AI agent with structured research capabilities:
1. Competitor feature analysis (web scraping)
2. Industry trend analysis (search + scrape)
3. API documentation fetching
4. User review mining
5. Tech blog analysis

NOTE: This module outputs research tasks that the AI agent should execute
using available MCP tools (Puppeteer, WebFetch, WebSearch, etc.)

Usage:
    python scripts/web_research_engine.py --research-topic "budget app features"
    python scripts/web_research_engine.py --competitor-analysis "mint.com,ynab.com"
    python scripts/web_research_engine.py --user-reviews "payplan competitors"
"""

import argparse
import json
from typing import List, Dict, Any
from dataclasses import dataclass, asdict


@dataclass
class ResearchTask:
    """Represents a research task for the AI agent to execute"""
    task_type: str  # competitor_analysis, trend_search, doc_fetch, review_mining
    description: str
    tool_required: str  # puppeteer, web_search, web_fetch
    target_url: str = None
    search_query: str = None
    css_selectors: Dict[str, str] = None
    expected_format: str = "markdown"  # markdown, json, html_table, csv
    priority: int = 5  # 1-10, higher = more important


@dataclass
class ResearchPlan:
    """Complete research plan with multiple tasks"""
    topic: str
    tasks: List[ResearchTask]
    expected_insights: List[str]


class WebResearchEngine:
    """Generate structured research plans for AI agent execution"""

    def __init__(self):
        self.competitor_sites = {
            "mint": "https://mint.intuit.com/features",
            "ynab": "https://www.ynab.com/features",
            "pocketguard": "https://pocketguard.com/features",
            "copilot": "https://copilot.money/features",
            "monarchmoney": "https://www.monarchmoney.com/features"
        }

    def create_competitor_analysis_plan(self, competitors: List[str] = None) -> ResearchPlan:
        """
        Create research plan for competitor feature analysis

        AI agent should:
        1. Use Puppeteer to navigate to competitor sites
        2. Extract feature lists using CSS selectors
        3. Screenshot feature pages for visual reference
        4. Compare with PayPlan capabilities
        """
        if competitors is None:
            competitors = ["mint", "ynab", "pocketguard"]

        tasks = []

        for competitor in competitors:
            if competitor.lower() not in self.competitor_sites:
                continue

            url = self.competitor_sites[competitor.lower()]

            # Task 1: Navigate and screenshot
            tasks.append(ResearchTask(
                task_type="competitor_screenshot",
                description=f"Screenshot {competitor} features page for visual reference",
                tool_required="mcp__puppeteer__puppeteer_screenshot",
                target_url=url,
                expected_format="image/png",
                priority=7
            ))

            # Task 2: Extract feature list
            tasks.append(ResearchTask(
                task_type="competitor_features",
                description=f"Extract feature list from {competitor} website",
                tool_required="mcp__web-browser__browse_webpage",
                target_url=url,
                css_selectors={
                    "features": "h2, h3, .feature-title, .feature-name",
                    "descriptions": "p, .feature-description"
                },
                expected_format="markdown",
                priority=10
            ))

            # Task 3: Extract pricing (if available)
            pricing_url = url.replace("/features", "/pricing")
            tasks.append(ResearchTask(
                task_type="competitor_pricing",
                description=f"Extract {competitor} pricing tiers",
                tool_required="mcp__web-browser__browse_webpage",
                target_url=pricing_url,
                css_selectors={
                    "tiers": ".pricing-tier, .plan",
                    "prices": ".price, .cost"
                },
                expected_format="json",
                priority=6
            ))

        return ResearchPlan(
            topic=f"Competitor Analysis: {', '.join(competitors)}",
            tasks=tasks,
            expected_insights=[
                "Feature gaps (what competitors have that PayPlan doesn't)",
                "Feature advantages (what PayPlan has that competitors don't)",
                "Pricing models for premium features",
                "UI/UX patterns to consider",
                "Marketing language for feature descriptions"
            ]
        )

    def create_industry_trend_plan(self, topic: str) -> ResearchPlan:
        """
        Create research plan for industry trend analysis

        AI agent should:
        1. WebSearch for trend articles
        2. Fetch top results with WebFetch
        3. Extract key insights
        4. Identify emerging patterns
        """
        tasks = []

        search_queries = [
            f"{topic} 2025 trends",
            f"best {topic} features",
            f"{topic} user requests",
            f"most wanted {topic} capabilities"
        ]

        for idx, query in enumerate(search_queries):
            # Task 1: Web search
            tasks.append(ResearchTask(
                task_type="trend_search",
                description=f"Search for: {query}",
                tool_required="WebSearch",
                search_query=query,
                expected_format="search_results",
                priority=9
            ))

            # Task 2: Fetch top 3 results
            tasks.append(ResearchTask(
                task_type="trend_fetch",
                description=f"Fetch and analyze top 3 results for: {query}",
                tool_required="WebFetch",
                search_query=query,  # AI agent will extract URLs from search results
                expected_format="markdown",
                priority=8
            ))

        # Task 3: Check Product Hunt
        tasks.append(ResearchTask(
            task_type="product_hunt_trends",
            description=f"Search Product Hunt for {topic} launches",
            tool_required="mcp__fetch__fetch",
            target_url=f"https://www.producthunt.com/search?q={topic.replace(' ', '+')}",
            expected_format="html",
            priority=7
        ))

        return ResearchPlan(
            topic=f"Industry Trends: {topic}",
            tasks=tasks,
            expected_insights=[
                "Emerging feature trends in the industry",
                "User pain points mentioned in articles",
                "New technologies being adopted",
                "Best practices and patterns",
                "Market opportunities"
            ]
        )

    def create_user_review_mining_plan(self, app_names: List[str]) -> ResearchPlan:
        """
        Create plan to mine user reviews for feature requests

        AI agent should:
        1. Search for app store reviews
        2. Extract common complaints
        3. Identify most-requested features
        4. Find usability issues
        """
        tasks = []

        for app in app_names:
            # Task 1: Search for reviews
            tasks.append(ResearchTask(
                task_type="review_search",
                description=f"Search for {app} user reviews and complaints",
                tool_required="WebSearch",
                search_query=f"{app} app review complaints missing features",
                expected_format="search_results",
                priority=8
            ))

            # Task 2: Reddit discussions
            tasks.append(ResearchTask(
                task_type="reddit_mining",
                description=f"Search Reddit for {app} feature requests",
                tool_required="WebSearch",
                search_query=f"site:reddit.com {app} feature request OR wish list",
                expected_format="search_results",
                priority=9
            ))

        return ResearchPlan(
            topic=f"User Review Mining: {', '.join(app_names)}",
            tasks=tasks,
            expected_insights=[
                "Most frequently requested features",
                "Common user pain points",
                "Usability issues to avoid",
                "Features users love (learn from)",
                "Deal-breakers (must-have features)"
            ]
        )

    def create_tech_docs_research_plan(self, technologies: List[str]) -> ResearchPlan:
        """
        Create plan to research technical documentation

        AI agent should:
        1. Fetch official docs
        2. Extract key features and capabilities
        3. Identify integration patterns
        4. Find pricing/limits
        """
        tasks = []

        doc_urls = {
            "supabase": "https://supabase.com/docs",
            "react": "https://react.dev/reference/react",
            "vercel": "https://vercel.com/docs",
            "tailwind": "https://tailwindcss.com/docs"
        }

        for tech in technologies:
            tech_lower = tech.lower()
            if tech_lower in doc_urls:
                url = doc_urls[tech_lower]

                tasks.append(ResearchTask(
                    task_type="tech_docs",
                    description=f"Fetch {tech} documentation highlights",
                    tool_required="mcp__fetch__fetch",
                    target_url=url,
                    expected_format="markdown",
                    priority=7
                ))

                # Pricing page if exists
                pricing_url = url.replace("/docs", "/pricing")
                tasks.append(ResearchTask(
                    task_type="tech_pricing",
                    description=f"Fetch {tech} pricing and limits",
                    tool_required="mcp__fetch__fetch",
                    target_url=pricing_url,
                    expected_format="markdown",
                    priority=6
                ))

        return ResearchPlan(
            topic=f"Technical Documentation: {', '.join(technologies)}",
            tasks=tasks,
            expected_insights=[
                "Key capabilities and features",
                "Integration requirements",
                "Pricing tiers and limits",
                "Best practices and patterns",
                "Breaking changes and migration guides"
            ]
        )


def format_research_plan_markdown(plan: ResearchPlan) -> str:
    """Format research plan as markdown for AI agent execution"""
    output = [f"# 🔬 Research Plan: {plan.topic}\n"]
    output.append(f"**Total Tasks**: {len(plan.tasks)}\n")
    output.append("**Expected Insights**:\n")
    for insight in plan.expected_insights:
        output.append(f"- {insight}\n")
    output.append("\n---\n\n")

    # Group tasks by priority
    sorted_tasks = sorted(plan.tasks, key=lambda t: t.priority, reverse=True)

    for idx, task in enumerate(sorted_tasks, 1):
        output.append(f"## Task {idx}: {task.description}\n")
        output.append(f"**Type**: {task.task_type}\n")
        output.append(f"**Tool Required**: `{task.tool_required}`\n")
        output.append(f"**Priority**: {task.priority}/10\n")

        if task.target_url:
            output.append(f"**URL**: {task.target_url}\n")
        if task.search_query:
            output.append(f"**Search**: `{task.search_query}`\n")
        if task.css_selectors:
            output.append(f"**Selectors**: ```json\n{json.dumps(task.css_selectors, indent=2)}\n```\n")

        output.append(f"**Expected Format**: {task.expected_format}\n")
        output.append("\n---\n\n")

    return "".join(output)


def main():
    parser = argparse.ArgumentParser(description="Web Research Engine - Generate research plans")
    parser.add_argument('--competitor-analysis', type=str,
                       help='Comma-separated competitor names (mint,ynab,pocketguard)')
    parser.add_argument('--industry-trends', type=str,
                       help='Topic for industry trend research')
    parser.add_argument('--user-reviews', type=str,
                       help='Comma-separated app names for review mining')
    parser.add_argument('--tech-docs', type=str,
                       help='Comma-separated technologies to research')
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown')
    parser.add_argument('--output', type=str, help='Output file (default: stdout)')

    args = parser.parse_args()

    engine = WebResearchEngine()
    plans = []

    if args.competitor_analysis:
        competitors = [c.strip() for c in args.competitor_analysis.split(',')]
        plans.append(engine.create_competitor_analysis_plan(competitors))

    if args.industry_trends:
        plans.append(engine.create_industry_trend_plan(args.industry_trends))

    if args.user_reviews:
        apps = [a.strip() for a in args.user_reviews.split(',')]
        plans.append(engine.create_user_review_mining_plan(apps))

    if args.tech_docs:
        techs = [t.strip() for t in args.tech_docs.split(',')]
        plans.append(engine.create_tech_docs_research_plan(techs))

    # Format output
    if args.format == 'json':
        output = json.dumps([asdict(plan) for plan in plans], indent=2)
    else:
        output = "\n\n".join([format_research_plan_markdown(plan) for plan in plans])

    # Write output
    if args.output:
        with open(args.output, 'w') as f:
            f.write(output)
        print(f"✅ Research plan written to {args.output}")
    else:
        print(output)


if __name__ == '__main__':
    main()
