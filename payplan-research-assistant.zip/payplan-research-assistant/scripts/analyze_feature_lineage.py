#!/usr/bin/env python3
"""
Feature Lineage Analyzer for PayPlan

Traces feature dependencies, evolution, and relationships across the codebase.
Provides insights into which features built on which, enabling better context
for future development.
"""

import os
import re
import json
import subprocess
from pathlib import Path
from typing import Dict, List, Set, Optional
from dataclasses import dataclass, asdict


@dataclass
class Feature:
    id: str
    name: str
    path: Path
    artifacts: List[str]
    dependencies: Set[str]
    dependent_features: Set[str]
    git_commits: List[str]
    status: str  # "completed", "in_progress", "planned"


class FeatureLineageAnalyzer:
    def __init__(self, repo_path: str = "."):
        self.repo_path = Path(repo_path)
        self.specs_dir = self.repo_path / "specs"
        self.features: Dict[str, Feature] = {}

    def discover_features(self) -> List[Feature]:
        """Discover all features in the specs directory."""
        features = []

        if not self.specs_dir.exists():
            print(f"❌ Specs directory not found: {self.specs_dir}")
            return features

        for feature_dir in sorted(self.specs_dir.iterdir()):
            if not feature_dir.is_dir() or feature_dir.name.startswith('.'):
                continue

            # Check if it's a valid feature (has spec.md or feature-spec.md)
            spec_file = feature_dir / "spec.md"
            alt_spec_file = feature_dir / "feature-spec.md"

            if not (spec_file.exists() or alt_spec_file.exists()):
                continue

            feature = self._analyze_feature(feature_dir)
            features.append(feature)
            self.features[feature.id] = feature

        return features

    def _analyze_feature(self, feature_dir: Path) -> Feature:
        """Analyze a single feature directory."""
        feature_id = feature_dir.name

        # Discover artifacts
        artifacts = []
        common_artifacts = [
            "spec.md", "feature-spec.md", "plan.md", "tasks.md",
            "data-model.md", "research.md", "quickstart.md"
        ]

        for artifact in common_artifacts:
            if (feature_dir / artifact).exists():
                artifacts.append(artifact)

        # Check for contracts and checklists subdirectories
        if (feature_dir / "contracts").exists():
            contracts = list((feature_dir / "contracts").glob("*.md"))
            artifacts.extend([f"contracts/{c.name}" for c in contracts])

        if (feature_dir / "checklists").exists():
            checklists = list((feature_dir / "checklists").glob("*.md"))
            artifacts.extend([f"checklists/{c.name}" for c in checklists])

        # Extract dependencies from spec.md
        dependencies = self._extract_dependencies(feature_dir)

        # Get git commits for this feature
        git_commits = self._get_feature_commits(feature_id)

        # Determine status
        status = self._determine_status(feature_dir, git_commits)

        # Extract feature name from spec
        name = self._extract_feature_name(feature_dir)

        return Feature(
            id=feature_id,
            name=name,
            path=feature_dir,
            artifacts=artifacts,
            dependencies=dependencies,
            dependent_features=set(),
            git_commits=git_commits,
            status=status
        )

    def _extract_dependencies(self, feature_dir: Path) -> Set[str]:
        """Extract feature dependencies from spec.md."""
        dependencies = set()
        spec_file = feature_dir / "spec.md"
        alt_spec_file = feature_dir / "feature-spec.md"

        spec_path = spec_file if spec_file.exists() else alt_spec_file
        if not spec_path.exists():
            return dependencies

        with open(spec_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        # Look for dependency patterns
        # Pattern 1: "## Dependencies" section
        dep_section_match = re.search(r'## Dependencies\s*\n(.*?)(?=\n##|\Z)', content, re.DOTALL)
        if dep_section_match:
            dep_section = dep_section_match.group(1)
            # Extract feature IDs (format: 000-feature-name)
            feature_refs = re.findall(r'\b(\d{3}-[\w-]+)\b', dep_section)
            dependencies.update(feature_refs)

        # Pattern 2: References to other features in text
        feature_refs = re.findall(r'[Ff]eature (\d{3}(?:-[\w-]+)?)', content)
        dependencies.update(feature_refs)

        return dependencies

    def _get_feature_commits(self, feature_id: str) -> List[str]:
        """Get git commits related to this feature."""
        try:
            # Search for commits mentioning the feature ID
            cmd = [
                'git', 'log', '--all', '--oneline',
                '--grep', feature_id, '-i'
            ]
            result = subprocess.run(
                cmd,
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                commits = [line.strip() for line in result.stdout.strip().split('\n') if line.strip()]
                return commits[:10]  # Limit to 10 most recent
        except Exception as e:
            print(f"⚠️  Could not get git commits for {feature_id}: {e}")

        return []

    def _determine_status(self, feature_dir: Path, git_commits: List[str]) -> str:
        """Determine feature status."""
        # Check for completion markers
        completion_markers = [
            "COMPLETE.md", "PHASE4_COMPLETE.md", "DONE.md"
        ]

        for marker in completion_markers:
            if (feature_dir / marker).exists():
                return "completed"

        # If has commits and tasks.md exists, likely in progress
        if git_commits and (feature_dir / "tasks.md").exists():
            return "in_progress"

        # If no commits but has spec, likely planned
        if not git_commits:
            return "planned"

        return "completed"  # Default if has commits

    def _extract_feature_name(self, feature_dir: Path) -> str:
        """Extract human-readable feature name from spec."""
        spec_file = feature_dir / "spec.md"
        alt_spec_file = feature_dir / "feature-spec.md"

        spec_path = spec_file if spec_file.exists() else alt_spec_file
        if not spec_path.exists():
            return feature_dir.name

        with open(spec_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                # Look for "# Feature Specification: Name"
                match = re.match(r'^#\s+(?:Feature Specification:\s*)?(.+)', line)
                if match:
                    return match.group(1).strip()

        return feature_dir.name

    def build_dependency_graph(self) -> None:
        """Build reverse dependencies (which features depend on this one)."""
        for feature_id, feature in self.features.items():
            for dep_id in feature.dependencies:
                if dep_id in self.features:
                    self.features[dep_id].dependent_features.add(feature_id)

    def get_feature_lineage(self, feature_id: str) -> Dict:
        """Get complete lineage for a feature (ancestors and descendants)."""
        if feature_id not in self.features:
            return {"error": f"Feature {feature_id} not found"}

        feature = self.features[feature_id]

        # Get ancestors (recursive dependencies)
        ancestors = self._get_ancestors(feature_id)

        # Get descendants (features that depend on this one)
        descendants = self._get_descendants(feature_id)

        return {
            "feature": asdict(feature),
            "ancestors": [asdict(self.features[fid]) for fid in sorted(ancestors)],
            "descendants": [asdict(self.features[fid]) for fid in sorted(descendants)]
        }

    def _get_ancestors(self, feature_id: str, visited: Optional[Set[str]] = None) -> Set[str]:
        """Recursively get all ancestor features."""
        if visited is None:
            visited = set()

        if feature_id not in self.features or feature_id in visited:
            return visited

        visited.add(feature_id)
        feature = self.features[feature_id]

        for dep_id in feature.dependencies:
            if dep_id in self.features:
                self._get_ancestors(dep_id, visited)

        visited.discard(feature_id)  # Don't include self
        return visited

    def _get_descendants(self, feature_id: str, visited: Optional[Set[str]] = None) -> Set[str]:
        """Recursively get all descendant features."""
        if visited is None:
            visited = set()

        if feature_id not in self.features or feature_id in visited:
            return visited

        visited.add(feature_id)
        feature = self.features[feature_id]

        for dep_id in feature.dependent_features:
            if dep_id in self.features:
                self._get_descendants(dep_id, visited)

        visited.discard(feature_id)  # Don't include self
        return visited

    def generate_report(self, output_format: str = "markdown") -> str:
        """Generate a comprehensive lineage report."""
        if output_format == "json":
            report = {
                "total_features": len(self.features),
                "features": {fid: asdict(f) for fid, f in self.features.items()}
            }
            return json.dumps(report, indent=2, default=str)

        # Markdown format
        lines = ["# PayPlan Feature Lineage Report\n"]
        lines.append(f"**Total Features**: {len(self.features)}\n")

        # Group by status
        by_status = {"completed": [], "in_progress": [], "planned": []}
        for feature in self.features.values():
            by_status[feature.status].append(feature)

        for status in ["completed", "in_progress", "planned"]:
            features = sorted(by_status[status], key=lambda f: f.id)
            if features:
                lines.append(f"\n## {status.replace('_', ' ').title()} ({len(features)})\n")
                for feature in features:
                    lines.append(f"### {feature.id}: {feature.name}\n")
                    lines.append(f"- **Path**: `{feature.path.relative_to(self.repo_path)}`\n")
                    lines.append(f"- **Artifacts**: {', '.join(feature.artifacts)}\n")

                    if feature.dependencies:
                        deps = ', '.join(f'`{d}`' for d in sorted(feature.dependencies))
                        lines.append(f"- **Dependencies**: {deps}\n")

                    if feature.dependent_features:
                        deps = ', '.join(f'`{d}`' for d in sorted(feature.dependent_features))
                        lines.append(f"- **Used By**: {deps}\n")

                    if feature.git_commits:
                        lines.append(f"- **Recent Commits**: {len(feature.git_commits)}\n")
                        for commit in feature.git_commits[:3]:
                            lines.append(f"  - `{commit}`\n")

                    lines.append("\n")

        return ''.join(lines)


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Analyze PayPlan feature lineage")
    parser.add_argument('--repo', default='.', help='Repository path')
    parser.add_argument('--feature', help='Specific feature to analyze')
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown')
    parser.add_argument('--output', help='Output file path')

    args = parser.parse_args()

    analyzer = FeatureLineageAnalyzer(args.repo)

    print("🔍 Discovering features...")
    features = analyzer.discover_features()
    print(f"✅ Found {len(features)} features")

    print("🔗 Building dependency graph...")
    analyzer.build_dependency_graph()
    print("✅ Dependency graph built")

    if args.feature:
        # Analyze specific feature
        lineage = analyzer.get_feature_lineage(args.feature)
        output = json.dumps(lineage, indent=2, default=str)
    else:
        # Generate full report
        output = analyzer.generate_report(args.format)

    if args.output:
        with open(args.output, 'w') as f:
            f.write(output)
        print(f"✅ Report written to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
