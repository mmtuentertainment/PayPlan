#!/usr/bin/env python3
"""
Code Pattern Finder for PayPlan

Searches for architectural patterns, conventions, and best practices across
the codebase to help understand how to implement new features consistently.
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, List, Set
from dataclasses import dataclass, asdict
from collections import defaultdict


@dataclass
class PatternMatch:
    file: str
    line_number: int
    context: str
    pattern_type: str


class CodePatternFinder:
    def __init__(self, repo_path: str = "."):
        self.repo_path = Path(repo_path)

        # Define architectural patterns to search for
        self.patterns = {
            # React patterns
            "react_context": r"(createContext|useContext)\s*\(",
            "react_hooks": r"(useState|useEffect|useCallback|useMemo|useRef)\s*\(",
            "custom_hooks": r"export\s+(?:function|const)\s+(use[A-Z]\w+)",

            # Storage patterns
            "localstorage": r"localStorage\.(getItem|setItem|removeItem)",
            "archive_storage": r"(ArchiveStorage|archiveStorage)",

            # Validation patterns
            "zod_schema": r"z\.(object|string|number|boolean|array|enum)",
            "validation_error": r"(ValidationError|ZodError)",

            # Error handling patterns
            "error_boundary": r"(ErrorBoundary|componentDidCatch)",
            "try_catch": r"try\s*\{[\s\S]*?\}\s*catch",
            "error_logging": r"(console\.error|logger\.error)",

            # PII/Security patterns
            "pii_sanitizer": r"(PiiSanitizer|sanitize\w+|piiSanitize)",
            "sanitization": r"sanitize[A-Z]\w*\(",

            # Testing patterns
            "vitest_tests": r"(describe|it|test)\s*\(",
            "test_assertions": r"expect\(.*?\)\.(toBe|toEqual|toMatch|toContain)",
            "mock_usage": r"(vi\.mock|vi\.spyOn)",

            # Performance patterns
            "memo_optimization": r"(React\.memo|useMemo|useCallback)",
            "lazy_loading": r"(React\.lazy|lazy\()",

            # Accessibility patterns
            "aria_labels": r"aria-\w+",
            "wcag_compliance": r"(role=|tabIndex|aria-)",

            # TypeScript patterns
            "type_definitions": r"(type|interface)\s+[A-Z]\w+",
            "generic_types": r"<[A-Z]\w+(?:,\s*[A-Z]\w+)*>",

            # Component patterns
            "component_definition": r"(?:export\s+)?(?:function|const)\s+([A-Z]\w+)(?:\s*[=:]|\s*\()",
            "props_interface": r"interface\s+(\w+Props)",

            # State management
            "reducer_pattern": r"(useReducer|reducer|dispatch)",
            "state_updates": r"set[A-Z]\w+\(",

            # API patterns
            "fetch_api": r"fetch\(",
            "async_await": r"async\s+(?:function|\()",

            # CSV patterns
            "csv_parsing": r"(PapaParse|parse\w+CSV)",
            "csv_generation": r"(generateCSV|toCSV)",
        }

    def find_patterns(
        self,
        pattern_types: List[str] = None,
        file_extensions: List[str] = None,
        max_results: int = 100
    ) -> Dict[str, List[PatternMatch]]:
        """Find code patterns across the codebase."""
        if pattern_types is None:
            pattern_types = list(self.patterns.keys())

        if file_extensions is None:
            file_extensions = ['.ts', '.tsx', '.js', '.jsx']

        results = defaultdict(list)

        # Search directories
        search_dirs = [
            self.repo_path / "frontend" / "src",
            self.repo_path / "backend" / "src",
            self.repo_path / "backend" / "tests",
        ]

        for search_dir in search_dirs:
            if not search_dir.exists():
                continue

            for file_path in self._walk_files(search_dir, file_extensions):
                matches = self._search_file(file_path, pattern_types)
                for pattern_type, file_matches in matches.items():
                    results[pattern_type].extend(file_matches)

        # Limit results
        for pattern_type in results:
            results[pattern_type] = results[pattern_type][:max_results]

        return dict(results)

    def _walk_files(self, directory: Path, extensions: List[str]) -> List[Path]:
        """Recursively walk directory and collect files with specific extensions."""
        files = []
        for root, _, filenames in os.walk(directory):
            for filename in filenames:
                if any(filename.endswith(ext) for ext in extensions):
                    files.append(Path(root) / filename)
        return files

    def _search_file(self, file_path: Path, pattern_types: List[str]) -> Dict[str, List[PatternMatch]]:
        """Search a single file for patterns."""
        matches = defaultdict(list)

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            for line_num, line in enumerate(lines, 1):
                for pattern_type in pattern_types:
                    if pattern_type not in self.patterns:
                        continue

                    pattern = self.patterns[pattern_type]
                    if re.search(pattern, line):
                        # Get context (line before and after if available)
                        context_lines = []
                        if line_num > 1:
                            context_lines.append(lines[line_num - 2].rstrip())
                        context_lines.append(line.rstrip())
                        if line_num < len(lines):
                            context_lines.append(lines[line_num].rstrip())

                        match = PatternMatch(
                            file=str(file_path.relative_to(self.repo_path)),
                            line_number=line_num,
                            context='\n'.join(context_lines),
                            pattern_type=pattern_type
                        )
                        matches[pattern_type].append(match)

        except Exception as e:
            print(f"⚠️  Error reading {file_path}: {e}")

        return matches

    def find_testing_conventions(self) -> Dict:
        """Analyze testing conventions used in the codebase."""
        test_patterns = self.find_patterns(
            pattern_types=["vitest_tests", "test_assertions", "mock_usage"],
            file_extensions=[".test.ts", ".test.tsx", ".spec.ts"]
        )

        # Analyze test file structure
        test_files = []
        test_dir = self.repo_path / "backend" / "tests"

        if test_dir.exists():
            for test_file in test_dir.rglob("*.test.ts"):
                with open(test_file, 'r') as f:
                    content = f.read()

                # Count test blocks
                describes = len(re.findall(r'\bdescribe\s*\(', content))
                tests = len(re.findall(r'\b(?:it|test)\s*\(', content))

                test_files.append({
                    "file": str(test_file.relative_to(self.repo_path)),
                    "describe_blocks": describes,
                    "test_cases": tests
                })

        return {
            "patterns": {k: [asdict(m) for m in v] for k, v in test_patterns.items()},
            "test_files": test_files
        }

    def find_architecture_patterns(self) -> Dict:
        """Find high-level architecture patterns."""
        arch_patterns = self.find_patterns(
            pattern_types=[
                "react_context", "react_hooks", "custom_hooks",
                "localstorage", "archive_storage",
                "error_boundary", "pii_sanitizer"
            ]
        )

        return {k: [asdict(m) for m in v] for k, v in arch_patterns.items()}

    def generate_pattern_report(self, output_format: str = "markdown") -> str:
        """Generate a comprehensive pattern usage report."""
        patterns = self.find_patterns()

        if output_format == "json":
            report = {
                pattern_type: [asdict(m) for m in matches]
                for pattern_type, matches in patterns.items()
            }
            return json.dumps(report, indent=2)

        # Markdown format
        lines = ["# PayPlan Code Pattern Analysis\n"]

        # Group patterns by category
        categories = {
            "React Patterns": ["react_context", "react_hooks", "custom_hooks", "component_definition"],
            "Storage Patterns": ["localstorage", "archive_storage"],
            "Validation Patterns": ["zod_schema", "validation_error"],
            "Error Handling": ["error_boundary", "try_catch", "error_logging"],
            "Security & PII": ["pii_sanitizer", "sanitization"],
            "Testing Patterns": ["vitest_tests", "test_assertions", "mock_usage"],
            "Performance": ["memo_optimization", "lazy_loading"],
            "Accessibility": ["aria_labels", "wcag_compliance"],
        }

        for category, pattern_types in categories.items():
            category_patterns = {
                pt: patterns.get(pt, [])
                for pt in pattern_types
                if pt in patterns and patterns[pt]
            }

            if not category_patterns:
                continue

            lines.append(f"\n## {category}\n")

            for pattern_type, matches in category_patterns.items():
                lines.append(f"\n### {pattern_type.replace('_', ' ').title()}\n")
                lines.append(f"**Occurrences**: {len(matches)}\n\n")

                # Show top 5 examples
                for match in matches[:5]:
                    lines.append(f"**{match.file}:{match.line_number}**\n")
                    lines.append("```\n")
                    lines.append(f"{match.context}\n")
                    lines.append("```\n\n")

                if len(matches) > 5:
                    lines.append(f"*...and {len(matches) - 5} more occurrences*\n\n")

        return ''.join(lines)


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Find code patterns in PayPlan")
    parser.add_argument('--repo', default='.', help='Repository path')
    parser.add_argument('--pattern', help='Specific pattern to search for')
    parser.add_argument('--category', choices=['react', 'storage', 'testing', 'security', 'all'],
                        default='all', help='Pattern category')
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown')
    parser.add_argument('--output', help='Output file path')

    args = parser.parse_args()

    finder = CodePatternFinder(args.repo)

    if args.pattern:
        patterns = finder.find_patterns([args.pattern])
        output = json.dumps({args.pattern: [asdict(m) for m in patterns.get(args.pattern, [])]}, indent=2)
    elif args.category == 'testing':
        output = json.dumps(finder.find_testing_conventions(), indent=2)
    elif args.category == 'architecture':
        output = json.dumps(finder.find_architecture_patterns(), indent=2)
    else:
        output = finder.generate_pattern_report(args.format)

    if args.output:
        with open(args.output, 'w') as f:
            f.write(output)
        print(f"✅ Pattern report written to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
