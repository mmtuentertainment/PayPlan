#!/usr/bin/env python3
"""
Semantic Code Search for PayPlan

Goes beyond regex matching to understand code intent and relationships.
Uses AST parsing, call graph analysis, and semantic understanding.
"""

import os
import re
import ast
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
from dataclasses import dataclass, asdict
from collections import defaultdict


@dataclass
class SemanticMatch:
    file: str
    line_number: int
    function_name: str
    code_snippet: str
    intent: str  # What the code does
    context: List[str]  # Related functions/classes
    confidence: float  # 0-1 score


class SemanticCodeSearcher:
    def __init__(self, repo_path: str = "."):
        self.repo_path = Path(repo_path)
        self.call_graph = defaultdict(set)  # function -> called_by
        self.function_intents = {}  # function -> inferred intent

    def search_by_intent(self, intent_query: str) -> List[SemanticMatch]:
        """
        Search code by what it does, not just what it's named.

        Examples:
        - "manipulate payment dates" -> finds date arithmetic
        - "handle network errors" -> finds try/catch with fetch/axios
        - "validate user input" -> finds validation logic
        """
        matches = []

        # Parse intent query
        intent_keywords = self._extract_intent_keywords(intent_query)

        # Search TypeScript/JavaScript files
        for file_path in self._walk_source_files():
            file_matches = self._analyze_file_intent(file_path, intent_keywords)
            matches.extend(file_matches)

        # Sort by confidence
        matches.sort(key=lambda m: m.confidence, reverse=True)
        return matches

    def find_related_code(self, file_path: str, line_number: int) -> Dict:
        """
        Find all code related to a specific location.

        Returns:
        - Functions that call this code
        - Functions this code calls
        - Related data structures
        - Similar code patterns
        """
        result = {
            "callers": [],
            "callees": [],
            "related_types": [],
            "similar_patterns": []
        }

        # Build call graph for this file
        self._build_call_graph(Path(file_path))

        # Find function at line
        function_name = self._find_function_at_line(file_path, line_number)

        if function_name:
            result["callers"] = list(self.call_graph.get(function_name, set()))
            result["callees"] = self._find_function_calls(file_path, function_name)

        return result

    def detect_anti_patterns(self) -> List[Dict]:
        """
        Detect common anti-patterns in the codebase.

        Anti-patterns:
        - Deeply nested callbacks (callback hell)
        - Large functions (>100 lines)
        - Duplicate code (copy-paste)
        - Missing error handling
        - Unvalidated user input
        - Magic numbers
        - God objects (classes doing too much)
        """
        anti_patterns = []

        for file_path in self._walk_source_files():
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                # Detect patterns
                patterns = self._detect_file_anti_patterns(file_path, content)
                anti_patterns.extend(patterns)

            except Exception as e:
                continue

        return anti_patterns

    def find_data_flow(self, variable_name: str, file_path: str) -> List[Dict]:
        """
        Trace data flow for a variable through the codebase.

        Shows:
        - Where variable is defined
        - Where it's modified
        - Where it's read
        - Function calls that use it
        """
        flow = []

        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            lines = content.split('\n')

            for line_num, line in enumerate(lines, 1):
                # Simple heuristic: look for variable name
                if re.search(rf'\b{re.escape(variable_name)}\b', line):
                    operation = self._infer_operation(line, variable_name)
                    flow.append({
                        "line": line_num,
                        "code": line.strip(),
                        "operation": operation  # "define", "modify", "read"
                    })

        except Exception:
            pass

        return flow

    def _extract_intent_keywords(self, query: str) -> Set[str]:
        """Extract semantic keywords from intent query."""
        # Intent mapping: user query -> code patterns
        intent_map = {
            "manipulate dates": ["Date", "setDate", "getDate", "toISOString", "datetime"],
            "handle errors": ["try", "catch", "throw", "Error", "reject"],
            "validate input": ["validate", "check", "assert", "schema", "zod"],
            "network request": ["fetch", "axios", "http", "api", "request"],
            "store data": ["localStorage", "setItem", "save", "persist"],
            "load data": ["getItem", "load", "fetch", "retrieve"],
            "sanitize": ["sanitize", "clean", "filter", "remove"],
            "format": ["format", "toString", "parse", "convert"],
        }

        keywords = set()
        query_lower = query.lower()

        for intent, patterns in intent_map.items():
            if any(word in query_lower for word in intent.split()):
                keywords.update(patterns)

        # Also include words from query
        keywords.update(query.split())

        return keywords

    def _analyze_file_intent(
        self,
        file_path: Path,
        intent_keywords: Set[str]
    ) -> List[SemanticMatch]:
        """Analyze a file for semantic matches."""
        matches = []

        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            lines = content.split('\n')

            # Analyze each function
            functions = self._extract_functions(content, file_path)

            for func in functions:
                # Calculate confidence based on keyword matches
                confidence = self._calculate_confidence(func, intent_keywords)

                if confidence > 0.3:  # Threshold
                    matches.append(SemanticMatch(
                        file=str(file_path.relative_to(self.repo_path)),
                        line_number=func['line_number'],
                        function_name=func['name'],
                        code_snippet=func['snippet'],
                        intent=func['inferred_intent'],
                        context=func['context'],
                        confidence=confidence
                    ))

        except Exception:
            pass

        return matches

    def _extract_functions(self, content: str, file_path: Path) -> List[Dict]:
        """Extract function definitions with context."""
        functions = []

        # TypeScript/JavaScript function patterns
        patterns = [
            r'(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(',
            r'(?:export\s+)?const\s+(\w+)\s*=\s*(?:async\s+)?\(',
            r'(\w+)\s*:\s*\([^)]*\)\s*=>'  # Method in object
        ]

        lines = content.split('\n')

        for pattern in patterns:
            for match in re.finditer(pattern, content, re.MULTILINE):
                func_name = match.group(1)
                line_num = content[:match.start()].count('\n') + 1

                # Extract function body (simplified)
                start_line = line_num - 1
                end_line = min(start_line + 20, len(lines))  # Max 20 lines
                snippet = '\n'.join(lines[start_line:end_line])

                # Infer intent from code
                inferred_intent = self._infer_intent(snippet)

                # Extract context (called functions)
                context = self._extract_called_functions(snippet)

                functions.append({
                    'name': func_name,
                    'line_number': line_num,
                    'snippet': snippet[:200],  # Limit snippet size
                    'inferred_intent': inferred_intent,
                    'context': context
                })

        return functions

    def _infer_intent(self, code: str) -> str:
        """Infer what code does based on patterns."""
        intents = []

        if 'localStorage' in code or 'setItem' in code:
            intents.append("stores data locally")

        if 'fetch' in code or 'axios' in code:
            intents.append("makes network request")

        if 'try' in code and 'catch' in code:
            intents.append("handles errors")

        if 'zod' in code or 'validate' in code.lower():
            intents.append("validates data")

        if 'Date' in code or 'toISOString' in code:
            intents.append("manipulates dates")

        if 'sanitize' in code.lower():
            intents.append("sanitizes data")

        if 'map' in code or 'filter' in code or 'reduce' in code:
            intents.append("transforms array data")

        return " and ".join(intents) if intents else "performs operation"

    def _extract_called_functions(self, code: str) -> List[str]:
        """Extract function calls from code."""
        # Match function calls: functionName(
        pattern = r'\b([a-z_][a-zA-Z0-9_]*)\s*\('
        matches = re.findall(pattern, code)

        # Filter out common keywords
        keywords = {'if', 'for', 'while', 'switch', 'return', 'catch', 'typeof'}
        return [m for m in set(matches) if m not in keywords][:5]

    def _calculate_confidence(self, func: Dict, keywords: Set[str]) -> float:
        """Calculate confidence score for semantic match."""
        score = 0.0

        # Check function name
        func_name_lower = func['name'].lower()
        for keyword in keywords:
            if keyword.lower() in func_name_lower:
                score += 0.3

        # Check intent description
        intent_lower = func['inferred_intent'].lower()
        for keyword in keywords:
            if keyword.lower() in intent_lower:
                score += 0.3

        # Check code snippet
        snippet_lower = func['snippet'].lower()
        for keyword in keywords:
            if keyword.lower() in snippet_lower:
                score += 0.2

        return min(score, 1.0)

    def _detect_file_anti_patterns(self, file_path: Path, content: str) -> List[Dict]:
        """Detect anti-patterns in a file."""
        patterns = []
        lines = content.split('\n')

        # 1. Large functions (>100 lines)
        for func in self._extract_functions(content, file_path):
            func_lines = func['snippet'].count('\n')
            if func_lines > 100:
                patterns.append({
                    "type": "large_function",
                    "severity": "warning",
                    "file": str(file_path.relative_to(self.repo_path)),
                    "line": func['line_number'],
                    "message": f"Function '{func['name']}' is {func_lines} lines (>100)",
                    "suggestion": "Consider breaking into smaller functions"
                })

        # 2. Deep nesting (>4 levels)
        for line_num, line in enumerate(lines, 1):
            indent_level = (len(line) - len(line.lstrip())) // 2
            if indent_level > 4:
                patterns.append({
                    "type": "deep_nesting",
                    "severity": "warning",
                    "file": str(file_path.relative_to(self.repo_path)),
                    "line": line_num,
                    "message": f"Deep nesting detected ({indent_level} levels)",
                    "suggestion": "Extract nested logic into separate functions"
                })

        # 3. Magic numbers
        magic_number_pattern = r'\b(\d{2,})\b'
        for line_num, line in enumerate(lines, 1):
            if '//' in line or '/*' in line:  # Skip comments
                continue
            matches = re.findall(magic_number_pattern, line)
            for num in matches:
                if num not in ['0', '1', '10', '100']:  # Common acceptable numbers
                    patterns.append({
                        "type": "magic_number",
                        "severity": "info",
                        "file": str(file_path.relative_to(self.repo_path)),
                        "line": line_num,
                        "message": f"Magic number detected: {num}",
                        "suggestion": "Consider extracting to named constant"
                    })

        # 4. Missing error handling in async functions
        if 'async ' in content and 'catch' not in content:
            patterns.append({
                "type": "missing_error_handling",
                "severity": "warning",
                "file": str(file_path.relative_to(self.repo_path)),
                "line": 1,
                "message": "Async function without try/catch",
                "suggestion": "Add error handling for async operations"
            })

        return patterns

    def _walk_source_files(self) -> List[Path]:
        """Walk source directories and collect TypeScript/JavaScript files."""
        files = []

        search_dirs = [
            self.repo_path / "frontend" / "src",
            self.repo_path / "backend" / "src",
        ]

        for search_dir in search_dirs:
            if not search_dir.exists():
                continue

            for root, _, filenames in os.walk(search_dir):
                for filename in filenames:
                    if filename.endswith(('.ts', '.tsx', '.js', '.jsx')):
                        files.append(Path(root) / filename)

        return files

    def _build_call_graph(self, file_path: Path):
        """Build call graph for a file."""
        # Simplified implementation
        pass

    def _find_function_at_line(self, file_path: str, line_number: int) -> Optional[str]:
        """Find function name at specific line."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            functions = self._extract_functions(content, Path(file_path))

            for func in functions:
                if func['line_number'] <= line_number <= func['line_number'] + 50:
                    return func['name']

        except Exception:
            pass

        return None

    def _find_function_calls(self, file_path: str, function_name: str) -> List[str]:
        """Find functions called by a specific function."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            functions = self._extract_functions(content, Path(file_path))

            for func in functions:
                if func['name'] == function_name:
                    return func['context']

        except Exception:
            pass

        return []

    def _infer_operation(self, line: str, variable: str) -> str:
        """Infer operation type on variable."""
        if f'const {variable}' in line or f'let {variable}' in line or f'var {variable}' in line:
            return "define"
        elif f'{variable} =' in line or f'{variable}++' in line or f'{variable}--' in line:
            return "modify"
        else:
            return "read"


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Semantic code search for PayPlan")
    parser.add_argument('--repo', default='.', help='Repository path')
    parser.add_argument('--intent', help='Search by intent (e.g., "manipulate payment dates")')
    parser.add_argument('--anti-patterns', action='store_true', help='Detect anti-patterns')
    parser.add_argument('--related', help='Find related code: file:line')
    parser.add_argument('--data-flow', help='Trace data flow: variable:file')
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown')
    parser.add_argument('--output', help='Output file path')

    args = parser.parse_args()

    searcher = SemanticCodeSearcher(args.repo)

    if args.intent:
        print(f"🔍 Searching for code with intent: {args.intent}")
        matches = searcher.search_by_intent(args.intent)

        if args.format == 'json':
            output = json.dumps([asdict(m) for m in matches], indent=2)
        else:
            lines = [f"# Semantic Search Results: {args.intent}\n\n"]
            lines.append(f"**Found {len(matches)} matches**\n\n")

            for match in matches[:10]:  # Top 10
                lines.append(f"### {match.function_name} ({match.confidence:.0%} confidence)\n")
                lines.append(f"**File**: [{match.file}]({match.file}:{match.line_number})\n")
                lines.append(f"**Intent**: {match.intent}\n")
                lines.append(f"**Context**: {', '.join(match.context)}\n\n")
                lines.append("```typescript\n")
                lines.append(f"{match.code_snippet}\n")
                lines.append("```\n\n")

            output = ''.join(lines)

    elif args.anti_patterns:
        print("🔍 Detecting anti-patterns...")
        patterns = searcher.detect_anti_patterns()

        if args.format == 'json':
            output = json.dumps(patterns, indent=2)
        else:
            lines = ["# Anti-Pattern Detection Report\n\n"]
            lines.append(f"**Found {len(patterns)} potential issues**\n\n")

            by_type = defaultdict(list)
            for p in patterns:
                by_type[p['type']].append(p)

            for ptype, items in by_type.items():
                lines.append(f"## {ptype.replace('_', ' ').title()} ({len(items)})\n\n")
                for item in items[:5]:
                    lines.append(f"- **{item['file']}:{item['line']}** - {item['message']}\n")
                    lines.append(f"  - *Suggestion*: {item['suggestion']}\n\n")

            output = ''.join(lines)

    else:
        output = "Usage: Specify --intent, --anti-patterns, --related, or --data-flow"

    if args.output:
        with open(args.output, 'w') as f:
            f.write(output)
        print(f"✅ Report written to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
