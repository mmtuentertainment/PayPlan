#!/usr/bin/env python3
"""
Spec Artifact Validator for PayPlan

Validates consistency across spec.md, plan.md, tasks.md and other artifacts.
Checks for completeness, cross-references, and adherence to spec-kit conventions.
"""

import re
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple
from dataclasses import dataclass, asdict
from enum import Enum


class Severity(Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class ValidationIssue:
    severity: Severity
    artifact: str
    message: str
    location: str = ""


class SpecArtifactValidator:
    def __init__(self, feature_path: Path):
        self.feature_path = Path(feature_path)
        self.feature_id = feature_path.name
        self.issues: List[ValidationIssue] = []

    def validate_all(self) -> List[ValidationIssue]:
        """Run all validation checks."""
        self.issues = []

        # Check artifact existence
        self._check_required_artifacts()

        # Validate spec.md
        if (self.feature_path / "spec.md").exists():
            self._validate_spec()

        # Validate plan.md
        if (self.feature_path / "plan.md").exists():
            self._validate_plan()

        # Validate tasks.md
        if (self.feature_path / "tasks.md").exists():
            self._validate_tasks()

        # Cross-artifact validation
        self._validate_cross_references()

        return self.issues

    def _check_required_artifacts(self):
        """Check for required artifacts per spec-kit methodology."""
        required = ["spec.md"]
        recommended = ["plan.md", "tasks.md", "data-model.md", "research.md"]

        for artifact in required:
            if not (self.feature_path / artifact).exists():
                self.issues.append(ValidationIssue(
                    severity=Severity.ERROR,
                    artifact="structure",
                    message=f"Required artifact missing: {artifact}"
                ))

        for artifact in recommended:
            if not (self.feature_path / artifact).exists():
                self.issues.append(ValidationIssue(
                    severity=Severity.WARNING,
                    artifact="structure",
                    message=f"Recommended artifact missing: {artifact}"
                ))

    def _validate_spec(self):
        """Validate spec.md structure and content."""
        spec_path = self.feature_path / "spec.md"

        with open(spec_path, 'r') as f:
            content = f.read()

        # Check required sections
        required_sections = [
            "User Scenarios & Testing",
            "Requirements",
            "Success Criteria"
        ]

        for section in required_sections:
            if f"## {section}" not in content:
                self.issues.append(ValidationIssue(
                    severity=Severity.ERROR,
                    artifact="spec.md",
                    message=f"Required section missing: {section}"
                ))

        # Check for user stories
        user_story_pattern = r"###\s+User Story \d+"
        user_stories = re.findall(user_story_pattern, content)

        if not user_stories:
            self.issues.append(ValidationIssue(
                severity=Severity.WARNING,
                artifact="spec.md",
                message="No user stories found"
            ))

        # Check for acceptance scenarios
        if "**Given**" not in content or "**When**" not in content or "**Then**" not in content:
            self.issues.append(ValidationIssue(
                severity=Severity.WARNING,
                artifact="spec.md",
                message="Missing Gherkin-style acceptance scenarios (Given/When/Then)"
            ))

        # Check for functional requirements
        fr_pattern = r"\*\*FR-\d+\*\*:"
        frs = re.findall(fr_pattern, content)

        if not frs:
            self.issues.append(ValidationIssue(
                severity=Severity.WARNING,
                artifact="spec.md",
                message="No functional requirements (FR-XXX) found"
            ))

        # Check for success criteria
        sc_pattern = r"\*\*SC-\d+\*\*:"
        scs = re.findall(sc_pattern, content)

        if not scs:
            self.issues.append(ValidationIssue(
                severity=Severity.WARNING,
                artifact="spec.md",
                message="No success criteria (SC-XXX) found"
            ))

    def _validate_plan(self):
        """Validate plan.md structure."""
        plan_path = self.feature_path / "plan.md"

        with open(plan_path, 'r') as f:
            content = f.read()

        # Check for phases or implementation steps
        phase_pattern = r"##\s+(?:Phase|Step|Part)\s+\d+"
        phases = re.findall(phase_pattern, content, re.IGNORECASE)

        if not phases:
            self.issues.append(ValidationIssue(
                severity=Severity.WARNING,
                artifact="plan.md",
                message="No clear phases or steps found in implementation plan"
            ))

        # Check for technical decisions
        if "decision" not in content.lower() and "approach" not in content.lower():
            self.issues.append(ValidationIssue(
                severity=Severity.INFO,
                artifact="plan.md",
                message="Consider documenting technical decisions or architectural approaches"
            ))

    def _validate_tasks(self):
        """Validate tasks.md structure."""
        tasks_path = self.feature_path / "tasks.md"

        with open(tasks_path, 'r') as f:
            content = f.read()

        # Check for task format (T-XXX or similar)
        task_pattern = r"\*\*T(?:ask)?-?\d+\*\*"
        tasks = re.findall(task_pattern, content, re.IGNORECASE)

        if not tasks:
            self.issues.append(ValidationIssue(
                severity=Severity.WARNING,
                artifact="tasks.md",
                message="No clearly formatted tasks (T-XXX) found"
            ))

        # Check for acceptance criteria in tasks
        if "acceptance" not in content.lower() and "done when" not in content.lower():
            self.issues.append(ValidationIssue(
                severity=Severity.INFO,
                artifact="tasks.md",
                message="Consider adding acceptance criteria or 'done when' clauses to tasks"
            ))

    def _validate_cross_references(self):
        """Validate consistency across artifacts."""
        spec_path = self.feature_path / "spec.md"
        plan_path = self.feature_path / "plan.md"
        tasks_path = self.feature_path / "tasks.md"

        if not all(p.exists() for p in [spec_path, plan_path, tasks_path]):
            return  # Skip if artifacts missing

        with open(spec_path, 'r') as f:
            spec_content = f.read()

        with open(plan_path, 'r') as f:
            plan_content = f.read()

        with open(tasks_path, 'r') as f:
            tasks_content = f.read()

        # Extract FRs from spec
        fr_pattern = r"\*\*FR-(\d+)\*\*"
        frs_in_spec = set(re.findall(fr_pattern, spec_content))

        # Check if FRs are referenced in plan or tasks
        frs_in_plan = set(re.findall(fr_pattern, plan_content))
        frs_in_tasks = set(re.findall(fr_pattern, tasks_content))

        unreferenced_frs = frs_in_spec - frs_in_plan - frs_in_tasks

        if unreferenced_frs:
            self.issues.append(ValidationIssue(
                severity=Severity.WARNING,
                artifact="cross-reference",
                message=f"Functional requirements not referenced in plan or tasks: {', '.join(f'FR-{fr}' for fr in unreferenced_frs)}"
            ))

        # Extract user stories from spec
        user_story_pattern = r"###\s+User Story (\d+)"
        stories_in_spec = set(re.findall(user_story_pattern, spec_content))

        # Check if user stories are referenced in plan
        stories_in_plan = set(re.findall(user_story_pattern, plan_content))

        unreferenced_stories = stories_in_spec - stories_in_plan

        if unreferenced_stories:
            self.issues.append(ValidationIssue(
                severity=Severity.INFO,
                artifact="cross-reference",
                message=f"User stories not referenced in plan: {', '.join(f'Story {s}' for s in unreferenced_stories)}"
            ))

    def generate_report(self, output_format: str = "markdown") -> str:
        """Generate validation report."""
        if output_format == "json":
            return json.dumps([asdict(issue) for issue in self.issues], indent=2, default=str)

        # Markdown format
        lines = [f"# Validation Report: {self.feature_id}\n\n"]

        if not self.issues:
            lines.append("✅ **All validation checks passed!**\n")
            return ''.join(lines)

        # Group by severity
        errors = [i for i in self.issues if i.severity == Severity.ERROR]
        warnings = [i for i in self.issues if i.severity == Severity.WARNING]
        infos = [i for i in self.issues if i.severity == Severity.INFO]

        if errors:
            lines.append(f"## ❌ Errors ({len(errors)})\n\n")
            for issue in errors:
                lines.append(f"- **{issue.artifact}**: {issue.message}\n")
                if issue.location:
                    lines.append(f"  - Location: {issue.location}\n")
            lines.append("\n")

        if warnings:
            lines.append(f"## ⚠️  Warnings ({len(warnings)})\n\n")
            for issue in warnings:
                lines.append(f"- **{issue.artifact}**: {issue.message}\n")
                if issue.location:
                    lines.append(f"  - Location: {issue.location}\n")
            lines.append("\n")

        if infos:
            lines.append(f"## ℹ️  Suggestions ({len(infos)})\n\n")
            for issue in infos:
                lines.append(f"- **{issue.artifact}**: {issue.message}\n")
                if issue.location:
                    lines.append(f"  - Location: {issue.location}\n")
            lines.append("\n")

        return ''.join(lines)


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Validate PayPlan spec artifacts")
    parser.add_argument('feature_path', help='Path to feature directory')
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown')
    parser.add_argument('--output', help='Output file path')

    args = parser.parse_args()

    validator = SpecArtifactValidator(args.feature_path)

    print(f"🔍 Validating {validator.feature_id}...")
    issues = validator.validate_all()

    errors = len([i for i in issues if i.severity == Severity.ERROR])
    warnings = len([i for i in issues if i.severity == Severity.WARNING])
    infos = len([i for i in issues if i.severity == Severity.INFO])

    print(f"✅ Validation complete: {errors} errors, {warnings} warnings, {infos} suggestions")

    output = validator.generate_report(args.format)

    if args.output:
        with open(args.output, 'w') as f:
            f.write(output)
        print(f"✅ Report written to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
