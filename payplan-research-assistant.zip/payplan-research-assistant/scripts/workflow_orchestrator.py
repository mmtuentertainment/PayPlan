#!/usr/bin/env python3
"""
Spec-Kit Workflow Orchestrator for PayPlan

Guides through the proper spec-driven development workflow:
1. /speckit.specify - Create feature specification
2. /speckit.clarify - Resolve ambiguities
3. /speckit.plan - Generate implementation plan
4. /speckit.tasks - Break into atomic tasks
5. /speckit.implement - Execute implementation

Enforces the workflow order and validates state transitions.
"""

import os
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum


class WorkflowStage(Enum):
    """Spec-kit workflow stages in order."""
    NOT_STARTED = 0
    SPECIFY = 1
    CLARIFY = 2
    PLAN = 3
    TASKS = 4
    IMPLEMENT = 5
    COMPLETE = 6


@dataclass
class WorkflowState:
    """Current state of a feature in the workflow."""
    feature_id: str
    current_stage: WorkflowStage
    completed_stages: List[WorkflowStage]
    artifacts_present: List[str]
    clarifications_remaining: int
    next_action: str
    blockers: List[str]


class WorkflowOrchestrator:
    """
    Orchestrates the spec-kit workflow for PayPlan features.

    Ensures proper stage progression:
    - specify → clarify → plan → tasks → implement
    """

    def __init__(self, repo_path: str = "."):
        self.repo_path = Path(repo_path)
        self.specs_dir = self.repo_path / "specs"

        # Required artifacts for each stage
        self.stage_artifacts = {
            WorkflowStage.SPECIFY: ["spec.md"],
            WorkflowStage.CLARIFY: ["spec.md"],  # Updated spec with clarifications
            WorkflowStage.PLAN: ["spec.md", "plan.md", "data-model.md"],
            WorkflowStage.TASKS: ["spec.md", "plan.md", "tasks.md"],
            WorkflowStage.IMPLEMENT: ["spec.md", "plan.md", "tasks.md"]
        }

    def get_feature_state(self, feature_id: str) -> WorkflowState:
        """Determine current workflow state for a feature."""
        feature_dir = self.specs_dir / feature_id

        if not feature_dir.exists():
            return WorkflowState(
                feature_id=feature_id,
                current_stage=WorkflowStage.NOT_STARTED,
                completed_stages=[],
                artifacts_present=[],
                clarifications_remaining=0,
                next_action="Run /speckit.specify to create feature specification",
                blockers=[]
            )

        # Check which artifacts exist
        artifacts = []
        for artifact in ["spec.md", "plan.md", "data-model.md", "tasks.md", "research.md", "quickstart.md"]:
            if (feature_dir / artifact).exists():
                artifacts.append(artifact)

        # Check for [NEEDS CLARIFICATION] markers
        clarifications_remaining = 0
        if "spec.md" in artifacts:
            spec_content = (feature_dir / "spec.md").read_text(encoding='utf-8', errors='ignore')
            clarifications_remaining = spec_content.count("[NEEDS CLARIFICATION")

        # Determine current stage
        current_stage = self._determine_stage(artifacts, clarifications_remaining)
        completed_stages = self._get_completed_stages(current_stage)

        # Determine next action
        next_action = self._get_next_action(current_stage, clarifications_remaining)

        # Check for blockers
        blockers = self._check_blockers(feature_dir, current_stage, artifacts)

        return WorkflowState(
            feature_id=feature_id,
            current_stage=current_stage,
            completed_stages=completed_stages,
            artifacts_present=artifacts,
            clarifications_remaining=clarifications_remaining,
            next_action=next_action,
            blockers=blockers
        )

    def validate_transition(
        self,
        feature_id: str,
        from_stage: WorkflowStage,
        to_stage: WorkflowStage
    ) -> Tuple[bool, str]:
        """
        Validate that a stage transition is allowed.

        Returns: (is_valid, reason)
        """
        # Check sequential order
        if to_stage.value != from_stage.value + 1:
            return (False, f"Cannot skip from {from_stage.name} to {to_stage.name}. Must follow: specify → clarify → plan → tasks → implement")

        # Check required artifacts for current stage
        feature_dir = self.specs_dir / feature_id
        required_artifacts = self.stage_artifacts.get(from_stage, [])

        for artifact in required_artifacts:
            if not (feature_dir / artifact).exists():
                return (False, f"Missing required artifact: {artifact}. Complete {from_stage.name} stage first.")

        # Stage-specific validations
        if to_stage == WorkflowStage.PLAN:
            # Cannot proceed to plan if clarifications remain
            spec_content = (feature_dir / "spec.md").read_text(encoding='utf-8', errors='ignore')
            clarifications = spec_content.count("[NEEDS CLARIFICATION")
            if clarifications > 0:
                return (False, f"{clarifications} clarifications remaining. Run /speckit.clarify first.")

        return (True, "Transition valid")

    def get_workflow_guidance(self, feature_id: str) -> str:
        """
        Get human-readable guidance for current workflow state.
        """
        state = self.get_feature_state(feature_id)

        lines = [f"# Workflow State: {feature_id}\n"]
        lines.append(f"**Current Stage**: {state.current_stage.name}\n")
        lines.append(f"**Completed**: {', '.join(s.name for s in state.completed_stages) or 'None'}\n\n")

        # Progress bar
        total_stages = 5
        completed = len(state.completed_stages)
        progress = "=" * completed + ">" + "-" * (total_stages - completed - 1)
        lines.append(f"**Progress**: [{progress}] {completed}/{total_stages}\n\n")

        # Artifacts
        lines.append("## Artifacts Present\n")
        if state.artifacts_present:
            for artifact in state.artifacts_present:
                lines.append(f"- ✅ {artifact}\n")
        else:
            lines.append("- ❌ No artifacts yet\n")
        lines.append("\n")

        # Clarifications
        if state.clarifications_remaining > 0:
            lines.append(f"## ⚠️  Clarifications Needed\n")
            lines.append(f"**{state.clarifications_remaining}** [NEEDS CLARIFICATION] markers remaining\n\n")

        # Blockers
        if state.blockers:
            lines.append("## 🚫 Blockers\n")
            for blocker in state.blockers:
                lines.append(f"- {blocker}\n")
            lines.append("\n")

        # Next action
        lines.append("## 🎯 Next Action\n")
        lines.append(f"{state.next_action}\n\n")

        # Workflow guide
        lines.append("## 📋 Spec-Kit Workflow\n")
        lines.append("1. **Specify** (`/speckit.specify`) - Create feature spec\n")
        lines.append("2. **Clarify** (`/speckit.clarify`) - Resolve ambiguities\n")
        lines.append("3. **Plan** (`/speckit.plan`) - Generate implementation plan\n")
        lines.append("4. **Tasks** (`/speckit.tasks`) - Break into atomic tasks\n")
        lines.append("5. **Implement** (`/speckit.implement`) - Execute tasks\n\n")

        return ''.join(lines)

    def suggest_next_command(self, feature_id: str) -> str:
        """Suggest the exact slash command to run next."""
        state = self.get_feature_state(feature_id)

        if state.current_stage == WorkflowStage.NOT_STARTED:
            return "/speckit.specify <feature description>"

        if state.current_stage == WorkflowStage.SPECIFY:
            if state.clarifications_remaining > 0:
                return "/speckit.clarify"
            else:
                return "/speckit.plan <implementation approach>"

        if state.current_stage == WorkflowStage.CLARIFY:
            return "/speckit.plan <implementation approach>"

        if state.current_stage == WorkflowStage.PLAN:
            return "/speckit.tasks"

        if state.current_stage == WorkflowStage.TASKS:
            return "/speckit.implement"

        return "Feature workflow complete! ✅"

    def _determine_stage(self, artifacts: List[str], clarifications: int) -> WorkflowStage:
        """Determine current workflow stage based on artifacts."""
        if not artifacts:
            return WorkflowStage.NOT_STARTED

        if "spec.md" not in artifacts:
            return WorkflowStage.NOT_STARTED

        if clarifications > 0:
            return WorkflowStage.SPECIFY

        if "plan.md" not in artifacts:
            return WorkflowStage.CLARIFY

        if "tasks.md" not in artifacts:
            return WorkflowStage.PLAN

        # Check if implementation has started
        # (Look for completed tasks or code commits)
        return WorkflowStage.TASKS

    def _get_completed_stages(self, current_stage: WorkflowStage) -> List[WorkflowStage]:
        """Get list of completed stages."""
        completed = []
        for stage in WorkflowStage:
            if stage.value < current_stage.value and stage != WorkflowStage.NOT_STARTED:
                completed.append(stage)
        return completed

    def _get_next_action(self, stage: WorkflowStage, clarifications: int) -> str:
        """Determine the next action to take."""
        if stage == WorkflowStage.NOT_STARTED:
            return "Run /speckit.specify to create feature specification"

        if stage == WorkflowStage.SPECIFY:
            if clarifications > 0:
                return f"Run /speckit.clarify to resolve {clarifications} ambiguities"
            else:
                return "Run /speckit.plan to generate implementation plan"

        if stage == WorkflowStage.CLARIFY:
            return "Run /speckit.plan to generate implementation plan"

        if stage == WorkflowStage.PLAN:
            return "Run /speckit.tasks to break plan into atomic tasks"

        if stage == WorkflowStage.TASKS:
            return "Run /speckit.implement to execute tasks"

        return "Feature complete! Consider running /speckit.analyze for consistency check"

    def _check_blockers(
        self,
        feature_dir: Path,
        stage: WorkflowStage,
        artifacts: List[str]
    ) -> List[str]:
        """Check for blockers preventing workflow progression."""
        blockers = []

        # Check for [NEEDS CLARIFICATION] markers blocking plan
        if stage == WorkflowStage.CLARIFY and "spec.md" in artifacts:
            spec_content = (feature_dir / "spec.md").read_text(encoding='utf-8', errors='ignore')
            clarifications = spec_content.count("[NEEDS CLARIFICATION")
            if clarifications > 0:
                blockers.append(f"{clarifications} clarifications must be resolved before planning")

        # Check for missing dependencies
        if stage == WorkflowStage.PLAN and "spec.md" not in artifacts:
            blockers.append("spec.md must exist before creating plan")

        if stage == WorkflowStage.TASKS and "plan.md" not in artifacts:
            blockers.append("plan.md must exist before generating tasks")

        return blockers


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Spec-Kit workflow orchestrator for PayPlan")
    parser.add_argument('feature_id', help='Feature ID (e.g., 020-new-feature)')
    parser.add_argument('--repo', default='.', help='Repository path')
    parser.add_argument('--suggest', action='store_true', help='Suggest next command')
    parser.add_argument('--validate', help='Validate transition: from_stage:to_stage')
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown')

    args = parser.parse_args()

    orchestrator = WorkflowOrchestrator(args.repo)

    if args.suggest:
        command = orchestrator.suggest_next_command(args.feature_id)
        print(f"Next command: {command}")

    elif args.validate:
        from_stage, to_stage = args.validate.split(':')
        from_enum = WorkflowStage[from_stage.upper()]
        to_enum = WorkflowStage[to_stage.upper()]

        is_valid, reason = orchestrator.validate_transition(
            args.feature_id,
            from_enum,
            to_enum
        )

        if is_valid:
            print(f"✅ Transition valid: {from_stage} → {to_stage}")
        else:
            print(f"❌ Transition invalid: {reason}")

    else:
        if args.format == 'json':
            state = orchestrator.get_feature_state(args.feature_id)
            print(json.dumps(asdict(state), indent=2, default=str))
        else:
            guidance = orchestrator.get_workflow_guidance(args.feature_id)
            print(guidance)


if __name__ == "__main__":
    main()
