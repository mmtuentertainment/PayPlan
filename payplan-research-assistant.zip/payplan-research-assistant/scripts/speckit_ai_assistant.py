#!/usr/bin/env python3
"""
Spec-Kit AI Assistant for PayPlan

Auto-generates spec artifacts, suggests requirements, and drafts tasks
based on natural language descriptions and past feature patterns.
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict


@dataclass
class SuggestedRequirement:
    id: str
    text: str
    rationale: str
    confidence: float
    related_features: List[str]


@dataclass
class SuggestedTask:
    id: str
    title: str
    description: str
    dependencies: List[str]
    estimate: str
    mapped_to: List[str]  # FRs


class SpecKitAIAssistant:
    def __init__(self, repo_path: str = "."):
        self.repo_path = Path(repo_path)
        self.specs_dir = self.repo_path / "specs"
        self.patterns_db = self._build_patterns_database()

    def _build_patterns_database(self) -> Dict:
        """Build database of patterns from completed features."""
        patterns = {
            "common_requirements": [],
            "common_success_criteria": [],
            "typical_tasks": [],
            "tech_stack_patterns": {}
        }

        # Analyze completed features
        if not self.specs_dir.exists():
            return patterns

        for feature_dir in self.specs_dir.iterdir():
            if not feature_dir.is_dir():
                continue

            spec_file = feature_dir / "spec.md"
            if spec_file.exists():
                self._extract_patterns_from_spec(spec_file, patterns)

        return patterns

    def suggest_requirements(
        self,
        feature_description: str,
        similar_features: List[str] = None
    ) -> List[SuggestedRequirement]:
        """
        Suggest functional requirements based on feature description
        and patterns from similar features.
        """
        suggestions = []

        # Analyze feature description for key concepts
        concepts = self._extract_concepts(feature_description)

        # Look for similar patterns in past features
        for feature_id in (similar_features or []):
            related_reqs = self._get_requirements_from_feature(feature_id)
            for req in related_reqs:
                confidence = self._calculate_relevance(req, concepts)
                if confidence > 0.5:
                    suggestions.append(SuggestedRequirement(
                        id=f"FR-{len(suggestions) + 1:03d}",
                        text=req,
                        rationale=f"Based on similar pattern in feature {feature_id}",
                        confidence=confidence,
                        related_features=[feature_id]
                    ))

        # Add common requirements based on keywords
        common_reqs = self._suggest_common_requirements(concepts)
        suggestions.extend(common_reqs)

        # Sort by confidence
        suggestions.sort(key=lambda s: s.confidence, reverse=True)

        return suggestions

    def generate_spec_template(
        self,
        feature_id: str,
        feature_name: str,
        feature_description: str
    ) -> str:
        """Generate initial spec.md from natural language description."""

        # Extract key information
        concepts = self._extract_concepts(feature_description)
        similar_features = self._find_similar_features(concepts)

        # Generate spec content
        spec = f"""# Feature Specification: {feature_name}

**Feature Branch**: `feature/{feature_id}`
**Created**: {self._get_date()}
**Status**: Draft
**Input**: User description: "{feature_description}"

## Clarifications

### Session {self._get_date()}

{self._generate_clarification_questions(concepts)}

## User Scenarios & Testing

{self._generate_user_stories(concepts, similar_features)}

## Requirements

### Functional Requirements

{self._generate_functional_requirements(concepts, similar_features)}

## Success Criteria

### Measurable Outcomes

{self._generate_success_criteria(concepts)}

## Assumptions

{self._generate_assumptions(concepts)}

## Dependencies

{self._generate_dependencies(similar_features)}

## Out of Scope

{self._generate_out_of_scope(concepts)}
"""
        return spec

    def generate_tasks_from_plan(
        self,
        feature_id: str,
        plan_md_path: str
    ) -> List[SuggestedTask]:
        """
        Generate tasks.md automatically from plan.md.
        Breaks down phases into atomic tasks.
        """
        tasks = []

        try:
            with open(plan_md_path, 'r', encoding='utf-8', errors='ignore') as f:
                plan_content = f.read()

            # Extract phases
            phases = self._extract_phases(plan_content)

            task_counter = 1

            for phase_num, phase in enumerate(phases):
                # Break each phase into tasks
                phase_tasks = self._break_phase_into_tasks(
                    phase,
                    phase_num,
                    task_counter
                )

                tasks.extend(phase_tasks)
                task_counter += len(phase_tasks)

        except Exception as e:
            print(f"⚠️  Error generating tasks: {e}")

        return tasks

    def suggest_missing_artifacts(self, feature_id: str) -> List[str]:
        """Identify missing spec-kit artifacts for a feature."""
        feature_dir = self.specs_dir / feature_id
        missing = []

        required_artifacts = [
            "spec.md",
            "plan.md",
            "tasks.md",
            "data-model.md",
            "research.md"
        ]

        for artifact in required_artifacts:
            if not (feature_dir / artifact).exists():
                missing.append(artifact)

        return missing

    def estimate_complexity(
        self,
        feature_description: str,
        similar_features: List[str] = None
    ) -> Dict:
        """
        Estimate feature complexity based on description and
        comparison with similar features.
        """
        estimate = {
            "complexity_score": 0.0,  # 0-10
            "estimated_days": 0,
            "confidence": 0.0,
            "factors": []
        }

        concepts = self._extract_concepts(feature_description)

        # Factor 1: Number of concepts
        num_concepts = len(concepts)
        if num_concepts < 3:
            estimate["factors"].append("Simple: Few concepts")
            estimate["complexity_score"] += 2
        elif num_concepts < 6:
            estimate["factors"].append("Moderate: Multiple concepts")
            estimate["complexity_score"] += 5
        else:
            estimate["factors"].append("Complex: Many concepts")
            estimate["complexity_score"] += 8

        # Factor 2: Keywords indicating complexity
        complex_keywords = [
            "integration", "performance", "security", "scalability",
            "real-time", "concurrent", "distributed", "optimization"
        ]

        desc_lower = feature_description.lower()
        complex_count = sum(1 for kw in complex_keywords if kw in desc_lower)

        if complex_count > 2:
            estimate["factors"].append("High complexity keywords detected")
            estimate["complexity_score"] += 2

        # Factor 3: Compare with similar features
        if similar_features:
            avg_days = self._get_average_duration(similar_features)
            estimate["estimated_days"] = int(avg_days)
            estimate["confidence"] = 0.7
        else:
            # Rough estimate based on complexity score
            estimate["estimated_days"] = max(3, int(estimate["complexity_score"] / 2))
            estimate["confidence"] = 0.4

        # Cap complexity score at 10
        estimate["complexity_score"] = min(estimate["complexity_score"], 10.0)

        return estimate

    def _extract_concepts(self, text: str) -> List[str]:
        """Extract key concepts from text."""
        # Simple keyword extraction
        concepts = []

        # Common technical concepts
        keywords = [
            "storage", "localStorage", "database", "api", "rest", "graphql",
            "authentication", "authorization", "validation", "sanitization",
            "performance", "optimization", "caching", "testing", "accessibility",
            "security", "pii", "error", "logging", "monitoring", "ui", "ux",
            "component", "hook", "context", "state", "routing", "navigation"
        ]

        text_lower = text.lower()
        for keyword in keywords:
            if keyword in text_lower:
                concepts.append(keyword)

        return list(set(concepts))

    def _find_similar_features(self, concepts: List[str]) -> List[str]:
        """Find features with similar concepts."""
        similar = []

        if not self.specs_dir.exists():
            return similar

        for feature_dir in self.specs_dir.iterdir():
            if not feature_dir.is_dir():
                continue

            spec_file = feature_dir / "spec.md"
            if spec_file.exists():
                try:
                    with open(spec_file, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read().lower()

                    # Count concept matches
                    matches = sum(1 for c in concepts if c in content)

                    if matches >= 3:  # Threshold
                        similar.append(feature_dir.name)

                except Exception:
                    pass

        return similar[:3]  # Top 3

    def _generate_clarification_questions(self, concepts: List[str]) -> str:
        """Generate initial clarification questions."""
        questions = []

        if "storage" in concepts or "localStorage" in concepts:
            questions.append("- Q: What data needs to be persisted, and what are the size limits? → A: [To be answered]")

        if "validation" in concepts:
            questions.append("- Q: What validation rules should be enforced, and when? → A: [To be answered]")

        if "performance" in concepts:
            questions.append("- Q: What are the performance targets (latency, throughput)? → A: [To be answered]")

        if "accessibility" in concepts:
            questions.append("- Q: What WCAG level compliance is required (A, AA, AAA)? → A: [To be answered]")

        if "security" in concepts or "pii" in concepts:
            questions.append("- Q: What sensitive data needs protection, and how? → A: [To be answered]")

        return "\n".join(questions) if questions else "- Q: [Initial question] → A: [To be answered]"

    def _generate_user_stories(self, concepts: List[str], similar_features: List[str]) -> str:
        """Generate initial user story templates."""
        return """### User Story 1 - [Story Title] (Priority: P1)

[User story description focusing on user needs and business value]

**Why this priority**: [Justification]

**Independent Test**: [How to test in isolation]

**Acceptance Scenarios**:
1. **Given** [initial context], **When** [action], **Then** [expected outcome]
"""

    def _generate_functional_requirements(self, concepts: List[str], similar_features: List[str]) -> str:
        """Generate functional requirements based on concepts."""
        requirements = []

        if "storage" in concepts:
            requirements.append("- **FR-001**: System MUST persist data to localStorage with error handling")

        if "validation" in concepts:
            requirements.append("- **FR-002**: System MUST validate all user input using Zod schemas")

        if "accessibility" in concepts:
            requirements.append("- **FR-003**: System MUST be WCAG 2.1 AA compliant")

        if "security" in concepts:
            requirements.append("- **FR-004**: System MUST sanitize PII from error logs")

        return "\n".join(requirements) if requirements else "- **FR-001**: System MUST [requirement]"

    def _generate_success_criteria(self, concepts: List[str]) -> str:
        """Generate success criteria based on concepts."""
        criteria = []

        if "performance" in concepts:
            criteria.append("- **SC-001**: Operations complete in <100ms (95th percentile)")

        if "testing" in concepts:
            criteria.append("- **SC-002**: 80%+ code coverage with all tests passing")

        if "accessibility" in concepts:
            criteria.append("- **SC-003**: WCAG 2.1 AA compliance verified via automated tools")

        return "\n".join(criteria) if criteria else "- **SC-001**: [Measurable outcome]"

    def _generate_assumptions(self, concepts: List[str]) -> str:
        """Generate assumptions."""
        return "- **Assumption 1**: [State assumption clearly]"

    def _generate_dependencies(self, similar_features: List[str]) -> str:
        """Generate dependencies section."""
        if similar_features:
            deps = [f"- **Dependency 1**: Feature {f} - [reason for dependency]" for f in similar_features[:1]]
            return "\n".join(deps)
        return "- **Dependency 1**: [External dependency]"

    def _generate_out_of_scope(self, concepts: List[str]) -> str:
        """Generate out of scope items."""
        return "- **Out of Scope 1**: [Explicitly state what is NOT included]"

    def _extract_phases(self, plan_content: str) -> List[Dict]:
        """Extract phases from plan.md."""
        phases = []

        # Match patterns like "## Phase 0 - Title"
        phase_pattern = r'##\s+Phase\s+(\d+)\s+-\s+([^\n]+)'
        matches = re.finditer(phase_pattern, plan_content, re.MULTILINE)

        for match in matches:
            phase_num = int(match.group(1))
            phase_title = match.group(2).strip()

            phases.append({
                "number": phase_num,
                "title": phase_title,
                "content": ""  # Could extract content between phases
            })

        return phases

    def _break_phase_into_tasks(
        self,
        phase: Dict,
        phase_num: int,
        start_counter: int
    ) -> List[SuggestedTask]:
        """Break a phase into atomic tasks."""
        tasks = []

        # Generate typical tasks for each phase
        if phase_num == 0:
            # Planning phase tasks
            tasks.append(SuggestedTask(
                id=f"T-{start_counter:03d}",
                title="Read and understand feature spec",
                description="Review spec.md and clarify any ambiguities",
                dependencies=[],
                estimate="30 minutes",
                mapped_to=[]
            ))

        # Add more task generation logic based on phase analysis

        return tasks

    def _get_requirements_from_feature(self, feature_id: str) -> List[str]:
        """Extract requirements from a feature's spec.md."""
        requirements = []

        spec_file = self.specs_dir / feature_id / "spec.md"
        if spec_file.exists():
            try:
                with open(spec_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()

                # Extract FR-XXX requirements
                fr_pattern = r'\*\*FR-\d+\*\*:\s*System\s+(?:MUST|SHOULD)\s+([^\n]+)'
                matches = re.findall(fr_pattern, content)
                requirements.extend(matches)

            except Exception:
                pass

        return requirements

    def _calculate_relevance(self, requirement: str, concepts: List[str]) -> float:
        """Calculate relevance score between requirement and concepts."""
        score = 0.0
        req_lower = requirement.lower()

        for concept in concepts:
            if concept in req_lower:
                score += 0.3

        return min(score, 1.0)

    def _suggest_common_requirements(self, concepts: List[str]) -> List[SuggestedRequirement]:
        """Suggest common requirements based on concepts."""
        suggestions = []

        # Common patterns
        if "testing" in concepts:
            suggestions.append(SuggestedRequirement(
                id=f"FR-{len(suggestions) + 100:03d}",
                text="All code MUST have 80%+ test coverage",
                rationale="PayPlan testing standard from Feature 018",
                confidence=0.9,
                related_features=["018-technical-debt-cleanup"]
            ))

        return suggestions

    def _get_average_duration(self, feature_ids: List[str]) -> float:
        """Get average duration of similar features (in days)."""
        # Simplified: return estimate based on number of similar features
        return 3.0 + len(feature_ids)

    def _get_date(self) -> str:
        """Get current date in YYYY-MM-DD format."""
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d")

    def _extract_patterns_from_spec(self, spec_file: Path, patterns: Dict):
        """Extract patterns from a completed spec."""
        # Implementation for pattern extraction
        pass


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Spec-Kit AI Assistant for PayPlan")
    parser.add_argument('--repo', default='.', help='Repository path')
    parser.add_argument('--generate-spec', help='Generate spec template for feature')
    parser.add_argument('--suggest-requirements', help='Suggest requirements based on description')
    parser.add_argument('--estimate-complexity', help='Estimate feature complexity')
    parser.add_argument('--missing-artifacts', help='Find missing artifacts for feature ID')
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown')
    parser.add_argument('--output', help='Output file path')

    args = parser.parse_args()

    assistant = SpecKitAIAssistant(args.repo)

    if args.generate_spec:
        # Parse: feature-id:feature-name:description
        parts = args.generate_spec.split(':', 2)
        if len(parts) == 3:
            feature_id, name, description = parts
            output = assistant.generate_spec_template(feature_id, name, description)
        else:
            output = "Usage: --generate-spec 'feature-id:name:description'"

    elif args.suggest_requirements:
        suggestions = assistant.suggest_requirements(args.suggest_requirements)

        if args.format == 'json':
            output = json.dumps([asdict(s) for s in suggestions], indent=2)
        else:
            lines = ["# Suggested Requirements\n\n"]
            for sugg in suggestions:
                lines.append(f"## {sugg.id} (Confidence: {sugg.confidence:.0%})\n")
                lines.append(f"**Requirement**: {sugg.text}\n\n")
                lines.append(f"**Rationale**: {sugg.rationale}\n\n")
            output = ''.join(lines)

    elif args.estimate_complexity:
        estimate = assistant.estimate_complexity(args.estimate_complexity)
        output = json.dumps(estimate, indent=2)

    elif args.missing_artifacts:
        missing = assistant.suggest_missing_artifacts(args.missing_artifacts)
        output = f"Missing artifacts for {args.missing_artifacts}:\n" + "\n".join(f"- {a}" for a in missing)

    else:
        output = "Specify --generate-spec, --suggest-requirements, --estimate-complexity, or --missing-artifacts"

    if args.output:
        with open(args.output, 'w') as f:
            f.write(output)
        print(f"✅ Output written to {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
