#!/usr/bin/env python3
"""
Feature Strategist - Intelligent Next Feature Recommendations

Analyzes codebase, planning documents, project history, Linear issues,
and external trends to suggest the most practical and valuable next feature to build.

Usage:
    python scripts/feature_strategist.py [--format markdown|json] [--output FILE]
    python scripts/feature_strategist.py --analyze-gaps
    python scripts/feature_strategist.py --suggest-next --top 5
    python scripts/feature_strategist.py --check-debt
    python scripts/feature_strategist.py --with-linear  # Include Linear issues/enhancements

Note: Linear integration requires the AI agent to call Linear MCP tools.
      This script outputs a marker that the AI agent should enhance with Linear data.
"""

import argparse
import json
import re
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Tuple
from collections import defaultdict, Counter
from dataclasses import dataclass, asdict
import sys


@dataclass
class FeatureSuggestion:
    """Represents a suggested next feature"""
    title: str
    priority_score: float  # 0-100
    category: str  # Enhancement, New Feature, Technical Debt, User Request
    description: str
    rationale: str
    user_value: str
    effort_estimate: str  # Small (1-2 days), Medium (3-5 days), Large (1-2 weeks)
    dependencies: List[str]
    aligns_with_constitution: bool
    evidence: Dict[str, Any]  # Supporting data

    def to_dict(self):
        return asdict(self)


@dataclass
class CodebaseGap:
    """Represents a gap or opportunity in the codebase"""
    gap_type: str  # Missing Feature, Incomplete Pattern, Technical Debt
    description: str
    severity: str  # Low, Medium, High, Critical
    affected_files: List[str]
    suggestion: str


class FeatureStrategist:
    """Analyzes project to suggest next practical features"""

    def __init__(self, project_root: Path = None):
        self.root = project_root or Path.cwd()
        self.specs_dir = self.root / "specs"
        self.frontend_dir = self.root / "frontend"
        self.backend_dir = self.root / "backend"

        # Cache for analysis results
        self._completed_features = None
        self._code_patterns = None
        self._git_history = None
        self._todos_fixmes = None

    def suggest_next_features(self, top_n: int = 5, include_research: bool = False,
                             include_linear: bool = False) -> List[FeatureSuggestion]:
        """
        Main analysis: Suggest next features based on comprehensive analysis

        Args:
            top_n: Number of top suggestions to return
            include_research: Whether to include external research (web search)
            include_linear: Whether to include Linear issues (AI agent must enhance)

        Returns prioritized list of feature suggestions
        """
        suggestions = []

        # 1. Analyze completed features to find logical progressions
        suggestions.extend(self._analyze_feature_progression())

        # 2. Detect codebase gaps and missing patterns
        suggestions.extend(self._analyze_codebase_gaps())

        # 3. Extract user pain points from code comments
        suggestions.extend(self._analyze_user_pain_points())

        # 4. Identify technical debt opportunities
        suggestions.extend(self._analyze_technical_debt())

        # 5. Check constitution alignment opportunities
        suggestions.extend(self._analyze_constitution_opportunities())

        # 6. Analyze TODO/FIXME comments for feature hints
        suggestions.extend(self._analyze_todo_comments())

        # 7. External research (if requested) - industry trends and similar projects
        if include_research:
            suggestions.extend(self._research_industry_trends())

        # 8. Linear issues (if requested) - AI agent must enhance with MCP calls
        if include_linear:
            suggestions.extend(self._analyze_linear_issues())

        # Deduplicate and score
        suggestions = self._deduplicate_suggestions(suggestions)
        suggestions = sorted(suggestions, key=lambda s: s.priority_score, reverse=True)

        return suggestions[:top_n]

    def _analyze_feature_progression(self) -> List[FeatureSuggestion]:
        """Analyze completed features to find logical next steps"""
        suggestions = []
        features = self._get_completed_features()

        # Pattern 1: If we have import (014) + export (014), suggest bulk operations
        has_import = any('import' in f['name'].lower() for f in features)
        has_export = any('export' in f['name'].lower() or 'csv' in f['name'].lower() for f in features)

        if has_import and has_export:
            suggestions.append(FeatureSuggestion(
                title="Bulk Payment Operations",
                priority_score=75.0,
                category="Enhancement",
                description="Enable bulk editing, deletion, and status updates for multiple payments at once",
                rationale="Natural progression after import/export. Users who manage many payments need bulk operations.",
                user_value="Save time when managing multiple payments simultaneously",
                effort_estimate="Medium (3-5 days)",
                dependencies=["014-csv-import", "015-payment-system"],
                aligns_with_constitution=True,
                evidence={
                    "pattern": "import/export → bulk operations",
                    "similar_projects": ["expense trackers", "budget apps"]
                }
            ))

        # Pattern 2: If we have user preferences (016), suggest notification preferences
        has_preferences = any('preference' in f['name'].lower() for f in features)
        if has_preferences:
            suggestions.append(FeatureSuggestion(
                title="Payment Reminders & Notifications",
                priority_score=82.0,
                category="New Feature",
                description="Send browser notifications or email alerts for upcoming payments",
                rationale="User preferences system exists. Notifications are natural extension.",
                user_value="Never miss payment deadlines with proactive reminders",
                effort_estimate="Medium (3-5 days)",
                dependencies=["016-user-preferences"],
                aligns_with_constitution=True,
                evidence={
                    "pattern": "preferences → notifications",
                    "user_request_indicators": []
                }
            ))

        # Pattern 3: If we have archive (016), suggest search/filter
        has_archive = any('archive' in f['name'].lower() for f in features)
        if has_archive:
            suggestions.append(FeatureSuggestion(
                title="Advanced Search & Filtering",
                priority_score=78.0,
                category="Enhancement",
                description="Search archives by amount, date range, tags, or description with fuzzy matching",
                rationale="Archive system makes search/filter essential for finding past data",
                user_value="Quickly find specific payments in large archives",
                effort_estimate="Medium (3-5 days)",
                dependencies=["016-archive-system"],
                aligns_with_constitution=True,
                evidence={
                    "pattern": "archive → search",
                    "common_pattern": "All archive systems need search"
                }
            ))

        # Pattern 4: If we have PII sanitization, suggest data export privacy controls
        has_pii = any('pii' in f['name'].lower() for f in features)
        if has_pii and has_export:
            suggestions.append(FeatureSuggestion(
                title="Privacy-Controlled Data Export",
                priority_score=70.0,
                category="Enhancement",
                description="Let users choose what PII to include/exclude when exporting data",
                rationale="PII sanitization exists but export doesn't give users control",
                user_value="Share payment data without exposing sensitive information",
                effort_estimate="Small (1-2 days)",
                dependencies=["019-pii-sanitization", "014-csv-export"],
                aligns_with_constitution=True,
                evidence={
                    "pattern": "pii + export → privacy controls",
                    "privacy_first_principle": True
                }
            ))

        # Pattern 5: Navigation system suggests dashboard/analytics
        has_navigation = any('navigation' in f['name'].lower() for f in features)
        if has_navigation:
            suggestions.append(FeatureSuggestion(
                title="Payment Analytics Dashboard",
                priority_score=85.0,
                category="New Feature",
                description="Visual dashboard with spending trends, category breakdowns, and payment history charts",
                rationale="Navigation system in place. Users need overview/insights page.",
                user_value="Understand spending patterns and financial health at a glance",
                effort_estimate="Large (1-2 weeks)",
                dependencies=["017-navigation-system", "015-payment-system"],
                aligns_with_constitution=True,
                evidence={
                    "pattern": "navigation → dashboard landing page",
                    "missing_component": "No overview/home page"
                }
            ))

        return suggestions

    def _analyze_codebase_gaps(self) -> List[FeatureSuggestion]:
        """Detect missing patterns or incomplete implementations"""
        suggestions = []

        # Check for missing error boundaries
        has_error_boundary = self._file_exists_matching('**/ErrorBoundary.*')
        if not has_error_boundary:
            suggestions.append(FeatureSuggestion(
                title="Global Error Boundary",
                priority_score=68.0,
                category="Technical Debt",
                description="Add React Error Boundary to gracefully handle runtime errors",
                rationale="No error boundary detected. React apps should have this for UX.",
                user_value="Better user experience when errors occur (no white screen)",
                effort_estimate="Small (1-2 days)",
                dependencies=[],
                aligns_with_constitution=True,
                evidence={
                    "gap_type": "Missing pattern",
                    "best_practice": "React Error Boundaries"
                }
            ))

        # Check for missing loading states
        loading_patterns = self._count_pattern_in_codebase(r'(loading|isLoading|pending)')
        component_count = self._count_pattern_in_codebase(r'(function|const|class)\s+\w+.*Component')

        if loading_patterns < component_count * 0.5:  # Less than 50% coverage
            suggestions.append(FeatureSuggestion(
                title="Consistent Loading States",
                priority_score=60.0,
                category="Technical Debt",
                description="Add loading indicators to all async operations for better UX",
                rationale=f"Only {loading_patterns} loading patterns for ~{component_count} components",
                user_value="Clear feedback during data fetching and operations",
                effort_estimate="Medium (3-5 days)",
                dependencies=[],
                aligns_with_constitution=True,
                evidence={
                    "gap_type": "Incomplete pattern",
                    "coverage": f"{loading_patterns}/{component_count}"
                }
            ))

        # Check for missing accessibility (ARIA) labels
        aria_labels = self._count_pattern_in_codebase(r'aria-label')
        buttons = self._count_pattern_in_codebase(r'<button')

        if buttons > 10 and aria_labels < buttons * 0.7:  # Less than 70% coverage
            suggestions.append(FeatureSuggestion(
                title="Accessibility Audit & Fixes",
                priority_score=72.0,
                category="Technical Debt",
                description="Add ARIA labels and keyboard navigation to all interactive elements",
                rationale=f"Only {aria_labels} ARIA labels for {buttons} buttons (WCAG 2.1 AA compliance)",
                user_value="Make app usable for screen reader users and keyboard navigation",
                effort_estimate="Medium (3-5 days)",
                dependencies=[],
                aligns_with_constitution=True,
                evidence={
                    "gap_type": "Incomplete accessibility",
                    "wcag_level": "AA",
                    "coverage": f"{aria_labels}/{buttons}"
                }
            ))

        return suggestions

    def _analyze_user_pain_points(self) -> List[FeatureSuggestion]:
        """Extract pain points from commit messages and comments"""
        suggestions = []

        # Analyze git commit messages for pain point keywords
        pain_keywords = [
            'fix', 'bug', 'issue', 'problem', 'error', 'crash',
            'slow', 'performance', 'confusing', 'difficult'
        ]

        try:
            result = subprocess.run(
                ['git', 'log', '--all', '--pretty=format:%s', '--since=3 months ago'],
                cwd=self.root,
                capture_output=True,
                text=True,
                timeout=10
            )

            if result.returncode == 0:
                commits = result.stdout.splitlines()
                pain_commits = [c for c in commits if any(k in c.lower() for k in pain_keywords)]

                # Pattern: Frequent performance fixes suggest need for optimization
                perf_fixes = [c for c in pain_commits if 'performance' in c.lower() or 'slow' in c.lower()]
                if len(perf_fixes) >= 3:
                    suggestions.append(FeatureSuggestion(
                        title="Performance Monitoring & Optimization",
                        priority_score=76.0,
                        category="Technical Debt",
                        description="Add performance monitoring, profiling, and optimization pass",
                        rationale=f"Found {len(perf_fixes)} performance-related fixes in recent commits",
                        user_value="Faster app response times and smoother interactions",
                        effort_estimate="Large (1-2 weeks)",
                        dependencies=[],
                        aligns_with_constitution=True,
                        evidence={
                            "pain_point": "performance",
                            "commit_count": len(perf_fixes),
                            "sample_commits": perf_fixes[:3]
                        }
                    ))
        except Exception:
            pass

        return suggestions

    def _analyze_technical_debt(self) -> List[FeatureSuggestion]:
        """Identify technical debt that should be addressed"""
        suggestions = []

        # Check for missing test coverage
        test_files = list(self.root.rglob('*.test.*')) + list(self.root.rglob('*.spec.*'))
        source_files = list(self.root.rglob('*.ts')) + list(self.root.rglob('*.tsx'))
        source_files = [f for f in source_files if '.test.' not in str(f) and '.spec.' not in str(f)]

        if source_files:
            test_coverage_ratio = len(test_files) / len(source_files)

            if test_coverage_ratio < 0.5:  # Less than 50% files have tests
                suggestions.append(FeatureSuggestion(
                    title="Test Coverage Improvement",
                    priority_score=65.0,
                    category="Technical Debt",
                    description="Increase test coverage to at least 70% across critical paths",
                    rationale=f"Only {len(test_files)} test files for {len(source_files)} source files ({test_coverage_ratio*100:.0f}%)",
                    user_value="Fewer bugs, safer refactoring, faster development",
                    effort_estimate="Large (1-2 weeks)",
                    dependencies=[],
                    aligns_with_constitution=True,
                    evidence={
                        "debt_type": "test_coverage",
                        "current_ratio": test_coverage_ratio,
                        "test_files": len(test_files),
                        "source_files": len(source_files)
                    }
                ))

        # Check for outdated dependencies (if package.json exists)
        package_json = self.root / "frontend" / "package.json"
        if package_json.exists():
            suggestions.append(FeatureSuggestion(
                title="Dependency Audit & Updates",
                priority_score=55.0,
                category="Technical Debt",
                description="Update outdated dependencies and fix security vulnerabilities",
                rationale="Regular dependency updates prevent security issues and compatibility problems",
                user_value="More secure app with latest features and bug fixes",
                effort_estimate="Small (1-2 days)",
                dependencies=[],
                aligns_with_constitution=True,
                evidence={
                    "debt_type": "dependencies",
                    "package_json": str(package_json)
                }
            ))

        return suggestions

    def _analyze_constitution_opportunities(self) -> List[FeatureSuggestion]:
        """Find opportunities to improve constitution alignment"""
        suggestions = []

        # Check if constitution exists
        constitution_path = self.root / "memory" / "constitution.md"
        if not constitution_path.exists():
            suggestions.append(FeatureSuggestion(
                title="Create Project Constitution",
                priority_score=80.0,
                category="Technical Debt",
                description="Define immutable architectural principles (privacy-first, localStorage-only, WCAG 2.1 AA)",
                rationale="No constitution found. Spec-kit methodology requires constitutional principles.",
                user_value="Consistent architecture across all future features",
                effort_estimate="Small (1-2 days)",
                dependencies=[],
                aligns_with_constitution=True,
                evidence={
                    "opportunity": "missing_constitution",
                    "spec_kit_requirement": True
                }
            ))

        return suggestions

    def _analyze_todo_comments(self) -> List[FeatureSuggestion]:
        """Extract feature suggestions from TODO/FIXME comments"""
        suggestions = []

        # Search for TODO/FIXME comments
        todos = self._find_todos_fixmes()

        # Group TODOs by theme
        themes = {
            'feature': [],
            'refactor': [],
            'bug': [],
            'performance': [],
            'accessibility': []
        }

        for todo in todos:
            comment = todo['comment'].lower()
            if any(k in comment for k in ['add', 'implement', 'create', 'build']):
                themes['feature'].append(todo)
            elif any(k in comment for k in ['refactor', 'reorganize', 'clean']):
                themes['refactor'].append(todo)
            elif any(k in comment for k in ['bug', 'fix', 'broken']):
                themes['bug'].append(todo)
            elif any(k in comment for k in ['perf', 'slow', 'optimize']):
                themes['performance'].append(todo)
            elif any(k in comment for k in ['a11y', 'accessibility', 'aria', 'screen reader']):
                themes['accessibility'].append(todo)

        # If 3+ TODOs mention same theme, suggest addressing it
        for theme, items in themes.items():
            if len(items) >= 3:
                suggestions.append(FeatureSuggestion(
                    title=f"Address {theme.title()} TODOs",
                    priority_score=62.0,
                    category="Technical Debt",
                    description=f"Complete {len(items)} pending {theme} TODO comments",
                    rationale=f"Found {len(items)} TODO comments related to {theme}",
                    user_value=f"Cleaner codebase with completed {theme} improvements",
                    effort_estimate="Medium (3-5 days)",
                    dependencies=[],
                    aligns_with_constitution=True,
                    evidence={
                        "source": "TODO comments",
                        "theme": theme,
                        "count": len(items),
                        "samples": [t['comment'] for t in items[:3]]
                    }
                ))

        return suggestions

    def _deduplicate_suggestions(self, suggestions: List[FeatureSuggestion]) -> List[FeatureSuggestion]:
        """Remove duplicate suggestions and merge similar ones"""
        seen_titles = {}
        unique = []

        for suggestion in suggestions:
            # Use title as deduplication key
            key = suggestion.title.lower().strip()

            if key not in seen_titles:
                seen_titles[key] = suggestion
                unique.append(suggestion)
            else:
                # Merge evidence if duplicate
                existing = seen_titles[key]
                existing.priority_score = max(existing.priority_score, suggestion.priority_score)
                existing.evidence.update(suggestion.evidence)

        return unique

    # Helper methods

    def _get_completed_features(self) -> List[Dict]:
        """Get list of completed features from specs directory"""
        if self._completed_features is not None:
            return self._completed_features

        features = []
        if not self.specs_dir.exists():
            return features

        for feature_dir in sorted(self.specs_dir.iterdir()):
            if not feature_dir.is_dir():
                continue

            spec_file = feature_dir / "spec.md"
            if spec_file.exists():
                try:
                    content = spec_file.read_text(encoding='utf-8', errors='ignore')

                    # Extract feature title
                    title_match = re.search(r'^#\s+(?:Feature Specification:?\s*)?(.+)$', content, re.MULTILINE)
                    title = title_match.group(1).strip() if title_match else feature_dir.name

                    features.append({
                        'id': feature_dir.name,
                        'name': title,
                        'path': str(feature_dir)
                    })
                except Exception:
                    pass

        self._completed_features = features
        return features

    def _file_exists_matching(self, pattern: str) -> bool:
        """Check if any file matches the glob pattern"""
        return len(list(self.root.rglob(pattern))) > 0

    def _count_pattern_in_codebase(self, regex_pattern: str) -> int:
        """Count occurrences of regex pattern across codebase"""
        count = 0

        for ext in ['*.ts', '*.tsx', '*.js', '*.jsx']:
            for file_path in self.root.rglob(ext):
                if 'node_modules' in str(file_path) or '.git' in str(file_path):
                    continue

                try:
                    content = file_path.read_text(encoding='utf-8', errors='ignore')
                    matches = re.findall(regex_pattern, content, re.IGNORECASE)
                    count += len(matches)
                except Exception:
                    pass

        return count

    def _find_todos_fixmes(self) -> List[Dict]:
        """Find all TODO/FIXME comments in codebase"""
        if self._todos_fixmes is not None:
            return self._todos_fixmes

        todos = []

        for ext in ['*.ts', '*.tsx', '*.js', '*.jsx', '*.py', '*.md']:
            for file_path in self.root.rglob(ext):
                if 'node_modules' in str(file_path) or '.git' in str(file_path):
                    continue

                try:
                    content = file_path.read_text(encoding='utf-8', errors='ignore')

                    # Match TODO/FIXME comments
                    pattern = r'(?://|/\*|#)\s*(TODO|FIXME|XXX|HACK)[\s:]+(.+?)(?:\*/|$)'
                    matches = re.finditer(pattern, content, re.MULTILINE | re.IGNORECASE)

                    for match in matches:
                        todos.append({
                            'file': str(file_path.relative_to(self.root)),
                            'type': match.group(1).upper(),
                            'comment': match.group(2).strip()
                        })
                except Exception:
                    pass

        self._todos_fixmes = todos
        return todos

    def _research_industry_trends(self) -> List[FeatureSuggestion]:
        """
        Research industry trends and best practices for similar projects

        NOTE: This method returns research-based suggestions that can be
        enhanced with actual web search results by the AI agent calling this script.

        The AI agent should use WebSearch to find:
        - "best payment tracking app features 2025"
        - "personal finance app trends"
        - "budget app must-have features"
        """
        suggestions = []

        # These are common industry trends for payment/budget apps
        # AI agent can enhance these with actual web search results

        suggestions.append(FeatureSuggestion(
            title="Recurring Payment Detection",
            priority_score=73.0,
            category="New Feature",
            description="Automatically detect and flag recurring payments (subscriptions, bills)",
            rationale="Industry trend: Smart apps auto-detect patterns to help users manage subscriptions",
            user_value="Never forget about subscriptions; get alerts when new recurring payments start",
            effort_estimate="Medium (3-5 days)",
            dependencies=["015-payment-system"],
            aligns_with_constitution=True,
            evidence={
                "source": "industry_research",
                "trend": "subscription management",
                "similar_apps": ["Mint", "YNAB", "Copilot"],
                "note": "AI agent should enhance with WebSearch results"
            }
        ))

        suggestions.append(FeatureSuggestion(
            title="Budget Goals & Tracking",
            priority_score=77.0,
            category="New Feature",
            description="Set monthly budget goals per category and track progress with visual indicators",
            rationale="Industry standard: All modern budget apps have goal setting and progress tracking",
            user_value="Stay on budget with clear visual progress and alerts when approaching limits",
            effort_estimate="Large (1-2 weeks)",
            dependencies=["015-payment-system", "017-navigation-system"],
            aligns_with_constitution=True,
            evidence={
                "source": "industry_research",
                "trend": "goal-based budgeting",
                "similar_apps": ["Mint", "YNAB", "PocketGuard"],
                "note": "AI agent should enhance with WebSearch results"
            }
        ))

        return suggestions

    def _analyze_linear_issues(self) -> List[FeatureSuggestion]:
        """
        Analyze Linear issues and convert to feature suggestions

        NOTE: This method outputs a marker that the AI agent should enhance
        with actual Linear API calls using MCP tools.

        The AI agent should:
        1. Call mcp__linear__list_issues(team="MMTU Entertainment", query="payplan")
        2. Filter for Backlog status and priority
        3. Convert to FeatureSuggestion objects with proper scoring

        This method returns a placeholder that signals the need for Linear integration.
        """
        suggestions = []

        # Placeholder suggestion that AI agent will replace with real Linear data
        suggestions.append(FeatureSuggestion(
            title="[LINEAR_INTEGRATION_MARKER]",
            priority_score=0.0,
            category="User Request",
            description="AI agent should fetch Linear issues and replace this marker",
            rationale="Linear issues tracked in MMTU Entertainment team need to be analyzed",
            user_value="Implement user-requested features from Linear backlog",
            effort_estimate="Varies",
            dependencies=[],
            aligns_with_constitution=True,
            evidence={
                "source": "linear_integration",
                "team": "MMTU Entertainment",
                "note": "AI agent must call mcp__linear__list_issues() and convert results",
                "required_mcp_tool": "mcp__linear__list_issues"
            }
        ))

        return suggestions


def format_suggestions_markdown(suggestions: List[FeatureSuggestion]) -> str:
    """Format suggestions as markdown"""
    output = ["# 🚀 Next Feature Recommendations\n"]
    output.append(f"**Generated**: {subprocess.check_output(['date']).decode().strip()}\n")
    output.append(f"**Total Suggestions**: {len(suggestions)}\n")
    output.append("---\n")

    for i, suggestion in enumerate(suggestions, 1):
        output.append(f"## {i}. {suggestion.title}\n")
        output.append(f"**Priority Score**: {suggestion.priority_score:.1f}/100 | **Category**: {suggestion.category}\n")
        output.append(f"**Effort**: {suggestion.effort_estimate}\n\n")

        output.append(f"### Description\n{suggestion.description}\n\n")
        output.append(f"### Rationale\n{suggestion.rationale}\n\n")
        output.append(f"### User Value\n{suggestion.user_value}\n\n")

        if suggestion.dependencies:
            output.append(f"### Dependencies\n")
            for dep in suggestion.dependencies:
                output.append(f"- {dep}\n")
            output.append("\n")

        output.append(f"### Constitution Alignment\n")
        output.append(f"{'✅ Aligns' if suggestion.aligns_with_constitution else '⚠️ May violate'}\n\n")

        output.append(f"### Evidence\n```json\n{json.dumps(suggestion.evidence, indent=2)}\n```\n\n")
        output.append("---\n\n")

    return "".join(output)


def main():
    parser = argparse.ArgumentParser(description="Feature Strategist - Suggest next features")
    parser.add_argument('--format', choices=['markdown', 'json'], default='markdown',
                       help='Output format')
    parser.add_argument('--output', type=str, help='Output file (default: stdout)')
    parser.add_argument('--top', type=int, default=5, help='Number of suggestions to show')
    parser.add_argument('--project-root', type=str, help='Project root directory')
    parser.add_argument('--research', action='store_true',
                       help='Include industry research (AI agent should enhance with WebSearch)')
    parser.add_argument('--with-linear', action='store_true',
                       help='Include Linear issues (AI agent must call Linear MCP tools)')

    args = parser.parse_args()

    # Initialize strategist
    root = Path(args.project_root) if args.project_root else Path.cwd()
    strategist = FeatureStrategist(root)

    # Generate suggestions
    suggestions = strategist.suggest_next_features(
        top_n=args.top,
        include_research=args.research,
        include_linear=args.with_linear
    )

    # Format output
    if args.format == 'json':
        output = json.dumps([s.to_dict() for s in suggestions], indent=2)
    else:
        output = format_suggestions_markdown(suggestions)

    # Write output
    if args.output:
        Path(args.output).write_text(output)
        print(f"✅ Wrote suggestions to {args.output}")
    else:
        print(output)


if __name__ == '__main__':
    main()
