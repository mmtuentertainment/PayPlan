# PayPlan Feature Conventions

Coding standards, testing conventions, and best practices used throughout PayPlan.

## Feature Naming Conventions

### Feature IDs
Format: `###-feature-name-with-dashes`

**Rules**:
- Three-digit number (zero-padded)
- Lowercase with hyphens
- Descriptive but concise

**Examples**:
- `014-build-a-csv` ✅
- `019-pii-pattern-refinement` ✅
- `016-PaymentArchive` ❌ (no camelCase)
- `16-archive` ❌ (missing zero-padding)

### Branch Names
Format: `feature/###-feature-name`

**Examples**:
- `feature/019-pii-pattern-refinement` ✅
- `feat/019-pii` ❌ (use full 'feature/' prefix)

### Commit Messages
Format: `<type>: <description>`

**Types**:
- `feat`: New feature
- `fix`: Bug fix
- `refactor`: Code restructuring without behavior change
- `test`: Test additions/changes
- `docs`: Documentation changes
- `chore`: Build/tool changes
- `perf`: Performance improvements

**Examples**:
```
feat: Feature 019 - Add word boundary PII pattern matching
fix: Phase 4 Round 7 - Critical security fixes (PII leaks)
test: Add comprehensive ErrorBoundary test coverage
docs: Update CLAUDE.md with new PII patterns
refactor: Simplify ArchiveStorage index loading
```

**Required Elements**:
- Reference feature number when applicable
- Descriptive summary (50-72 chars)
- Body with details for complex changes
- Footer with GitHub signatures

**Footer**:
```
🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
```

## File Naming Conventions

### TypeScript Files
**Pattern**: PascalCase for components, camelCase for utilities

**Examples**:
- `ArchiveList.tsx` - Component
- `ArchiveList.test.tsx` - Component tests
- `ArchiveList.types.ts` - Type definitions
- `archiveStorage.ts` - Utility/service
- `useArchive.ts` - Custom hook

### Test Files
**Pattern**: `[FileName].test.ts[x]`

**Examples**:
- `PiiSanitizer.test.ts` - Backend test
- `ArchiveList.test.tsx` - Component test
- `ArchiveWorkflow.business.test.ts` - Business logic test

### Spec Artifacts
**Standard Names** (don't rename):
- `spec.md` - Feature specification
- `plan.md` - Implementation plan
- `tasks.md` - Task breakdown
- `data-model.md` - Data entities
- `research.md` - Research findings
- `quickstart.md` - Manual testing guide

## Code Style Guidelines

### TypeScript Style

#### Type Definitions
```typescript
// ✅ Use interface for objects
interface Payment {
  id: string;
  amount: number;
  date: string;
}

// ✅ Use type for unions/intersections
type PaymentStatus = 'pending' | 'completed' | 'archived';

// ✅ Use const for literals
const MAX_ARCHIVES = 50 as const;

// ❌ Don't use 'any'
function process(data: any) { } // Bad

// ✅ Use specific types or unknown
function process(data: Payment) { } // Good
function process(data: unknown) { } // Good when type truly unknown
```

#### Function Declarations
```typescript
// ✅ Export function (for top-level)
export function calculateTotal(payments: Payment[]): number {
  return payments.reduce((sum, p) => sum + p.amount, 0);
}

// ✅ Arrow function (for callbacks, methods)
const handleClick = useCallback(() => {
  setArchived(true);
}, [setArchived]);

// ✅ Async/await (not .then())
async function loadArchive(id: string): Promise<Archive> {
  const data = await ArchiveStorage.load(id);
  return data;
}
```

#### Component Style
```typescript
// ✅ Functional components with TypeScript
interface ArchiveListProps {
  archives: Archive[];
  onSelect: (id: string) => void;
}

export function ArchiveList({ archives, onSelect }: ArchiveListProps) {
  return (
    <div className="archive-list">
      {archives.map(archive => (
        <ArchiveCard
          key={archive.id}
          archive={archive}
          onClick={() => onSelect(archive.id)}
        />
      ))}
    </div>
  );
}

// ❌ Don't use React.FC
export const ArchiveList: React.FC<ArchiveListProps> = ({ ... }) => { }
```

### Naming Conventions

#### Variables and Functions
```typescript
// ✅ camelCase for variables and functions
const archiveCount = 10;
function loadArchive() { }

// ✅ PascalCase for components and classes
class ArchiveManager { }
function ArchiveList() { }

// ✅ SCREAMING_SNAKE_CASE for constants
const MAX_ARCHIVE_SIZE = 5 * 1024 * 1024;
const PII_PATTERNS = ['email', 'password'];

// ✅ Descriptive names
const totalPaymentAmount = calculateTotal(payments); // Good
const x = calculateTotal(payments); // Bad

// ✅ Boolean prefixes: is/has/should/can
const isArchived = true;
const hasPayments = payments.length > 0;
const shouldSanitize = checkPiiPatterns(fieldName);
```

#### Type Names
```typescript
// ✅ Descriptive, avoid generic names
interface ArchiveMetadata { }  // Good
interface Data { }             // Bad

// ✅ Props suffix for component props
interface ArchiveListProps { }

// ✅ Type suffix for type unions
type ArchiveStatusType = 'active' | 'archived';

// ❌ Don't prefix interfaces with I
interface IArchive { }  // Bad
interface Archive { }   // Good
```

## Testing Conventions

### Test Organization

#### File Structure
```typescript
// Feature-based test organization
describe('PiiSanitizer', () => {
  describe('Word Boundary Matching', () => {
    it('should not sanitize filename field', () => {
      // Test implementation
    });

    it('should sanitize name field', () => {
      // Test implementation
    });
  });

  describe('Authentication Secrets', () => {
    it('should sanitize password field', () => {
      // Test implementation
    });
  });
});
```

### Test Naming
**Pattern**: `should [expected behavior] when [condition]`

**Examples**:
```typescript
it('should remove PII fields from error objects', () => { });
it('should preserve legitimate technical fields', () => { });
it('should load archive index in under 100ms', () => { });
it('should handle circular references without crashing', () => { });
```

### Assertion Style
```typescript
// ✅ Use expect().toBe() for primitives
expect(count).toBe(5);
expect(isValid).toBe(true);

// ✅ Use expect().toEqual() for objects/arrays
expect(result).toEqual({ id: '123', name: 'Test' });
expect(archives).toEqual([archive1, archive2]);

// ✅ Use expect().toMatchObject() for partial matching
expect(payment).toMatchObject({
  amount: 100,
  date: expect.any(String)
});

// ✅ Use expect.any() for dynamic values
expect(archive).toEqual({
  id: expect.any(String),
  created: expect.any(Number)
});
```

### Test Data Generation
```typescript
// ✅ Create test data within each test (not global)
it('should sanitize email fields', () => {
  const testData = { email: 'test@example.com', name: 'John' };
  const result = sanitize(testData);
  expect(result).not.toHaveProperty('email');
});

// ✅ Use factories for complex objects
function createPayment(overrides = {}): Payment {
  return {
    id: crypto.randomUUID(),
    amount: 100,
    date: new Date().toISOString(),
    ...overrides
  };
}

it('should calculate total correctly', () => {
  const payments = [
    createPayment({ amount: 50 }),
    createPayment({ amount: 75 })
  ];
  expect(calculateTotal(payments)).toBe(125);
});
```

### Mock Management
```typescript
import { describe, it, expect, beforeEach, vi } from 'vitest';

describe('ArchiveManager', () => {
  beforeEach(() => {
    // Clean up mocks before each test
    vi.clearAllMocks();
    vi.restoreAllMocks();
  });

  it('should call storage save', () => {
    const saveSpy = vi.spyOn(ArchiveStorage, 'save');
    manager.saveArchive(archive);
    expect(saveSpy).toHaveBeenCalledWith(archive);
  });
});
```

### Test Coverage Targets
- **Unit tests**: 80%+ code coverage
- **Integration tests**: All critical paths
- **Business tests**: All user scenarios from spec.md

## Error Handling Conventions

### Error Boundaries
```tsx
// ✅ Wrap app/routes in ErrorBoundary
<ErrorBoundary>
  <ArchiveList />
</ErrorBoundary>

// ✅ Provide fallback UI
function ErrorFallback({ error }: { error: Error }) {
  return (
    <div role="alert">
      <h2>Something went wrong</h2>
      <button onClick={() => window.location.reload()}>
        Reload
      </button>
    </div>
  );
}
```

### Error Logging
```typescript
// ✅ Sanitize errors before logging
try {
  await saveArchive(archive);
} catch (error) {
  console.error('Archive save failed:', sanitize({ error, archive }));
  throw error;
}

// ❌ Don't log unsanitized data
console.error('Archive save failed:', error, archive); // May contain PII
```

### Error Messages
```typescript
// ✅ User-friendly messages
throw new Error('Failed to load archive: Archive not found');

// ❌ Technical jargon
throw new Error('ENOENT: no such file or directory'); // Bad for users

// ✅ Include context for debugging
throw new Error(`Failed to parse payment: ${paymentId} - Invalid date format`);
```

## Performance Conventions

### React Optimization

#### Memoization
```typescript
// ✅ Memo for expensive components
export const ArchiveCard = React.memo(function ArchiveCard({ archive }) {
  return <div>{archive.name}</div>;
});

// ✅ useMemo for expensive calculations
const totalAmount = useMemo(() => {
  return payments.reduce((sum, p) => sum + p.amount, 0);
}, [payments]);

// ✅ useCallback for event handlers passed as props
const handleSelect = useCallback((id: string) => {
  setSelected(id);
}, [setSelected]);
```

#### Avoid Unnecessary Re-renders
```typescript
// ✅ Destructure props to prevent re-renders
function ArchiveCard({ archive: { id, name, date } }) {
  return <div>{name}</div>;
}

// ❌ Passing entire object causes re-renders
function ArchiveCard({ archive }) {
  return <div>{archive.name}</div>;
}
```

### localStorage Optimization
```typescript
// ✅ Batch writes with debounce
const debouncedSave = debounce((data) => {
  localStorage.setItem('archives_index', JSON.stringify(data));
}, 500);

// ✅ Use index for metadata, load content on demand
async function loadArchive(id: string) {
  // Fast: Load from index
  const index = await loadIndex();
  const metadata = index.find(a => a.id === id);

  // On-demand: Load full content
  const content = JSON.parse(localStorage.getItem(`archive_${id}`));

  return { ...metadata, ...content };
}
```

## Accessibility Conventions

### ARIA Labels
```tsx
// ✅ Descriptive labels for buttons
<button aria-label="Archive payment plan">
  <ArchiveIcon />
</button>

// ✅ Role and labels for custom components
<div
  role="button"
  tabIndex={0}
  aria-label="Select archive"
  onClick={handleClick}
  onKeyPress={handleKeyPress}
>
  {archive.name}
</div>
```

### Keyboard Navigation
```tsx
// ✅ Support Enter and Space for custom interactive elements
function handleKeyPress(event: React.KeyboardEvent) {
  if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault();
    handleClick();
  }
}

// ✅ Visible focus indicators
<button className="focus:ring-2 focus:ring-blue-500 focus:outline-none">
  Archive
</button>
```

### Semantic HTML
```tsx
// ✅ Use semantic elements
<nav>
  <ul>
    <li><a href="/archives">Archives</a></li>
  </ul>
</nav>

// ❌ Don't use divs for everything
<div onClick={handleClick}>Archives</div> // Bad

// ✅ Use button for actions
<button onClick={handleClick}>Archive</button> // Good
```

## Documentation Conventions

### Code Comments
```typescript
// ✅ Explain WHY, not WHAT
// Sanitize errors to prevent PII leaks in production logs
const sanitized = sanitize(error);

// ❌ Don't state the obvious
// Set the count to 0
let count = 0;

// ✅ Document complex logic
// Word boundary regex: matches 'name' in 'userName' or 'user_name'
// but not in 'filename' (where 'name' is not a complete word)
const pattern = /(^|_|[A-Z])name(_|[A-Z]|$)/i;
```

### Function Documentation
```typescript
/**
 * Sanitizes an object by removing PII fields based on field name patterns.
 *
 * Uses word boundary matching to prevent false positives (e.g., 'filename'
 * is preserved while 'name' is removed).
 *
 * @param obj - Object to sanitize (can be nested)
 * @returns Sanitized copy with PII fields removed
 *
 * @example
 * const input = { username: 'john', password: 'secret' };
 * const output = sanitize(input);
 * // output: { username: 'john' }
 */
export function sanitize(obj: unknown): unknown {
  // Implementation
}
```

### README Documentation
```markdown
# Feature Name

Brief description of what this feature does.

## Usage

\`\`\`typescript
import { ArchiveManager } from './ArchiveManager';

const manager = new ArchiveManager();
await manager.saveArchive(archive);
\`\`\`

## API

### `saveArchive(archive: Archive): Promise<string>`

Saves an archive to localStorage and returns the archive ID.

## Testing

\`\`\`bash
npm test -- ArchiveManager.test.ts
\`\`\`
```

## Git Conventions

### Commit Workflow
```bash
# 1. Stage changes
git add .

# 2. Run tests
npm test

# 3. Commit with descriptive message
git commit -m "feat: Feature 019 - Add word boundary PII matching

Implements FR-001 through FR-003 from spec.md:
- Word boundary pattern matching
- Authentication secret patterns
- Scoped IP address detection

All 226+ existing tests pass + 30 new tests added.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>"
```

### Pull Request Workflow
```bash
# 1. Create PR with gh CLI
gh pr create --title "feat: Feature 019 - PII Pattern Refinement" \
  --body "## Summary
- Implements word boundary pattern matching (FR-001)
- Adds authentication secret detection (FR-003)
- Fixes false positives and false negatives

## Testing
- All 226+ existing tests pass
- 30+ new tests added for word boundaries
- Performance remains <50ms per sanitization

## Related
- Closes MMT-48
- Depends on Feature 018 (Technical Debt Cleanup)

🤖 Generated with [Claude Code](https://claude.com/claude-code)"

# 2. Wait for CI checks
gh pr checks

# 3. Merge when approved
gh pr merge --squash
```

## CLAUDE.md Updates

### When to Update
Update `CLAUDE.md` when:
- Adding new technologies
- Establishing new patterns
- Completing a feature
- Changing project structure

### Update Format
```markdown
## Active Technologies
- [Tech name] [version]: [Purpose] ([feature-id])

## Project Structure
\`\`\`
[Updated directory tree]
\`\`\`

## [Feature Name] (Feature ###)
- **[Pattern]**: [Description]
- **[Targets]**: [Performance/other targets]
```

### Commit Pattern
```bash
# Commit CLAUDE.md updates separately
git add CLAUDE.md
git commit -m "docs: Update CLAUDE.md with Feature 019 patterns"
```

## Quick Reference Checklist

### Before Starting Development
- [ ] Read feature spec in `specs/###-feature-name/spec.md`
- [ ] Understand requirements (FR-XXX) and success criteria (SC-XXX)
- [ ] Check dependencies on other features
- [ ] Review related code in git history

### During Development
- [ ] Write tests before implementation (TDD)
- [ ] Follow naming conventions (camelCase, PascalCase, etc.)
- [ ] Add TypeScript types (no `any`)
- [ ] Sanitize errors before logging
- [ ] Optimize for performance targets
- [ ] Ensure WCAG 2.1 AA accessibility

### Before Committing
- [ ] Run tests: `npm test`
- [ ] Run linter: `npm run lint`
- [ ] Check git diff for accidental changes
- [ ] Write descriptive commit message
- [ ] Reference feature ID in commit

### Before Creating PR
- [ ] All tests passing
- [ ] All lint errors fixed
- [ ] CLAUDE.md updated if needed
- [ ] PR description includes summary and testing details
- [ ] Reference related issues/features
