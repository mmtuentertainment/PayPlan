# Spec-Kit Workflow Deep Dive Reference

Complete guide to GitHub's Spec-Kit methodology implementation for AI-assisted development.

## Table of Contents

1. [Core Philosophy](#core-philosophy)
2. [Workflow Stages](#workflow-stages)
3. [Slash Command Implementation](#slash-command-implementation)
4. [Constitutional Development](#constitutional-development)
5. [Template Structure](#template-structure)
6. [Script Integration](#script-integration)
7. [Quality Gates & Validation](#quality-gates--validation)

---

## Core Philosophy

### Specification-Driven Development

**Key Principle**: Specifications become executable. Instead of writing specs that get out of sync with code, specs directly drive implementation through AI agents.

**Why It Works**:
- Specs are written in natural language (business-readable)
- Templates constrain LLM behavior to ensure quality
- Constitutional principles enforce architectural consistency
- Phase gates prevent premature implementation

**Critical Success Factors**:
1. **User Stories as Organization Unit**: Every feature breaks into independently testable user stories (P1, P2, P3)
2. **Progressive Elaboration**: specify → clarify → plan → tasks → implement
3. **Forced Reflection**: `[NEEDS CLARIFICATION]` markers limit assumptions (max 3 per stage)
4. **Constitution Compliance**: Every plan validates against immutable architectural principles

---

## Workflow Stages

### Stage 0: Constitution (Optional Foundation)

**Command**: `/speckit.constitution`

**Purpose**: Establish project-wide immutable principles before first feature

**Output**: `/memory/constitution.md`

**Structure**:
```markdown
# [PROJECT_NAME] Constitution

## Core Principles

### I. Library-First
Every feature starts as standalone library...

### II. CLI Interface
Every library exposes functionality via CLI...

### III. Test-First (NON-NEGOTIABLE)
TDD mandatory: Tests written → User approved → Tests fail → Implement

### IV-IX: [Additional Principles]
...

## Governance
Constitution supersedes all other practices
Amendments require approval + migration plan
```

**When to Use**:
- Starting a new project
- Establishing consistent patterns across features
- Preventing architectural drift

**Constitutional Principles (Common Examples)**:
- **Article I**: Library-First (self-contained modules)
- **Article II**: CLI Interface (text in/out protocol)
- **Article III**: Test-First (TDD mandatory)
- **Article VII**: Simplicity Gate (<3 projects rule)
- **Article VIII**: Anti-Abstraction Gate (reject premature patterns)
- **Article IX**: Integration-First (libraries call each other via CLI)

---

### Stage 1: Specify (Feature Creation)

**Command**: `/speckit.specify [natural language description]`

**Purpose**: Convert natural language → formal specification

**Execution Flow**:

1. **Branch Management**:
   ```bash
   # Fetch all sources
   git fetch --all --prune

   # Find highest feature number for short-name
   git ls-remote --heads origin | grep -E 'refs/heads/[0-9]+-<short-name>$'
   git branch | grep -E '^[* ]*[0-9]+-<short-name>$'
   ls specs/ | grep -E '^[0-9]+-<short-name>$'

   # Use highest + 1
   # Example: 019-pii-pattern-refinement → 020-pii-pattern-refinement
   ```

2. **Run Script** (creates branch + spec file):
   ```bash
   scripts/bash/create-new-feature.sh --json --number 5 --short-name "user-auth" "Add user authentication"
   ```

3. **Load Template**: Read `templates/spec-template.md`

4. **Parse User Description**:
   - Extract key concepts (actors, actions, data, constraints)
   - Identify clear requirements
   - Mark ambiguities with `[NEEDS CLARIFICATION: specific question]`
   - **LIMIT**: Maximum 3 clarification markers total
   - **Prioritize**: scope > security > UX > technical details

5. **Fill Spec Sections**:

   **Mandatory Sections**:
   - **User Scenarios & Testing**: User stories with priorities (P1, P2, P3)
     - Each story MUST be independently testable
     - Each story has acceptance scenarios (Given/When/Then)
   - **Requirements**: Functional requirements (FR-001, FR-002, ...)
   - **Success Criteria**: Measurable, technology-agnostic outcomes (SC-001, SC-002, ...)

   **Optional Sections** (include only if relevant):
   - Key Entities (if feature involves data)
   - Edge Cases
   - Assumptions
   - Out of Scope

6. **Specification Quality Validation**:
   - Generate checklist at `FEATURE_DIR/checklists/requirements.md`
   - Validate against checklist criteria:
     - No implementation details leaked
     - All requirements testable
     - Success criteria measurable
     - No [NEEDS CLARIFICATION] markers remain (or max 3)
   - If validation fails: Fix spec → Re-validate (max 3 iterations)

7. **Clarification Dialog** (if markers remain):
   ```markdown
   ## Question 1: [Topic]

   **Context**: [Quote relevant spec section]

   **What we need to know**: [Specific question]

   **Suggested Answers**:

   | Option | Answer | Implications |
   |--------|--------|--------------|
   | A      | Email/password | Simple, no 3rd party |
   | B      | OAuth2 | Complex, better UX |
   | C      | SSO | Enterprise, requires infrastructure |
   | Custom | Provide your own | [Explain format] |

   **Your choice**: _[Wait for user response]_
   ```

8. **Output**:
   - Branch: `###-feature-name`
   - Spec: `specs/###-feature-name/spec.md`
   - Checklist: `specs/###-feature-name/checklists/requirements.md`
   - Readiness: `/speckit.clarify` or `/speckit.plan`

---

### Stage 2: Clarify (Optional Risk Reduction)

**Command**: `/speckit.clarify [optional context]`

**Purpose**: Identify and resolve underspecified areas BEFORE planning

**When to Use**:
- Spec has ambiguous requirements
- Multiple reasonable interpretations exist
- Risk of downstream rework is high
- Exploratory spike → Skip clarify (but warn of risk)

**Execution Flow**:

1. **Run Script** (get paths):
   ```bash
   scripts/bash/check-prerequisites.sh --json --paths-only
   # Returns: FEATURE_DIR, FEATURE_SPEC, IMPL_PLAN, TASKS
   ```

2. **Load Current Spec**: Read `specs/###-feature-name/spec.md`

3. **Structured Ambiguity Scan** (Taxonomy):
   - **Functional Scope & Behavior**: Core goals, out-of-scope, user roles
   - **Domain & Data Model**: Entities, attributes, relationships, state transitions
   - **Interaction & UX Flow**: User journeys, error states, accessibility
   - **Non-Functional Attributes**: Performance, scalability, observability, security
   - **Integration & Dependencies**: External services, failure modes, protocols
   - **Edge Cases & Failure Handling**: Negative scenarios, rate limiting, conflicts
   - **Constraints & Tradeoffs**: Technical constraints, rejected alternatives
   - **Terminology & Consistency**: Canonical terms, avoided synonyms
   - **Completion Signals**: Acceptance criteria testability, Definition of Done

4. **Prioritize Questions** (Maximum 5 total):
   - Each question MUST be either:
     - Multiple choice (2-5 mutually exclusive options)
     - Short answer (≤5 words)
   - Only include questions that materially impact:
     - Architecture / Data modeling / Task decomposition
     - Test design / UX behavior / Operational readiness
     - Compliance validation
   - Apply (Impact × Uncertainty) heuristic

5. **Sequential Questioning Loop** (One at a time):

   **For Multiple Choice**:
   ```markdown
   **Recommended:** Option B - Industry standard OAuth2 provides best security/UX balance

   | Option | Description |
   |--------|-------------|
   | A      | Email/password authentication |
   | B      | OAuth2 (Google, GitHub) |
   | C      | Enterprise SSO only |
   | Short  | Provide different answer (≤5 words) |

   You can reply with option letter ("A"), accept recommendation ("yes"/"recommended"), or provide custom answer.
   ```

   **For Short Answer**:
   ```markdown
   **Suggested:** 90 days - Standard retention for GDPR compliance

   Format: Short answer (≤5 words). Accept suggestion ("yes"/"suggested") or provide your own.
   ```

6. **Integration After Each Answer** (Incremental):
   - Create `## Clarifications` section (if missing)
   - Add `### Session YYYY-MM-DD` subheading
   - Append: `- Q: <question> → A: <final answer>`
   - **Apply clarification** to appropriate section:
     - Functional ambiguity → Update Functional Requirements
     - User interaction → Update User Stories
     - Data shape → Update Data Model
     - Non-functional → Add/modify Quality Attributes
     - Edge case → Add to Edge Cases / Error Handling
     - Terminology → Normalize term across spec
   - **Remove obsolete statements** (avoid contradictions)
   - **Save spec file** immediately after each integration

7. **Validation** (After each write + final pass):
   - One bullet per accepted answer (no duplicates)
   - Total questions ≤ 5
   - No lingering vague placeholders
   - No contradictory statements
   - Markdown structure valid
   - Terminology consistent

8. **Completion Report**:
   - Number of questions asked/answered
   - Path to updated spec
   - Sections touched
   - Coverage summary table:
     - **Resolved**: Was Partial/Missing, now addressed
     - **Deferred**: Exceeds quota or better for planning
     - **Clear**: Already sufficient
     - **Outstanding**: Still Partial/Missing but low impact
   - Recommendation: Proceed to `/speckit.plan` or run clarify again?

---

### Stage 3: Plan (Design Artifacts)

**Command**: `/speckit.plan [optional context]`

**Purpose**: Generate technical design from specification

**Execution Flow**:

1. **Setup**:
   ```bash
   scripts/bash/setup-plan.sh --json
   # Returns: FEATURE_SPEC, IMPL_PLAN, SPECS_DIR, BRANCH
   ```

2. **Load Context**:
   - Read `FEATURE_SPEC` (spec.md)
   - Read `/memory/constitution.md`
   - Load `IMPL_PLAN` template (plan-template.md)

3. **Fill Technical Context** (mark unknowns):
   ```markdown
   **Language/Version**: Python 3.11 or NEEDS CLARIFICATION
   **Primary Dependencies**: FastAPI, SQLAlchemy or NEEDS CLARIFICATION
   **Storage**: PostgreSQL or N/A
   **Testing**: pytest or NEEDS CLARIFICATION
   **Target Platform**: Linux server or NEEDS CLARIFICATION
   **Performance Goals**: 1000 req/s or NEEDS CLARIFICATION
   **Constraints**: <200ms p95 or NEEDS CLARIFICATION
   **Scale/Scope**: 10k users or NEEDS CLARIFICATION
   ```

4. **Constitution Check** (GATE: Must pass):
   - Validate against constitution principles
   - Common gates:
     - **Article VII (Simplicity)**: ≤3 projects total
     - **Article VIII (Anti-Abstraction)**: No Repository pattern unless justified
     - **Article IX (Integration-First)**: Libraries call via CLI, not import
   - If violations: Document in Complexity Tracking table + justification
   - **ERROR if violations unjustified**

5. **Phase 0: Outline & Research** (`research.md`):
   - Extract all "NEEDS CLARIFICATION" from Technical Context
   - For each unknown → research task
   - For each technology → best practices task
   - For each dependency → patterns task
   - Consolidate findings in `research.md`:
     ```markdown
     ### Authentication Method
     - **Decision**: OAuth2 with JWT tokens
     - **Rationale**: Industry standard, scalable, secure
     - **Alternatives considered**: Session-based (rejected: not scalable), API keys (rejected: less secure)
     ```

6. **Phase 1: Design & Contracts**:

   **Generate `data-model.md`**:
   - Extract entities from spec
   - Define fields, relationships, validation rules
   - Document state transitions
   ```markdown
   ### User Entity
   - **id**: UUID (primary key)
   - **email**: String (unique, validated)
   - **password_hash**: String (bcrypt)
   - **Relationships**: 1-to-many with Session
   - **State Transitions**: Pending → Active → Suspended → Deleted
   ```

   **Generate `/contracts/` API specifications**:
   - For each user action → endpoint
   - Use REST/GraphQL patterns
   - Output OpenAPI or GraphQL schema
   ```yaml
   # contracts/auth-api.yaml
   openapi: 3.0.0
   paths:
     /auth/login:
       post:
         requestBody:
           content:
             application/json:
               schema:
                 type: object
                 properties:
                   email: string
                   password: string
   ```

   **Generate `quickstart.md`** (Manual test scenarios):
   - User flows for acceptance testing
   - Step-by-step manual test scripts
   - Expected results for each scenario

   **Update Agent Context**:
   ```bash
   # Auto-detects agent type (claude, copilot, etc.)
   scripts/bash/update-agent-context.sh __AGENT__
   # Updates .claude/CLAUDE.md or .github/copilot-instructions.md
   # Preserves manual additions between <!-- MANUAL ADDITIONS START/END --> markers
   ```

7. **Re-evaluate Constitution Check** (Post-design):
   - Verify final design still complies
   - Update Complexity Tracking if needed

8. **Output**:
   - Branch: `###-feature-name`
   - Plan: `specs/###-feature-name/plan.md`
   - Research: `specs/###-feature-name/research.md`
   - Data Model: `specs/###-feature-name/data-model.md`
   - Contracts: `specs/###-feature-name/contracts/*.yaml`
   - Quickstart: `specs/###-feature-name/quickstart.md`
   - Agent Context: `.claude/CLAUDE.md` (or agent-specific)
   - Readiness: `/speckit.tasks`

---

### Stage 4: Tasks (Atomic Breakdown)

**Command**: `/speckit.tasks [optional context]`

**Purpose**: Generate actionable, dependency-ordered tasks

**Execution Flow**:

1. **Setup**:
   ```bash
   scripts/bash/check-prerequisites.sh --json
   # Returns: FEATURE_DIR, AVAILABLE_DOCS (list)
   ```

2. **Load Design Documents**:
   - **Required**: `plan.md` (tech stack), `spec.md` (user stories)
   - **Optional**: `data-model.md`, `contracts/`, `research.md`, `quickstart.md`

3. **Task Generation Rules**:

   **Checklist Format (REQUIRED)**:
   ```markdown
   - [ ] [TaskID] [P?] [Story?] Description with file path

   Examples:
   - [ ] T001 Create project structure per plan.md
   - [ ] T005 [P] Implement auth middleware in src/middleware/auth.py
   - [ ] T012 [P] [US1] Create User model in src/models/user.py
   - [ ] T014 [US1] Implement UserService in src/services/user_service.py
   ```

   **Format Components**:
   - **Checkbox**: `- [ ]` (markdown checkbox)
   - **Task ID**: T001, T002, T003... (sequential execution order)
   - **[P] marker**: Include ONLY if parallelizable (different files, no dependencies)
   - **[Story] label**: [US1], [US2], [US3]... (REQUIRED for user story phases)
   - **Description**: Clear action with exact file path

4. **Task Organization** (By User Story):

   **From User Stories (spec.md)** - PRIMARY:
   - Each user story (P1, P2, P3...) gets its own phase
   - Map components to their story:
     - Models needed for story
     - Services needed for story
     - Endpoints/UI for story
     - Tests for story (if TDD requested)

   **From Contracts**:
   - Map endpoint → user story it serves
   - Contract test task [P] before implementation

   **From Data Model**:
   - Map entity → user story(ies) needing it
   - If entity serves multiple stories: Earliest story or Setup phase

   **From Setup/Infrastructure**:
   - Shared infrastructure → Setup phase (Phase 1)
   - Foundational/blocking → Foundational phase (Phase 2)
   - Story-specific → within story's phase

5. **Phase Structure**:
   ```markdown
   ## Phase 1: Setup
   - [ ] T001 Create project structure per plan.md
   - [ ] T002 Initialize Python 3.11 venv
   - [ ] T003 Install dependencies (FastAPI, SQLAlchemy)

   ## Phase 2: Foundational
   - [ ] T004 [P] Create database schema
   - [ ] T005 [P] Set up configuration system

   ## Phase 3: User Story 1 - User Registration (P1)
   **Goal**: Allow users to create accounts
   **Independent Test**: User can register and receive confirmation email

   ### Tests (if TDD)
   - [ ] T006 [P] [US1] Contract test: POST /auth/register
   - [ ] T007 [P] [US1] Unit test: UserService.create_user()

   ### Implementation
   - [ ] T008 [P] [US1] Create User model in src/models/user.py
   - [ ] T009 [US1] Implement UserService in src/services/user_service.py
   - [ ] T010 [US1] Create /auth/register endpoint in src/api/auth.py
   - [ ] T011 [US1] Integrate email confirmation

   ## Phase 4: User Story 2 - User Login (P2)
   ...

   ## Final Phase: Polish & Cross-Cutting
   - [ ] T030 Add comprehensive error logging
   - [ ] T031 Performance profiling and optimization
   - [ ] T032 Security audit
   ```

6. **Dependencies Section**:
   ```markdown
   ## Dependencies

   User Story 1 (P1) → User Story 2 (P2) → User Story 3 (P3)
   ├─ No dependencies between stories
   ├─ Each story can be implemented independently
   └─ MVP = Just User Story 1
   ```

7. **Parallel Execution Examples**:
   ```markdown
   ## Parallel Opportunities

   **Phase 3 (US1)**: T006, T007, T008 can run in parallel (different files)
   **Phase 4 (US2)**: T015, T016, T017 can run in parallel
   ```

8. **Tests are OPTIONAL**:
   - Only generate test tasks if:
     - Explicitly requested in spec
     - User requests TDD approach
   - Otherwise: Implementation tasks only

9. **Output**:
   - Tasks: `specs/###-feature-name/tasks.md`
   - Summary:
     - Total task count
     - Task count per user story
     - Parallel opportunities
     - Independent test criteria per story
     - Suggested MVP scope (typically User Story 1)
   - Format validation: ALL tasks follow checklist format
   - Readiness: `/speckit.implement`

---

### Stage 5: Implement (Execution)

**Command**: `/speckit.implement [optional context]`

**Purpose**: Execute implementation from tasks.md

**Execution Flow**:

1. **Setup**:
   ```bash
   scripts/bash/check-prerequisites.sh --json --require-tasks --include-tasks
   # Returns: FEATURE_DIR, AVAILABLE_DOCS, TASKS_CONTENT
   ```

2. **Checklist Status Validation** (If checklists/ exists):
   ```markdown
   | Checklist      | Total | Completed | Incomplete | Status |
   |----------------|-------|-----------|------------|--------|
   | ux.md          | 12    | 12        | 0          | ✓ PASS |
   | security.md    | 8     | 5         | 3          | ✗ FAIL |
   | performance.md | 6     | 6         | 0          | ✓ PASS |
   ```

   - **If any checklist FAILS**:
     - Display table
     - **STOP** and ask: "Some checklists incomplete. Proceed anyway? (yes/no)"
     - If "no": Halt execution
     - If "yes": Continue to step 3

   - **If all checklists PASS**:
     - Display table (all passing)
     - Automatically proceed to step 3

3. **Load Implementation Context**:
   - **REQUIRED**: `tasks.md`, `plan.md`
   - **IF EXISTS**: `data-model.md`, `contracts/`, `research.md`, `quickstart.md`

4. **Project Setup Verification**:

   **Ignore File Creation** (Based on detected tech):
   ```bash
   # Detect git repo
   git rev-parse --git-dir 2>/dev/null && create .gitignore

   # Detect Docker
   [ -f Dockerfile ] && create .dockerignore

   # Detect Node.js
   [ -f package.json ] && create .npmignore, .eslintignore, .prettierignore

   # Detect Python
   [ -f requirements.txt ] && add __pycache/, .venv/, *.pyc

   # Detect Rust
   [ -f Cargo.toml ] && add target/, *.rlib, *.prof*
   ```

   **Common Patterns**:
   - **Universal**: `.DS_Store`, `Thumbs.db`, `.vscode/`, `.idea/`, `.env*`
   - **Node.js**: `node_modules/`, `dist/`, `*.log`
   - **Python**: `__pycache__/`, `*.pyc`, `.venv/`
   - **Rust**: `target/`, `*.rlib`, `*.prof*`

5. **Parse tasks.md Structure**:
   - Extract phases (Setup, Tests, Core, Integration, Polish)
   - Extract task dependencies (Sequential vs Parallel)
   - Extract task details (ID, description, file paths, [P] marker)

6. **Execute Implementation** (Phase-by-phase):

   **Execution Rules**:
   - Complete each phase before moving to next
   - Respect dependencies: Sequential tasks run in order
   - Parallel tasks [P] can run together (different files)
   - TDD approach: Test tasks before implementation tasks
   - File-based coordination: Same file = sequential

   **Phase Order**:
   1. **Setup**: Initialize structure, dependencies, config
   2. **Tests** (if TDD): Write contract, entity, integration tests
   3. **Core**: Implement models, services, CLI, endpoints
   4. **Integration**: Database, middleware, logging, external services
   5. **Polish**: Unit tests, performance, documentation

7. **Progress Tracking**:
   - Report progress after each completed task
   - Halt if non-parallel task fails
   - For parallel tasks [P]: Continue successful, report failed
   - **CRITICAL**: Mark completed tasks as `[X]` in tasks.md
   ```markdown
   - [X] T001 Create project structure per plan.md
   - [X] T002 Initialize Python 3.11 venv
   - [ ] T003 Install dependencies (FastAPI, SQLAlchemy)
   ```

8. **Error Handling**:
   - Clear error messages with context
   - Suggest next steps if blocked
   - User can fix and resume

9. **Completion Validation**:
   - Verify all required tasks completed
   - Check features match spec
   - Validate tests pass
   - Confirm follows technical plan
   - Report final status with summary

10. **Output**:
    - Implemented feature in codebase
    - Updated tasks.md (all tasks marked `[X]`)
    - Test results
    - Implementation summary
    - Readiness: Manual validation, QA, deployment

---

## Slash Command Implementation

### How Slash Commands Work

**Mechanism**:
1. User types `/speckit.specify Build user authentication` in AI agent
2. AI agent reads `.claude/commands/speckit.specify.md` (or `.github/commands/` for Copilot)
3. Command file contains:
   - **Frontmatter** (YAML): description, scripts to run
   - **Body** (Markdown): Detailed instructions for AI
4. AI follows instructions, runs scripts, generates artifacts

**Command File Structure**:
```markdown
---
description: Create feature specification from natural language
scripts:
  sh: scripts/bash/create-new-feature.sh --json "{ARGS}"
  ps: scripts/powershell/create-new-feature.ps1 -Json "{ARGS}"
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding.

## Outline

1. Run `{SCRIPT}` from repo root...
2. Load templates...
3. Execute workflow...
4. Generate artifacts...
```

**Variable Substitution**:
- `$ARGUMENTS` → User-provided text after slash command
- `{SCRIPT}` → Appropriate script for OS (sh or ps)
- `{ARGS}` → JSON-escaped arguments

---

## Constitutional Development

### Why Constitutions Matter

**Problem**: LLMs generate inconsistent architectures across features
**Solution**: Immutable constitution enforced at every planning phase

### Constitution Structure

```markdown
# [PROJECT] Constitution

## Core Principles

### I. Library-First
- Every feature = standalone library
- Self-contained, independently testable
- Clear purpose (no "utilities" dumping ground)

### II. CLI Interface
- Every library exposes via CLI
- stdin/args → stdout (data)
- stderr (errors)
- JSON + human-readable formats

### III. Test-First (NON-NEGOTIABLE)
- TDD mandatory
- Tests written → User approves → Tests fail → Implement
- Red-Green-Refactor strictly enforced

### VII. Simplicity Gate
- Maximum 3 projects/repositories
- Justify 4th with documented need
- Simpler alternative rejection rationale required

### VIII. Anti-Abstraction Gate
- No Repository pattern unless justified
- No premature abstraction
- Direct solutions preferred

### IX. Integration-First
- Libraries call each other via CLI (not import)
- Text protocol enforces decoupling
- Enables polyglot development

## Governance

- Constitution supersedes all practices
- Amendments require approval + migration
- All PRs verify compliance
```

### Constitution Checks (Phase Gates)

**When**: Before Phase 0 research + After Phase 1 design

**How**:
```markdown
## Constitution Check

*GATE: Must pass before Phase 0. Re-check after Phase 1.*

| Article | Status | Notes |
|---------|--------|-------|
| I. Library-First | ✓ PASS | Feature structured as auth_lib/ |
| II. CLI Interface | ✓ PASS | Exposes auth-cli command |
| III. Test-First | ✓ PASS | TDD workflow defined |
| VII. Simplicity | ⚠ VIOLATION | 4th project needed - see Complexity Tracking |
| VIII. Anti-Abstraction | ✓ PASS | Direct SQL, no Repository pattern |
| IX. Integration-First | ✓ PASS | Calls user_lib via CLI |

**Violations Requiring Justification**:
- Article VII: 4th project needed for auth isolation
  - Justification: Security boundary, separate deployment
  - Simpler alternative rejected: Monolith violates least-privilege principle
```

**If Unjustified Violations**: **ERROR** → Cannot proceed to implementation

---

## Template Structure

### Spec Template Highlights

**Location**: `templates/spec-template.md`

**Key Sections**:
```markdown
# Feature Specification: [NAME]

**Feature Branch**: `###-feature-name`
**Status**: Draft
**Input**: User description: "$ARGUMENTS"

## User Scenarios & Testing *(mandatory)*
### User Story 1 - [Title] (Priority: P1)
**Why this priority**: [Value explanation]
**Independent Test**: [How to test standalone]
**Acceptance Scenarios**:
1. **Given** [state], **When** [action], **Then** [outcome]

## Requirements *(mandatory)*
### Functional Requirements
- **FR-001**: System MUST [capability]
- **FR-002**: Users MUST be able to [interaction]

### Key Entities *(if data involved)*
- **User**: Represents account holder (email, password_hash)

## Success Criteria *(mandatory)*
### Measurable Outcomes
- **SC-001**: Users complete registration in <2 minutes (90% rate)
- **SC-002**: System handles 1000 concurrent users without degradation
```

**Critical Rules**:
- Mandatory sections MUST be filled
- Optional sections removed if not applicable (not "N/A")
- No implementation details (tech-agnostic)
- Max 3 [NEEDS CLARIFICATION] markers
- Success criteria MUST be measurable + technology-agnostic

---

### Plan Template Highlights

**Location**: `templates/plan-template.md`

**Key Sections**:
```markdown
# Implementation Plan: [FEATURE]

## Technical Context
**Language/Version**: Python 3.11
**Primary Dependencies**: FastAPI, SQLAlchemy
**Storage**: PostgreSQL
**Testing**: pytest
**Performance Goals**: 1000 req/s
**Constraints**: <200ms p95

## Constitution Check
[See Constitutional Development section]

## Project Structure
### Documentation (this feature)
specs/###-feature/
├── spec.md
├── plan.md
├── research.md
├── data-model.md
├── contracts/
└── tasks.md

### Source Code (repository root)
src/
├── models/
├── services/
├── cli/
└── lib/

tests/
├── contract/
├── integration/
└── unit/

## Complexity Tracking
[Only if Constitution violations need justification]
```

---

### Tasks Template Highlights

**Location**: `templates/tasks-template.md`

**Key Sections**:
```markdown
# Implementation Tasks: [FEATURE]

## Phase 1: Setup
- [ ] T001 Create project structure per plan.md
- [ ] T002 Initialize dependencies

## Phase 2: Foundational
- [ ] T003 [P] Set up database schema
- [ ] T004 [P] Configure logging

## Phase 3: User Story 1 - [Title] (P1)
**Goal**: [User story summary]
**Independent Test**: [Standalone test criteria]

### Tests (if TDD)
- [ ] T005 [P] [US1] Contract test: POST /auth/register

### Implementation
- [ ] T006 [P] [US1] Create User model in src/models/user.py
- [ ] T007 [US1] Implement UserService in src/services/user_service.py

## Dependencies
US1 (P1) → US2 (P2) → US3 (P3)
```

**Critical Format**:
- EVERY task: `- [ ] [TID] [P?] [Story?] Description with file path`
- Story labels REQUIRED for user story phases
- [P] marker for parallelizable tasks
- Clear file paths in descriptions

---

## Script Integration

### How Scripts Work

**Purpose**: Scripts are the bridge between AI instructions and actual file system operations.

**Common Scripts**:

1. **`create-new-feature.sh`** (Specify stage):
   ```bash
   # Usage
   ./scripts/bash/create-new-feature.sh --json --number 5 --short-name "user-auth" "Add user authentication"

   # Does:
   # 1. Creates branch: 005-user-auth
   # 2. Creates directory: specs/005-user-auth/
   # 3. Copies spec template to specs/005-user-auth/spec.md
   # 4. Returns JSON: {"BRANCH_NAME": "...", "SPEC_FILE": "..."}
   ```

2. **`check-prerequisites.sh`** (Clarify/Tasks/Implement stages):
   ```bash
   # Usage
   ./scripts/bash/check-prerequisites.sh --json --paths-only

   # Does:
   # 1. Detects current feature branch
   # 2. Finds feature directory in specs/
   # 3. Returns JSON: {"FEATURE_DIR": "...", "FEATURE_SPEC": "...", "AVAILABLE_DOCS": ["..."]}
   ```

3. **`setup-plan.sh`** (Plan stage):
   ```bash
   # Usage
   ./scripts/bash/setup-plan.sh --json

   # Does:
   # 1. Copies plan template to specs/###-feature/plan.md
   # 2. Returns JSON: {"FEATURE_SPEC": "...", "IMPL_PLAN": "...", "BRANCH": "..."}
   ```

4. **`update-agent-context.sh`** (Plan stage - agent context):
   ```bash
   # Usage
   ./scripts/bash/update-agent-context.sh claude

   # Does:
   # 1. Auto-detects agent type (claude, copilot, gemini, etc.)
   # 2. Updates agent-specific context file (.claude/CLAUDE.md or .github/copilot-instructions.md)
   # 3. Adds new technology from current plan
   # 4. Preserves manual additions between <!-- MANUAL ADDITIONS START/END --> markers
   ```

**JSON Output Pattern**:
```json
{
  "BRANCH_NAME": "005-user-auth",
  "FEATURE_DIR": "/absolute/path/to/specs/005-user-auth",
  "SPEC_FILE": "/absolute/path/to/specs/005-user-auth/spec.md",
  "IMPL_PLAN": "/absolute/path/to/specs/005-user-auth/plan.md",
  "AVAILABLE_DOCS": ["spec.md", "plan.md", "data-model.md"]
}
```

**Error Handling**:
- Scripts return non-zero exit codes on error
- AI instructions: "If script fails, abort and instruct user to fix"

---

## Quality Gates & Validation

### Gate 1: Specification Quality (Specify Stage)

**Checklist**: `FEATURE_DIR/checklists/requirements.md`

**Validation Items**:
- [ ] No implementation details (languages, frameworks, APIs)
- [ ] Focused on user value and business needs
- [ ] Written for non-technical stakeholders
- [ ] All mandatory sections completed
- [ ] No [NEEDS CLARIFICATION] markers remain (or max 3)
- [ ] Requirements are testable and unambiguous
- [ ] Success criteria are measurable
- [ ] Success criteria are technology-agnostic
- [ ] All acceptance scenarios defined
- [ ] Edge cases identified
- [ ] Scope clearly bounded

**Enforcement**:
- Auto-generated checklist
- AI validates spec against checklist
- Max 3 fix iterations
- If still failing after 3 iterations: Document issues + warn user

---

### Gate 2: Constitution Compliance (Plan Stage)

**Check**: Before Phase 0 + After Phase 1

**Validation**:
```markdown
## Constitution Check

| Article | Status | Notes |
|---------|--------|-------|
| I. Library-First | ✓ PASS | ... |
| III. Test-First | ✓ PASS | ... |
| VII. Simplicity | ⚠ VIOLATION | Needs justification |
```

**Enforcement**:
- **PASS**: Proceed to next phase
- **VIOLATION with justification**: Document in Complexity Tracking → Proceed
- **VIOLATION without justification**: **ERROR** → Cannot proceed

---

### Gate 3: Checklist Completeness (Implement Stage)

**Check**: Before starting implementation

**Validation**:
```markdown
| Checklist      | Total | Completed | Incomplete | Status |
|----------------|-------|-----------|------------|--------|
| ux.md          | 12    | 12        | 0          | ✓ PASS |
| security.md    | 8     | 5         | 3          | ✗ FAIL |
```

**Enforcement**:
- **All PASS**: Auto-proceed to implementation
- **Any FAIL**: STOP + Ask user "Proceed anyway? (yes/no)"
  - "no" → Halt execution
  - "yes" → Continue (risk acknowledged)

---

### Gate 4: Task Format Validation (Tasks Stage)

**Check**: After generating tasks.md

**Validation**:
```markdown
✓ All tasks follow format: - [ ] [TID] [P?] [Story?] Description with file path
✓ Task IDs sequential (T001, T002, T003...)
✓ [P] markers only on parallelizable tasks
✓ [Story] labels on all user story phase tasks
✓ File paths in all descriptions
```

**Enforcement**:
- Report validation summary
- If format errors: Fix and re-validate
- Must pass before `/speckit.implement`

---

## Integration with PayPlan

### PayPlan Spec-Kit Usage Patterns

**Current PayPlan Conventions**:
- Features numbered: 014, 015, 016... (no short-name suffix yet)
- Spec directory: `specs/###-feature-name/`
- Artifacts: `spec.md`, `plan.md`, `tasks.md`, `data-model.md`, `research.md`
- Agent context: `CLAUDE.md` (auto-updated)

**Spec-Kit Alignment**:
- PayPlan follows specify → plan → tasks → implement workflow
- PayPlan specs include user stories with priorities (P1, P2, P3)
- PayPlan uses FR-### and SC-### numbering
- PayPlan tracks feature dependencies (see completed_features_index.md)
- PayPlan uses TDD approach (tests before implementation)

**Key Differences**:
- PayPlan: Feature IDs lack short-name suffix (014 vs 014-csv-import)
- PayPlan: No formal constitution yet (would benefit from one)
- PayPlan: Manual CLAUDE.md updates (spec-kit auto-updates)
- PayPlan: Uses custom scripts (not spec-kit standard scripts)

**Recommended Integration**:
1. Adopt spec-kit short-name convention: `020-user-settings` not just `020`
2. Create PayPlan constitution (define privacy-first, localStorage-only, WCAG 2.1 AA principles)
3. Use spec-kit's `update-agent-context.sh` for auto CLAUDE.md updates
4. Adopt spec-kit's checklist validation pattern
5. Follow spec-kit's user story organization (independent, testable stories)

---

## Quick Reference: Command Flow

```mermaid
graph TD
    A[User: Natural language description] --> B[/speckit.specify]
    B --> C{Has [NEEDS CLARIFICATION]?}
    C -->|Yes, high risk| D[/speckit.clarify]
    C -->|No, or low risk| E[/speckit.plan]
    D --> E
    E --> F{Constitution violations?}
    F -->|Unjustified| G[ERROR: Cannot proceed]
    F -->|Pass or justified| H[/speckit.tasks]
    H --> I{Checklists complete?}
    I -->|No| J[User: Proceed anyway?]
    J -->|No| K[STOP: Fix checklists]
    J -->|Yes| L[/speckit.implement]
    I -->|Yes| L
    L --> M[Implementation complete]
```

---

## Best Practices Summary

1. **Specify Stage**:
   - Limit [NEEDS CLARIFICATION] to 3 max
   - Make informed guesses for minor details
   - Prioritize user stories (P1, P2, P3)
   - Ensure stories are independently testable

2. **Clarify Stage**:
   - Run BEFORE planning if high ambiguity
   - Ask max 5 questions (one at a time)
   - Integrate answers incrementally
   - Skip for exploratory spikes (but warn of risk)

3. **Plan Stage**:
   - Resolve all "NEEDS CLARIFICATION" in research.md
   - Validate constitution compliance
   - Generate contracts for all user actions
   - Update agent context automatically

4. **Tasks Stage**:
   - Organize by user story (not layer)
   - Use strict checklist format
   - Mark parallel tasks [P]
   - Ensure MVP = just User Story 1

5. **Implement Stage**:
   - Check checklists first
   - Execute phase-by-phase
   - Mark completed tasks [X]
   - TDD: Tests before implementation

6. **Constitutional Principles**:
   - Enforce at every planning phase
   - Justify violations in Complexity Tracking
   - ERROR if unjustified violations
   - Re-check after design changes

7. **Quality Gates**:
   - Specification quality → before clarify/plan
   - Constitution compliance → before Phase 0 + after Phase 1
   - Checklist completeness → before implement
   - Task format → after task generation
