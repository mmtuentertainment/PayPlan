# Spec-Kit Methodology Reference

Complete guide to the specification-driven development methodology used in PayPlan.

## Overview

Spec-Kit is a documentation-first development methodology that emphasizes:
1. **Clarification before implementation** - Understand requirements deeply
2. **Artifact-driven planning** - Create comprehensive design documents
3. **Test-driven development** - Write tests before implementation
4. **Incremental delivery** - Break work into small, testable tasks

## Core Artifacts

### 1. spec.md (Feature Specification)
**Purpose**: Define WHAT the feature does and WHY it's needed

**Required Sections**:
- **Feature Branch**: Branch name (format: `###-feature-name`)
- **Clarifications**: Questions and answers from discovery
- **User Scenarios & Testing**: User stories with Gherkin acceptance scenarios
- **Requirements**: Functional requirements (FR-XXX format)
- **Success Criteria**: Measurable outcomes (SC-XXX format)
- **Dependencies**: External dependencies and prerequisites
- **Out of Scope**: Explicit non-goals

**Best Practices**:
- Use natural language, avoid technical implementation details
- Focus on user needs and business value
- Include concrete examples and edge cases
- Number requirements for traceability
- Make success criteria measurable

**Example Structure**:
```markdown
# Feature Specification: [Feature Name]

**Feature Branch**: `feature/XXX-feature-name`
**Created**: YYYY-MM-DD
**Status**: Draft | In Progress | Completed

## Clarifications

### Session YYYY-MM-DD
- Q: [Question] → A: [Answer]

## User Scenarios & Testing

### User Story 1 - [Story Title] (Priority: P0/P1/P2)

[User story description focusing on user needs and business value]

**Why this priority**: [Justification]

**Independent Test**: [How to test in isolation]

**Acceptance Scenarios**:
1. **Given** [initial context], **When** [action], **Then** [expected outcome]

## Requirements

### Functional Requirements
- **FR-001**: System MUST [requirement]
- **FR-002**: System SHOULD [requirement]

## Success Criteria

### Measurable Outcomes
- **SC-001**: [Measurable outcome with metrics]
```

### 2. plan.md (Implementation Plan)
**Purpose**: Define HOW the feature will be implemented

**Required Sections**:
- **Implementation Approach**: High-level strategy
- **Phases**: Breakdown of implementation stages
- **Technical Decisions**: Key architectural choices
- **Testing Strategy**: How the feature will be validated

**Best Practices**:
- Break work into phases (0-5 typical)
- Phase 0 is always planning/setup
- Each phase should be independently testable
- Document technical decisions with rationale
- Include testing approach for each phase

**Example Structure**:
```markdown
# Implementation Plan: [Feature Name]

## Implementation Approach

[High-level strategy and architecture]

## Phase 0 - Planning & Setup
**Goal**: [Phase objective]
**Deliverables**: [What gets created]
**Testing**: [How to verify]

## Phase 1 - [Phase Name]
[Repeat for each phase]

## Technical Decisions

### Decision 1: [Decision Title]
**Problem**: [What needs deciding]
**Options**: [Alternatives considered]
**Choice**: [Selected approach]
**Rationale**: [Why this choice]
```

### 3. tasks.md (Task Breakdown)
**Purpose**: Define granular, actionable tasks for implementation

**Required Sections**:
- **Task List**: Numbered tasks with acceptance criteria
- **Dependencies**: Task ordering and prerequisites
- **Estimates**: Time estimates (optional)

**Best Practices**:
- Each task should be <2 hours of work
- Use T-XXX format for task IDs
- Include "Done when" acceptance criteria
- Order by dependencies
- Map tasks to FRs and user stories

**Example Structure**:
```markdown
# Task Breakdown: [Feature Name]

## Phase 0 - Planning

### T-001: [Task Title]
**Mapped to**: FR-001, User Story 1
**Dependencies**: None
**Estimate**: 30 minutes

**Description**: [What needs to be done]

**Done When**:
- [ ] [Specific completion criterion]
- [ ] [Test passes]
```

### 4. data-model.md (Data Model)
**Purpose**: Define data structures and state management

**Required Sections**:
- **Entities**: Core data types
- **Relationships**: How entities relate
- **Storage**: Where data lives (localStorage, memory, etc.)
- **Validation**: Data constraints

### 5. research.md (Research & Decisions)
**Purpose**: Document research findings and technical decisions

**Content**:
- Library evaluations
- Best practice research
- Architectural decision records
- Performance considerations
- Security considerations

### 6. quickstart.md (Manual Testing Guide)
**Purpose**: Provide step-by-step manual testing procedures

**Content**:
- Setup instructions
- Test scenarios
- Expected outcomes
- Edge cases to verify

### 7. contracts/ (Component Contracts)
**Purpose**: Define interfaces and behavioral contracts

**Content**:
- Component APIs
- Input/output specifications
- Side effects
- Test assertions

### 8. checklists/ (Validation Checklists)
**Purpose**: Provide verification checklists

**Content**:
- Requirements checklist
- Testing checklist
- Accessibility checklist
- Security checklist

## Workflow

### Step 1: Clarification (/speckit.clarify)
- Read user's feature description
- Identify underspecified areas
- Ask 3-5 targeted questions
- Update spec.md with answers

### Step 2: Specification (/speckit.specify)
- Create complete spec.md
- Define user stories with priorities
- Document functional requirements
- Set measurable success criteria
- Clarify dependencies and scope

### Step 3: Planning (/speckit.plan)
- Create plan.md with implementation phases
- Create data-model.md with entities
- Create research.md with technical decisions
- Create contracts/ for component specifications
- Create quickstart.md for manual testing

### Step 4: Task Generation (/speckit.tasks)
- Break plan into atomic tasks
- Map tasks to requirements
- Define acceptance criteria
- Establish dependency order

### Step 5: Analysis (/speckit.analyze)
- Validate cross-artifact consistency
- Check requirement coverage
- Verify task completeness
- Identify gaps

### Step 6: Implementation (/speckit.implement)
- Execute tasks in order
- Write tests first (TDD)
- Implement functionality
- Verify acceptance criteria
- Update artifacts as needed

## Naming Conventions

### Feature IDs
Format: `###-feature-name`

Examples:
- `014-build-a-csv` - Simple feature
- `016-payment-archive` - Core feature
- `019-pii-pattern-refinement` - Enhancement

### Branch Names
Format: `feature/###-feature-name`

Example: `feature/019-pii-pattern-refinement`

### Requirement IDs
- **FR-XXX**: Functional Requirements
- **NFR-XXX**: Non-Functional Requirements
- **SC-XXX**: Success Criteria
- **T-XXX**: Tasks

### Priority Levels
- **P0**: Critical - Blocks core functionality
- **P1**: High - Important for feature completeness
- **P2**: Medium - Enhances user experience
- **P3**: Low - Nice to have

## Testing Strategy

### Test-Driven Development (TDD)
1. Write test for acceptance criterion
2. Run test (should fail)
3. Implement minimum code to pass
4. Refactor
5. Repeat

### Test Levels
- **Unit Tests**: Test individual functions/components
- **Integration Tests**: Test component interactions
- **Business Tests**: Test complete user scenarios
- **Performance Tests**: Validate performance targets

### Test Organization
```
backend/tests/
  unit/           # Unit tests for individual modules
  integration/    # Integration tests across modules
  business/       # Business logic and scenario tests

frontend/src/
  components/
    __tests__/    # Component tests
```

## Artifact Maintenance

### When to Update
- **spec.md**: When requirements change or are clarified
- **plan.md**: When implementation approach changes
- **tasks.md**: As tasks are completed or new tasks discovered
- **research.md**: When new decisions are made
- **data-model.md**: When entities or storage changes

### Version Control
- Commit planning artifacts before implementation
- Reference feature ID in all commits
- Include artifact updates in feature PRs
- Tag completion with COMPLETE.md or similar marker

## Common Patterns

### Feature Dependencies
Document in spec.md Dependencies section:
```markdown
## Dependencies

- **Dependency 1**: Feature 018 (Technical Debt Cleanup) -
  provides PiiSanitizer module that this feature refines
```

### Phased Implementation
```markdown
## Phase 0 - Planning & Setup (Day 1)
## Phase 1 - Core Functionality (Days 2-3)
## Phase 2 - Testing & Validation (Day 4)
## Phase 3 - Documentation & Polish (Day 5)
```

### Cross-Referencing
- In tasks.md: `**Mapped to**: FR-001, User Story 1`
- In plan.md: `This phase implements FR-001 through FR-005`
- In tests: `// Test for FR-001: System MUST implement word boundaries`

## Quality Checklist

### Before Starting Implementation
- [ ] spec.md has all required sections
- [ ] All user stories have priorities
- [ ] Functional requirements are numbered
- [ ] Success criteria are measurable
- [ ] plan.md breaks work into phases
- [ ] tasks.md has atomic tasks with acceptance criteria
- [ ] All artifacts cross-reference each other

### During Implementation
- [ ] Tests written before code
- [ ] Each task verified against acceptance criteria
- [ ] Artifacts updated as discoveries made
- [ ] Commits reference feature ID

### Before Marking Complete
- [ ] All tasks completed
- [ ] All tests passing
- [ ] All success criteria met
- [ ] Documentation updated
- [ ] CLAUDE.md updated with technologies and conventions
