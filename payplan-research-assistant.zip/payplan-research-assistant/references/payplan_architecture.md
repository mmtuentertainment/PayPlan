# PayPlan Architecture Reference

Comprehensive guide to PayPlan's architecture, design patterns, and technical stack.

## Project Overview

**PayPlan** is a privacy-first Buy Now, Pay Later (BNPL) payment planning tool that helps users:
- Import payment schedules from CSV or email
- Visualize payment timelines
- Detect financial risks
- Archive payment plans
- Maintain privacy (no authentication, local-only storage)

## Technology Stack

### Frontend
- **React 19.1.1**: UI framework
- **TypeScript 5.8.3**: Type-safe development
- **React Router 7.9.3**: Client-side routing
- **Radix UI**: Accessible component primitives
- **Tailwind CSS 4.1.13**: Utility-first styling
- **Vitest 3.2.4**: Unit and component testing

### Backend
- **Node.js 20.x**: Server runtime
- **TypeScript 5.8.3**: Type definitions
- **Zod 4.1.11**: Runtime validation
- **PapaParse 5.5.3**: CSV parsing/generation
- **uuid 13.0.0**: Unique ID generation
- **Vitest**: Backend testing

### Storage
- **localStorage**: Primary storage (privacy-first, no server)
- **Two-tier architecture**: Index + individual items for performance

## Project Structure

```
PayPlan/
├── frontend/
│   ├── src/
│   │   ├── components/        # React components
│   │   │   ├── archive/       # Archive-related components
│   │   │   ├── navigation/    # Navigation components
│   │   │   └── ...
│   │   ├── lib/               # Business logic
│   │   │   ├── archive/       # Archive storage and logic
│   │   │   ├── security/      # PII sanitization, etc.
│   │   │   └── ...
│   │   ├── hooks/             # Custom React hooks
│   │   ├── pages/             # Page components
│   │   ├── contexts/          # React contexts
│   │   └── types/             # TypeScript types
│   └── dist/                  # Build output
├── backend/
│   ├── src/
│   │   ├── lib/               # Backend libraries
│   │   │   ├── security/      # Security utilities
│   │   │   │   └── PiiSanitizer.js
│   │   │   └── ...
│   │   └── ...
│   └── tests/
│       ├── unit/              # Unit tests
│       ├── integration/       # Integration tests
│       └── business/          # Business logic tests
├── specs/                     # Feature specifications
│   ├── 014-build-a-csv/
│   ├── 015-build-a-payment/
│   ├── 016-payment-archive/
│   ├── 017-navigation-system/
│   ├── 018-technical-debt-cleanup/
│   ├── 019-pii-pattern-refinement/
│   └── ...
└── CLAUDE.md                  # Development guidelines

```

## Core Architectural Patterns

### 1. Privacy-First Design

**Principle**: No user data leaves the browser

**Implementation**:
- All data stored in `localStorage`
- No authentication or user accounts
- No server-side persistence
- PII sanitization in logs and errors

**Key Files**:
- `backend/src/lib/security/PiiSanitizer.js` - Sanitizes PII from logs
- Storage implementations use localStorage only

### 2. Two-Tier Storage Architecture (Feature 016)

**Problem**: Loading 50 archived payment plans from localStorage is slow

**Solution**: Separate index from content

**Implementation**:
```
localStorage:
  'archives_index' -> {
    archives: [
      { id, name, date, metadata }
    ],
    metadata: { count, lastUpdate }
  }

  'archive_[id]' -> {
    id,
    name,
    payments: [...],
    fullData: {...}
  }
```

**Performance Targets**:
- Index loading: <100ms
- Individual archive: <50ms
- CSV export: <3s

**Key Files**:
- `frontend/src/lib/archive/ArchiveStorage.ts`
- `frontend/src/lib/archive/ArchiveManager.ts`

### 3. Component-Based Architecture

**Pattern**: Isolated, reusable components

**Structure**:
```
ComponentName/
├── ComponentName.tsx         # Main component
├── ComponentName.test.tsx    # Tests
├── ComponentName.types.ts    # Type definitions
└── index.ts                  # Public exports
```

**Example**: Archive components
- `ArchiveList` - Displays archive index
- `ArchiveDetail` - Shows individual archive
- `ArchiveCard` - Single archive item

### 4. Custom Hooks Pattern

**Purpose**: Encapsulate reusable logic

**Common Hooks**:
- `useArchive()` - Archive CRUD operations
- `usePayment()` - Payment data management
- `useNavigation()` - Route navigation helpers

**Pattern**:
```typescript
export function useArchive() {
  const [archives, setArchives] = useState<Archive[]>([]);
  const [loading, setLoading] = useState(false);

  const loadArchives = useCallback(async () => {
    setLoading(true);
    try {
      const data = await ArchiveStorage.loadIndex();
      setArchives(data);
    } finally {
      setLoading(false);
    }
  }, []);

  return { archives, loading, loadArchives };
}
```

### 5. Context-Based State Management

**Pattern**: React Context for global state

**Key Contexts**:
- `PaymentContext` - Current payment plan state
- `NavigationContext` - Navigation state
- `ErrorContext` - Error handling state

**Implementation**:
```typescript
export const PaymentContext = createContext<PaymentContextType>(null);

export function PaymentProvider({ children }) {
  const [payment, setPayment] = useState<Payment | null>(null);

  const value = useMemo(() => ({
    payment,
    setPayment,
    clearPayment: () => setPayment(null)
  }), [payment]);

  return (
    <PaymentContext.Provider value={value}>
      {children}
    </PaymentContext.Provider>
  );
}
```

### 6. Error Boundary Pattern

**Purpose**: Graceful error handling

**Implementation**:
```typescript
class ErrorBoundary extends React.Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    // Log with PII sanitization
    logger.error(sanitize({ error, errorInfo }));
  }

  render() {
    if (this.state.hasError) {
      return <ErrorFallback error={this.state.error} />;
    }
    return this.props.children;
  }
}
```

### 7. PII Sanitization (Feature 018 & 019)

**Purpose**: Remove sensitive data from logs/errors

**Pattern**: Field name pattern matching (not value inspection)

**Implementation**:
```javascript
// PiiSanitizer.js
const PII_PATTERNS = [
  'email', 'phone', 'address', 'ssn', 'name',
  'password', 'token', 'apiKey', 'secret', 'auth'
];

function sanitize(obj) {
  if (typeof obj !== 'object') return obj;

  const result = {};
  for (const [key, value] of Object.entries(obj)) {
    if (shouldSanitizeField(key)) {
      continue; // Remove field
    }
    result[key] = sanitize(value); // Recursive
  }
  return result;
}

function shouldSanitizeField(fieldName) {
  const lower = fieldName.toLowerCase();
  return PII_PATTERNS.some(pattern => {
    // Word boundary matching (Feature 019)
    const regex = new RegExp(`(^|_|[A-Z])${pattern}(_|[A-Z]|$)`, 'i');
    return regex.test(fieldName);
  });
}
```

**Key Improvements (Feature 019)**:
- Word boundary matching to prevent false positives (`filename` not sanitized)
- Authentication secret prioritization (password, token checked first)
- Scoped IP detection (`ipAddress` sanitized, `zip` not sanitized)

### 8. Validation with Zod

**Pattern**: Runtime type validation

**Example**:
```typescript
import { z } from 'zod';

const PaymentSchema = z.object({
  id: z.string().uuid(),
  amount: z.number().positive(),
  date: z.string().datetime(),
  description: z.string().min(1).max(255)
});

type Payment = z.infer<typeof PaymentSchema>;

function validatePayment(data: unknown): Payment {
  return PaymentSchema.parse(data);
}
```

### 9. CSV Import/Export (Feature 014)

**Pattern**: Structured CSV processing

**Import**:
```typescript
import Papa from 'papaparse';

function importCSV(file: File): Promise<Payment[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      complete: (results) => {
        const validated = results.data.map(validatePayment);
        resolve(validated);
      },
      error: reject
    });
  });
}
```

**Export**:
```typescript
function exportCSV(payments: Payment[]): string {
  return Papa.unparse(payments, {
    columns: ['id', 'date', 'amount', 'description'],
    header: true
  });
}
```

### 10. Navigation with React Router (Feature 017)

**Pattern**: Declarative routing

**Implementation**:
```typescript
import { createBrowserRouter } from 'react-router-dom';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'archives', element: <ArchiveListPage /> },
      { path: 'archives/:id', element: <ArchiveDetailPage /> },
      { path: 'payment/new', element: <NewPaymentPage /> }
    ]
  }
]);
```

## Testing Strategy

### Unit Tests
**Purpose**: Test individual functions/modules

**Pattern**:
```typescript
import { describe, it, expect } from 'vitest';

describe('PiiSanitizer', () => {
  it('should remove password fields', () => {
    const input = { username: 'user', password: 'secret' };
    const output = sanitize(input);
    expect(output).toEqual({ username: 'user' });
  });
});
```

### Integration Tests
**Purpose**: Test component interactions

**Pattern**:
```typescript
describe('Archive System', () => {
  it('should load and display archives', async () => {
    const archives = await ArchiveStorage.loadIndex();
    render(<ArchiveList archives={archives} />);
    expect(screen.getByText('My Archive')).toBeInTheDocument();
  });
});
```

### Business Tests
**Purpose**: Test complete user scenarios

**Pattern**:
```typescript
describe('Payment Archive Workflow', () => {
  it('should create, save, and load archive', async () => {
    // Create payment
    const payment = createPayment({ amount: 100 });

    // Save as archive
    const archiveId = await saveArchive(payment);

    // Load from storage
    const loaded = await loadArchive(archiveId);

    expect(loaded.payment).toEqual(payment);
  });
});
```

## Performance Considerations

### localStorage Optimization
- **Index-based loading**: Load metadata first, content on demand
- **Lazy loading**: Only load visible archives
- **Debounced saves**: Batch localStorage writes

### Bundle Size Optimization
- **Code splitting**: Route-based chunks
- **Tree shaking**: Remove unused code
- **Vendor chunking**: Separate React/libraries

**Targets (Feature 018)**:
- Initial bundle: <200KB gzipped
- Route chunks: <50KB each
- Time to Interactive: <3s on 3G

### Rendering Optimization
- **React.memo**: Memoize expensive components
- **useMemo/useCallback**: Prevent unnecessary recalculations
- **Virtualization**: For long lists (archives, payments)

## Accessibility (WCAG 2.1 AA)

### Requirements
- **Keyboard navigation**: All interactive elements accessible via keyboard
- **Screen reader support**: ARIA labels and roles
- **Color contrast**: 4.5:1 minimum for text
- **Focus indicators**: Visible focus states

### Implementation
```tsx
<button
  aria-label="Archive payment plan"
  onClick={handleArchive}
  className="focus:ring-2 focus:ring-blue-500"
>
  Archive
</button>
```

## Security

### PII Protection (Feature 018 & 019)
- **Field-based sanitization**: Remove sensitive fields from logs
- **No value inspection**: Privacy-preserving pattern matching
- **Authentication secret detection**: Prioritize security-critical fields

### Input Validation
- **Zod schemas**: Runtime type checking
- **Sanitization**: Remove dangerous characters
- **Size limits**: Prevent DoS via large inputs

### Error Handling
- **Sanitized errors**: PII removed before logging
- **Error boundaries**: Prevent app crashes
- **Graceful degradation**: Fallback UI on errors

## Common Development Workflows

### Adding a New Feature
1. Create feature spec in `specs/###-feature-name/`
2. Write spec.md with requirements
3. Create plan.md with implementation approach
4. Break into tasks in tasks.md
5. Implement with TDD (tests first)
6. Update CLAUDE.md with new patterns

### Modifying Existing Features
1. Read existing spec in `specs/###-feature-name/`
2. Understand requirements and architecture
3. Check for dependent features
4. Write tests for changes
5. Implement changes
6. Update relevant specs

### Debugging Issues
1. Check error logs (sanitized)
2. Review feature spec for expected behavior
3. Check git history for related changes
4. Run tests to isolate issue
5. Fix and add regression test

## Key Files Quick Reference

### Core Business Logic
- `backend/src/lib/security/PiiSanitizer.js` - PII sanitization
- `frontend/src/lib/archive/ArchiveStorage.ts` - Archive persistence
- `frontend/src/lib/archive/ArchiveManager.ts` - Archive operations

### Main Components
- `frontend/src/components/archive/ArchiveList.tsx` - Archive list view
- `frontend/src/components/navigation/NavigationHeader.tsx` - App navigation
- `frontend/src/components/payment/PaymentForm.tsx` - Payment input

### Testing
- `backend/tests/unit/PiiSanitizer.test.ts` - PII tests
- `backend/tests/business/ArchiveWorkflow.test.ts` - Archive scenarios

### Configuration
- `CLAUDE.md` - Development guidelines (auto-updated)
- `package.json` - Dependencies and scripts
- `vite.config.ts` - Frontend build config
- `vitest.config.ts` - Test configuration

## Feature Lineage

**Completed Features** (in order):
1. **014-build-a-csv** - CSV import/export
2. **015-build-a-payment** - Payment data structure
3. **016-payment-archive** - Archive system with two-tier storage
4. **017-navigation-system** - React Router integration
5. **018-technical-debt-cleanup** - Performance, security, testing improvements
6. **019-pii-pattern-refinement** - Enhanced PII detection

**Dependencies**:
- 019 depends on 018 (refines PiiSanitizer)
- 018 depends on 014-017 (consolidates all features)
- 016 depends on 015 (archives payments)
- 015 depends on 014 (uses CSV export)
