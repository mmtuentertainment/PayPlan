---
name: payplan-research-assistant
description: Comprehensive research and analysis tool for the PayPlan project with intelligent next-feature suggestions. Use this skill proactively when working on PayPlan to understand feature lineage, discover code patterns, validate spec artifacts, search git history, suggest next features to build, and maintain consistency with established conventions. Triggers on PayPlan-specific questions about architecture, past features, testing patterns, or when planning what to build next.
---

# PayPlan Research Assistant

Intelligent research and analysis tool specifically designed for the PayPlan project. Provides deep insights into feature evolution, architectural patterns, spec-kit compliance, and development conventions to accelerate both past feature understanding and future feature development.

## When to Use This Skill

Use this skill proactively in the following scenarios:

### Planning & Discovery
- Before starting a new feature (understand what exists, what patterns to follow)
- When the user asks about PayPlan architecture or design decisions
- When exploring how existing features work together
- When validating spec artifacts for consistency

### Implementation
- When looking for examples of how to implement a specific pattern
- When understanding which technologies or approaches to use
- When searching for where specific functionality is implemented
- When checking test coverage and testing conventions

### Code Review & Maintenance
- When validating that a feature follows established patterns
- When understanding the history of a specific file or feature
- When checking for cross-feature dependencies
- When analyzing technical debt or refactoring opportunities

### Examples of Triggering Queries
- "How does PayPlan handle PII sanitization?"
- "What features depend on the archive system?"
- "Show me examples of React hooks in the codebase"
- "Validate the spec artifacts for feature 019"
- "What testing patterns does PayPlan use?"
- "Find all commits related to performance optimization"

## Core Capabilities

This skill provides **eight powerful analysis tools** via Python scripts, plus comprehensive reference documentation for immediate context loading.

### 🆕 ENHANCED CAPABILITIES (Ultimate Edition)

### 1. Feature Lineage Analysis

**Purpose**: Trace feature dependencies, evolution, and relationships

**Usage**:
```bash
python scripts/analyze_feature_lineage.py --feature 019-pii-pattern-refinement
```

**What it provides**:
- Complete dependency graph (ancestors and descendants)
- Feature status (completed/in-progress/planned)
- Artifacts list (spec.md, plan.md, contracts, etc.)
- Related git commits
- Cross-feature relationships

**When to use**:
- Understanding feature history
- Planning new features that build on existing ones
- Identifying which features will be impacted by changes
- Generating feature progression reports

### 2. Code Pattern Discovery

**Purpose**: Find architectural patterns, conventions, and best practices in the codebase

**Usage**:
```bash
python scripts/find_code_patterns.py --pattern react_hooks
python scripts/find_code_patterns.py --category testing
```

**What it searches for**:
- React patterns (hooks, context, components, memoization)
- Storage patterns (localStorage, archive system)
- Validation patterns (Zod schemas, error handling)
- Security patterns (PII sanitization)
- Testing patterns (Vitest, assertions, mocks)
- Performance patterns (lazy loading, optimization)
- Accessibility patterns (ARIA, WCAG compliance)
- TypeScript patterns (types, interfaces, generics)

**When to use**:
- Finding examples of how to implement a specific pattern
- Understanding code organization conventions
- Discovering testing approaches
- Learning accessibility implementation

### 3. Spec Artifact Validation

**Purpose**: Validate consistency across spec.md, plan.md, tasks.md and other artifacts

**Usage**:
```bash
python scripts/validate_spec_artifacts.py specs/019-pii-pattern-refinement
```

**What it checks**:
- Required artifacts present (spec.md, plan.md, tasks.md)
- Spec structure (User Stories, Requirements, Success Criteria)
- Plan organization (phases, technical decisions)
- Task format (T-XXX IDs, acceptance criteria)
- Cross-references (FRs referenced in plan/tasks, user stories mapped)

**When to use**:
- Before starting implementation (ensure planning is complete)
- During spec-kit workflow (validate after /speckit.plan)
- Before marking feature complete (verify all artifacts consistent)
- When troubleshooting missing or incomplete specifications

### 4. Git History Search

**Purpose**: Analyze commits, PRs, and feature progression through git history

**Usage**:
```bash
python scripts/search_git_history.py 019-pii-pattern-refinement --type feature
python scripts/search_git_history.py "PII sanitization" --type pattern
python scripts/search_git_history.py backend/src/lib/security/PiiSanitizer.js --type file
```

**What it provides**:
- All commits related to a feature
- PR numbers extracted from commit messages
- Commit statistics (files changed, insertions, deletions)
- File history (who changed what and when)
- Pattern-based commit search

**When to use**:
- Understanding why code was written a certain way
- Finding related PRs and discussions
- Tracing feature implementation timeline
- Debugging issues by reviewing change history

### 5. Semantic Code Search 🆕

**Purpose**: Understand code by intent, not just text matching. Goes beyond regex to analyze what code does.

**Usage**:
```bash
# Search by intent
python scripts/semantic_code_search.py --intent "manipulate payment dates"
python scripts/semantic_code_search.py --intent "handle network errors"

# Detect anti-patterns
python scripts/semantic_code_search.py --anti-patterns

# Find related code
python scripts/semantic_code_search.py --related "file.ts:42"

# Trace data flow
python scripts/semantic_code_search.py --data-flow "paymentAmount:PaymentForm.tsx"
```

**What it provides**:
- **Intent-based search**: "handle errors" finds try/catch blocks, not just literal text
- **Anti-pattern detection**: Large functions (>100 lines), deep nesting (>4 levels), magic numbers, missing error handling
- **Code relationships**: Find callers, callees, and related data structures
- **Data flow tracing**: See where variables are defined, modified, and read
- **Confidence scoring**: 0-100% confidence on semantic matches

**Examples**:
- "Find code that manipulates payment dates" → Finds date arithmetic even if not named "paymentDate"
- "Detect anti-patterns" → "Function calculateTotal is 150 lines (>100)"
- "Find code that validates user input" → Finds Zod schemas and validation logic

**When to use**:
- Understanding unfamiliar code by what it does
- Finding all error handling patterns
- Detecting code quality issues
- Tracing data transformations

### 6. GitHub Integration 🆕

**Purpose**: Pull PRs, issues, CI status, and review comments from GitHub

**Usage**:
```bash
# Get all PRs for a feature
python scripts/github_integration.py 019-pii-pattern-refinement

# Get only PRs
python scripts/github_integration.py 019 --prs-only

# Get CI status
python scripts/github_integration.py --ci-status

# Get PR details
python scripts/github_integration.py 019 --format json
```

**What it provides**:
- **Feature PRs**: All pull requests mentioning feature ID
- **Review comments**: CodeRabbit, human reviews, approval status
- **CI/CD status**: Passing/failing checks, workflow runs, success rate
- **Issues**: GitHub issues and Linear references (MMT-48, etc.)
- **PR metadata**: Labels, authors, merge status, created/merged dates

**Examples**:
- "Show me all PRs for Feature 019" → 3 PRs found, 2 merged, 1 with failing CI
- "What's the CI success rate?" → 80% (8/10 recent runs passing)
- "Find Linear issues for Feature 018" → MMT-48 mentioned in commit abc123

**When to use**:
- Understanding feature implementation history
- Checking CI/CD health
- Finding related discussions and reviews
- Tracking Linear issue references

### 7. Spec-Kit AI Assistant 🆕

**Purpose**: Auto-generate spec artifacts, suggest requirements, estimate complexity

**Usage**:
```bash
# Generate spec template
python scripts/speckit_ai_assistant.py --generate-spec "020-new-feature:User Settings:Allow users to customize preferences"

# Suggest requirements
python scripts/speckit_ai_assistant.py --suggest-requirements "Build a payment scheduler"

# Estimate complexity
python scripts/speckit_ai_assistant.py --estimate-complexity "Add real-time sync across tabs"

# Find missing artifacts
python scripts/speckit_ai_assistant.py --missing-artifacts 019-pii-pattern-refinement
```

**What it provides**:
- **Auto-generated spec.md**: Complete template from natural language description
- **Requirement suggestions**: FRs based on similar features (with confidence scores)
- **Complexity estimation**: Predicted days/score based on similar features
- **Task generation**: Auto-break plan.md into atomic tasks
- **Missing artifact detection**: Which spec-kit files are missing

**Examples**:
- "Generate spec for payment scheduler" → Creates spec.md with user stories, FRs, success criteria
- "Suggest requirements for localStorage feature" → "FR-001: System MUST persist data (90% confidence, based on Feature 016)"
- "Estimate complexity of real-time sync" → 8/10 complexity, 5-7 days, based on Feature 017

**When to use**:
- Kickstarting new feature specs
- Getting requirement ideas from past patterns
- Estimating feature scope/duration
- Ensuring spec completeness

### 8. Feature Strategist 🆕🔥

**Purpose**: **Intelligently suggest the next practical feature** by analyzing codebase, planning docs, project history, and industry trends

**Usage**:
```bash
# Get top 5 feature suggestions
python scripts/feature_strategist.py --top 5

# Include industry research
python scripts/feature_strategist.py --top 5 --research

# Output to file
python scripts/feature_strategist.py --top 10 --format markdown --output /tmp/suggestions.md
```

**What it analyzes**:
- **Feature Progression**: Logical next steps based on completed features (e.g., import+export → bulk operations)
- **Codebase Gaps**: Missing patterns (error boundaries, loading states, ARIA labels)
- **User Pain Points**: Extracted from commit messages and code comments
- **Technical Debt**: Test coverage, outdated dependencies, refactoring opportunities
- **Constitution Opportunities**: Missing constitution, compliance improvements
- **TODO Comments**: Grouped by theme (feature, refactor, bug, performance, accessibility)
- **Industry Trends** (with `--research`): Best practices from similar projects (Mint, YNAB, etc.)
- **Linear Issues** (with `--with-linear`) 🆕: User-requested features and enhancements from Linear backlog

**What it provides**:
- **Priority Score** (0-100): How important/valuable is this feature
- **Category**: New Feature, Enhancement, Technical Debt, User Request
- **Effort Estimate**: Small (1-2 days), Medium (3-5 days), Large (1-2 weeks)
- **User Value**: Clear explanation of user benefit
- **Rationale**: Why this feature makes sense now
- **Dependencies**: Which existing features this builds on
- **Constitution Alignment**: Does it align with project principles?
- **Evidence**: Supporting data (patterns, commit counts, similar apps, etc.)

**Example Output**:
```markdown
## 1. Payment Analytics Dashboard
**Priority Score**: 85.0/100 | **Category**: New Feature
**Effort**: Large (1-2 weeks)

### Description
Visual dashboard with spending trends, category breakdowns, and payment history charts

### Rationale
Navigation system in place. Users need overview/insights page.

### User Value
Understand spending patterns and financial health at a glance

### Dependencies
- 017-navigation-system
- 015-payment-system

### Evidence
- Pattern: navigation → dashboard landing page
- Missing component: No overview/home page
```

**Analysis Patterns**:
1. **Import + Export → Bulk Operations**: If you have CSV import/export, suggest bulk editing/deletion
2. **Preferences → Notifications**: User settings naturally extend to notification preferences
3. **Archive → Search**: Archive systems always need search/filter capabilities
4. **PII + Export → Privacy Controls**: Let users control what PII to include in exports
5. **Navigation → Dashboard**: Navigation system needs a landing page with insights
6. **Test Coverage < 50% → Test Improvement**: Technical debt opportunity
7. **3+ TODO comments on same theme → Address TODOs**: Refactoring opportunity

**When to use**:
- **Planning next sprint**: "What should we build next?"
- **Prioritization**: "Which features give most user value?"
- **Gap analysis**: "What's missing from our app?"
- **Technical debt**: "What should we refactor?"
- **Constitution**: "Should we create a project constitution?"

**AI Agent Enhancement**:
When `--research` flag is used, the AI agent calling this script should enhance suggestions with WebSearch:
- "best payment tracking app features 2025"
- "personal finance app trends"
- "budget app must-have features"
- Similar project analysis (Mint, YNAB, PocketGuard, Copilot)

When `--with-linear` flag is used, the AI agent should:
1. Call `mcp__linear__list_issues(team="MMTU Entertainment", query="payplan")`
2. Filter for Backlog/Todo status with High/Medium priority
3. Convert Linear issues to FeatureSuggestion objects with proper scoring:
   - Priority: Urgent=95, High=85, Medium=75, Low=50
   - Category: "User Request" (from Linear)
   - Dependencies: Extracted from issue description
   - Evidence: Include Linear issue ID (MMT-XX), URL, and priority

**Real PayPlan Example**:
```bash
$ python scripts/feature_strategist.py --top 3

# Returns:
# 1. Payment Analytics Dashboard (85/100) - Large effort
# 2. Payment Reminders & Notifications (82/100) - Medium effort
# 3. Advanced Search & Filtering (78/100) - Medium effort
```

### 9. Web Research Engine 🆕🔥🌐

**Purpose**: **Multi-format data fetching and competitor analysis** using Puppeteer, WebSearch, and WebFetch to research industry trends, competitor features, user reviews, and technical documentation

**Usage**:
```bash
# Competitor feature analysis
python scripts/web_research_engine.py --competitor-analysis "mint,ynab,pocketguard"

# Industry trend research
python scripts/web_research_engine.py --industry-trends "budget app features"

# User review mining
python scripts/web_research_engine.py --user-reviews "mint,ynab,copilot"

# Technical documentation research
python scripts/web_research_engine.py --tech-docs "supabase,react,vercel"

# Combined research plan
python scripts/web_research_engine.py \
  --competitor-analysis "mint,ynab" \
  --industry-trends "personal finance 2025" \
  --format markdown --output /tmp/research-plan.md
```

**What it generates**:
- **Research Plans**: Structured task lists for AI agent execution
- **Competitor Analysis Tasks**: Puppeteer scraping of feature pages, pricing, screenshots
- **Trend Analysis Tasks**: WebSearch queries, article fetching, Product Hunt research
- **Review Mining Tasks**: Reddit discussions, App Store reviews, user complaints
- **Tech Doc Tasks**: API documentation, pricing pages, integration guides

**Research Plan Structure**:
```markdown
# 🔬 Research Plan: Competitor Analysis

**Total Tasks**: 9
**Expected Insights**:
- Feature gaps (what competitors have that PayPlan doesn't)
- Feature advantages (what PayPlan has that competitors don't)
- Pricing models for premium features
- UI/UX patterns to consider

## Task 1: Screenshot Mint features page
**Tool Required**: `mcp__puppeteer__puppeteer_screenshot`
**URL**: https://mint.intuit.com/features
**Priority**: 7/10

## Task 2: Extract Mint feature list
**Tool Required**: `mcp__web-browser__browse_webpage`
**URL**: https://mint.intuit.com/features
**Selectors**:
{
  "features": "h2, h3, .feature-title",
  "descriptions": "p, .feature-description"
}
**Priority**: 10/10
```

**Available MCP Tools for Execution**:
1. **mcp__puppeteer__puppeteer_navigate** - Navigate to URLs
2. **mcp__puppeteer__puppeteer_screenshot** - Screenshot pages
3. **mcp__puppeteer__puppeteer_evaluate** - Run JavaScript
4. **mcp__web-browser__browse_webpage** - Extract with CSS selectors
5. **WebSearch** - Search for articles and trends
6. **WebFetch** - Fetch article content
7. **mcp__fetch__fetch** - Simple URL fetching

**Competitor Sites Configured**:
- **Mint**: https://mint.intuit.com/features
- **YNAB**: https://www.ynab.com/features
- **PocketGuard**: https://pocketguard.com/features
- **Copilot**: https://copilot.money/features
- **Monarch Money**: https://www.monarchmoney.com/features

**Research Types**:

1. **Competitor Feature Analysis**:
   - Scrape feature pages with Puppeteer
   - Extract feature lists and descriptions
   - Compare pricing tiers
   - Screenshot UI for visual reference
   - Identify gaps and advantages

2. **Industry Trend Analysis**:
   - WebSearch for "budget app features 2025 trends"
   - Fetch top blog articles
   - Search Product Hunt for new launches
   - Extract emerging patterns
   - Identify market opportunities

3. **User Review Mining**:
   - Search Reddit for "r/personalfinance" discussions
   - Extract App Store review complaints
   - Find most-requested features
   - Identify common pain points
   - Discover deal-breaker features

4. **Technical Documentation**:
   - Fetch Supabase/React/Vercel docs
   - Extract key capabilities
   - Research pricing and limits
   - Find integration patterns
   - Identify breaking changes

**AI Agent Workflow**:
1. User asks: "What features do competitors have that we don't?"
2. AI runs: `python scripts/web_research_engine.py --competitor-analysis "mint,ynab"`
3. Script outputs research plan with 15 tasks
4. AI executes each task using MCP tools (Puppeteer, WebSearch, WebFetch)
5. AI synthesizes findings into actionable feature suggestions
6. Results feed into Feature Strategist for prioritization

**Example Output (After AI Execution)**:
```markdown
## Competitor Feature Analysis Results

### Features PayPlan Lacks:
1. **Budget Goals** (Mint, YNAB, PocketGuard) - Set monthly limits per category
2. **Bill Negotiation** (Mint, Copilot) - Auto-negotiate bills to save money
3. **Investment Tracking** (Mint, Monarch) - Track portfolio performance
4. **Credit Score Monitoring** (Mint) - Free credit score updates

### Features PayPlan Has (Competitive Advantages):
1. **Privacy-First** - No server storage, 100% local
2. **No Authentication Required** - Works immediately
3. **PII Sanitization** - Built-in privacy protection

### Pricing Models:
- Mint: Free (ad-supported)
- YNAB: $14.99/month or $99/year
- PocketGuard: $12.99/month or $74.99/year
- Copilot: $2.99/month (iOS only)
```

**When to use**:
- **Before planning features**: "What do competitors offer?"
- **Market research**: "What's trending in budget apps?"
- **User insights**: "What do users complain about?"
- **Tech decisions**: "What can Supabase do?"
- **Competitive analysis**: "How do we compare to Mint?"

**Integration with Feature Strategist**:
```bash
# Generate research plan
python scripts/web_research_engine.py --competitor-analysis "mint,ynab" --output /tmp/plan.md

# AI agent executes plan with MCP tools
# Results feed into Feature Strategist

# Get prioritized suggestions based on competitor gaps
python scripts/feature_strategist.py --top 10 --research
```

**Data Formats Supported**:
- **Markdown**: Readable article content, documentation
- **JSON**: Structured API responses, data extraction
- **HTML**: Full page content for complex extraction
- **Images**: Screenshots for visual reference
- **Search Results**: WebSearch result blocks

**Best Practices**:
1. Start with competitor analysis to find feature gaps
2. Use trend analysis to validate feature value
3. Mine user reviews to understand pain points
4. Research tech docs before implementation
5. Feed results into Feature Strategist for prioritization

### 10. Reference Documentation (Immediate Context)

Five comprehensive reference documents are available for immediate loading:

#### `references/spec_kit_methodology.md`
Complete guide to specification-driven development methodology used in PayPlan.

**Contents**:
- Core artifacts (spec.md, plan.md, tasks.md, etc.)
- Required sections and structure
- Spec-kit workflow (/speckit.clarify → specify → plan → tasks → implement)
- Naming conventions (feature IDs, branches, requirements)
- Testing strategy (TDD, test levels, organization)
- Quality checklists

**When to load**: Planning new features, understanding artifact structure, validating spec-kit compliance

#### `references/payplan_architecture.md`
Comprehensive guide to PayPlan's architecture, design patterns, and technical stack.

**Contents**:
- Technology stack (React 19.1.1, TypeScript 5.8.3, etc.)
- Project structure (frontend/backend/specs organization)
- Core architectural patterns (privacy-first, two-tier storage, PII sanitization, etc.)
- Testing strategy (unit/integration/business tests)
- Performance considerations
- Accessibility (WCAG 2.1 AA)
- Security (PII protection, input validation)
- Key files quick reference

**When to load**: Understanding system architecture, implementing new features, making architectural decisions

#### `references/feature_conventions.md`
Coding standards, testing conventions, and best practices used throughout PayPlan.

**Contents**:
- Naming conventions (features, branches, commits, files)
- Code style guidelines (TypeScript, functions, components)
- Testing conventions (organization, naming, assertions, mocks)
- Error handling conventions (boundaries, logging, messages)
- Performance conventions (React optimization, localStorage)
- Accessibility conventions (ARIA, keyboard, semantic HTML)
- Documentation conventions (comments, function docs, READMEs)
- Git conventions (commit workflow, PR workflow)
- CLAUDE.md update patterns

**When to load**: Writing new code, reviewing code, setting up testing, debugging issues

#### `references/completed_features_index.md`
Quick reference guide to all completed PayPlan features (014-019).

**Contents**:
- Feature progression timeline
- Individual feature summaries with key technologies and patterns
- Feature dependency graph
- Common patterns across features
- Performance benchmarks
- Security milestones
- Quick lookup ("How do I...?" guide)

**When to load**: Planning new features, understanding feature relationships, finding implementation examples

#### `references/spec_kit_workflow_deep_dive.md` 🆕
**NEW**: Complete implementation guide to GitHub's Spec-Kit methodology for AI-assisted development.

**Contents**:
- **Core Philosophy**: Specification-driven development principles, why specs become executable
- **Workflow Stages**: Detailed walkthrough of constitution → specify → clarify → plan → tasks → implement
- **Slash Command Implementation**: How commands work, variable substitution, script integration
- **Constitutional Development**: Immutable principles, phase gates, compliance validation
- **Template Structure**: Spec, plan, and task templates with format requirements
- **Script Integration**: How bash/PowerShell scripts bridge AI instructions and file system
- **Quality Gates & Validation**: Specification quality, constitution compliance, checklist completeness

**Workflow Stage Details**:
- Stage 0: Constitution (optional foundation)
- Stage 1: Specify (natural language → formal spec)
- Stage 2: Clarify (resolve ambiguities before planning)
- Stage 3: Plan (generate design artifacts)
- Stage 4: Tasks (atomic, dependency-ordered breakdown)
- Stage 5: Implement (execute from tasks.md)

**When to load**:
- BEFORE creating new features (understand spec-kit workflow)
- When using `/speckit.*` slash commands
- Understanding how PayPlan's methodology compares to spec-kit
- Learning constitutional principles and quality gates
- Troubleshooting spec-kit workflow issues

## Typical Workflows

### Workflow 1: Planning a New Feature

**Goal**: Understand existing patterns before implementing a new feature

**Steps**:
1. **Discover related features**: Run `python scripts/analyze_feature_lineage.py --format markdown` to review completed features and dependencies
2. **Load architecture reference**: Read `references/payplan_architecture.md` to understand storage patterns, component patterns, testing patterns
3. **Find implementation examples**: Run `python scripts/find_code_patterns.py --category react` to discover how similar features are implemented
4. **Load conventions**: Read `references/feature_conventions.md` for naming standards, code style, testing approach
5. **Create spec following spec-kit methodology**: Read `references/spec_kit_methodology.md` to understand artifact structure

### Workflow 2: Understanding an Existing Feature

**Goal**: Deeply understand how a feature works and why decisions were made

**Steps**:
1. **Get feature overview**: Run `python scripts/analyze_feature_lineage.py --feature 019-pii-pattern-refinement` to understand dependencies, artifacts, and status
2. **Read feature spec**: Load `specs/019-pii-pattern-refinement/spec.md` to understand requirements
3. **Review git history**: Run `python scripts/search_git_history.py 019-pii-pattern-refinement --type feature` to see implementation timeline and related PRs
4. **Find related code patterns**: Run `python scripts/find_code_patterns.py --pattern pii_sanitizer` to discover where the feature is implemented
5. **Check quick reference**: Read `references/completed_features_index.md` section on Feature 019 for summary

### Workflow 3: Validating Spec Artifacts

**Goal**: Ensure spec artifacts are complete and consistent before implementation

**Steps**:
1. **Run validation**: `python scripts/validate_spec_artifacts.py specs/019-pii-pattern-refinement` to check for errors, warnings, and suggestions
2. **Review spec-kit methodology**: Read `references/spec_kit_methodology.md` to understand what's required
3. **Fix identified issues**: Add missing sections, ensure cross-references, add acceptance criteria
4. **Re-validate**: Run validation again to confirm all issues resolved

### Workflow 4: Finding Code Examples

**Goal**: Find examples of how to implement a specific pattern

**Steps**:
1. **Search by pattern type**: Run `python scripts/find_code_patterns.py --pattern custom_hooks` to get file locations and code context
2. **Search by category**: Run `python scripts/find_code_patterns.py --category testing` to see testing patterns across codebase
3. **Review conventions**: Read `references/feature_conventions.md` for best practices
4. **Check architecture patterns**: Read `references/payplan_architecture.md` for pattern explanations

## Best Practices for Using This Skill

### 1. Start with References for Quick Context

Before running scripts, check if the information is already in reference docs. References load instantly and provide comprehensive context.

### 2. Use Scripts for Dynamic Analysis

Use scripts when you need:
- Real-time codebase analysis (pattern discovery)
- Cross-artifact validation (spec consistency)
- Git history investigation (commit search)
- Feature relationship mapping (lineage analysis)

### 3. Combine Multiple Approaches

Most effective workflow:
1. Load relevant reference doc for context
2. Run analysis script for specific query
3. Synthesize findings and provide actionable guidance

### 4. Validate Before Implementation

Always validate spec artifacts before starting implementation:
```bash
python scripts/validate_spec_artifacts.py specs/[feature-id]
```

Catch missing requirements, incomplete tasks, or broken cross-references early.

### 5. Reference Feature IDs in All Output

When providing guidance, always reference:
- Feature IDs (e.g., "Feature 019 uses word boundary matching")
- File paths (e.g., "See `backend/src/lib/security/PiiSanitizer.js:45`")
- Requirement IDs (e.g., "This implements FR-001 from spec.md")

## Integration with Spec-Kit Workflow

This skill integrates seamlessly with PayPlan's spec-kit methodology:

- **During /speckit.clarify**: Load `spec_kit_methodology.md` and use `analyze_feature_lineage.py` to identify related features
- **During /speckit.specify**: Load `completed_features_index.md` for spec examples and use `find_code_patterns.py` for technical constraints
- **During /speckit.plan**: Load `payplan_architecture.md` for patterns and use `find_code_patterns.py` for implementation examples
- **During /speckit.tasks**: Load `spec_kit_methodology.md` for task patterns and reference completed features for granularity examples
- **Before implementation**: Run `validate_spec_artifacts.py` to check completeness
- **During /speckit.implement**: Use `find_code_patterns.py` for examples and load `feature_conventions.md` for code style
- **During /speckit.analyze**: Run `validate_spec_artifacts.py` and `analyze_feature_lineage.py` to verify consistency

## Quick Command Reference

### Original Capabilities
```bash
# Feature lineage
python scripts/analyze_feature_lineage.py --feature [ID]
python scripts/analyze_feature_lineage.py --format markdown > /tmp/report.md

# Code patterns
python scripts/find_code_patterns.py --pattern [pattern_name]
python scripts/find_code_patterns.py --category [testing|react|security]

# Spec validation
python scripts/validate_spec_artifacts.py specs/[feature-id]

# Git history
python scripts/search_git_history.py [feature-id] --type feature
python scripts/search_git_history.py [pattern] --type pattern
python scripts/search_git_history.py [file-path] --type file
```

### 🆕 Enhanced Capabilities
```bash
# Semantic code search
python scripts/semantic_code_search.py --intent "manipulate dates"
python scripts/semantic_code_search.py --anti-patterns
python scripts/semantic_code_search.py --related "file.ts:42"

# GitHub integration
python scripts/github_integration.py [feature-id]
python scripts/github_integration.py [feature-id] --prs-only
python scripts/github_integration.py --ci-status

# Spec-Kit AI assistant
python scripts/speckit_ai_assistant.py --generate-spec "id:name:description"
python scripts/speckit_ai_assistant.py --suggest-requirements "description"
python scripts/speckit_ai_assistant.py --estimate-complexity "description"
python scripts/speckit_ai_assistant.py --missing-artifacts [feature-id]

# Feature strategist
python scripts/feature_strategist.py --top 5
python scripts/feature_strategist.py --top 5 --research
python scripts/feature_strategist.py --top 5 --with-linear  # Include Linear issues
python scripts/feature_strategist.py --top 10 --research --with-linear --format markdown --output /tmp/suggestions.md
```

All scripts support `--format markdown|json` and `--output [file]` options.

---

## 🎯 Ultimate Edition Features

This enhanced skill goes **far beyond** basic documentation:

✅ **Semantic understanding** - Finds code by what it does, not just what it's named
✅ **GitHub integration** - PRs, issues, CI status, review comments
✅ **AI-powered suggestions** - Auto-generate specs, requirements, complexity estimates
✅ **Anti-pattern detection** - Catch code quality issues before they become problems
✅ **Data flow tracing** - See how variables transform through your code
✅ **Complexity prediction** - Estimate feature duration based on similar work
✅ **Next Feature Strategist** 🔥 - Intelligently suggests what to build next based on codebase, history, and trends

This skill transforms Claude Code into a **PayPlan domain expert** with comprehensive project context, predictive insights, strategic planning capabilities, and intelligent recommendations for what to build next.
