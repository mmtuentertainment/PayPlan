# PayPlan Research Assistant Skill

Comprehensive research and analysis tool for the PayPlan project.

## Installation

✅ **Already installed!** This skill is located at:
```
~/.claude/skills/payplan-research-assistant/
```

## Quick Start

This skill automatically triggers when you ask PayPlan-specific questions in Claude Code:

**Try these examples:**
- "How does PayPlan handle PII sanitization?"
- "What features depend on the archive system?"
- "Show me React hooks patterns in PayPlan"
- "Validate the spec artifacts for feature 019"
- "Find all commits related to performance optimization"

## What's Included

### Scripts (`scripts/`)
4 powerful Python analysis tools:
- `analyze_feature_lineage.py` - Feature dependencies and evolution
- `find_code_patterns.py` - Discover code patterns across codebase
- `validate_spec_artifacts.py` - Validate spec consistency
- `search_git_history.py` - Git history and PR analysis

### References (`references/`)
4 comprehensive documentation files:
- `spec_kit_methodology.md` - Spec-kit workflow guide
- `payplan_architecture.md` - Architecture and patterns
- `feature_conventions.md` - Coding standards
- `completed_features_index.md` - Features 014-019 reference

## Manual Script Usage

You can also run scripts directly:

```bash
# Feature lineage
python3 ~/.claude/skills/payplan-research-assistant/scripts/analyze_feature_lineage.py --feature 019-pii-pattern-refinement

# Code patterns
python3 ~/.claude/skills/payplan-research-assistant/scripts/find_code_patterns.py --pattern react_hooks

# Spec validation
python3 ~/.claude/skills/payplan-research-assistant/scripts/validate_spec_artifacts.py specs/019-pii-pattern-refinement

# Git history
python3 ~/.claude/skills/payplan-research-assistant/scripts/search_git_history.py 019-pii-pattern-refinement --type feature
```

All scripts support `--format markdown|json` and `--output [file]` options.

## Updating the Skill

As you complete new features, update these files:
- `references/completed_features_index.md` - Add new feature summaries
- `references/payplan_architecture.md` - Document new patterns
- `references/feature_conventions.md` - Add new conventions

Scripts automatically discover new features in `specs/` directory.

## Skill Location

- **Skill directory**: `~/.claude/skills/payplan-research-assistant/`
- **Backup zip**: `/tmp/payplan-research-assistant.zip`

## Support

See [SKILL.md](SKILL.md) for complete documentation on capabilities and workflows.

---

**Created**: 2025-10-25
**Version**: 1.0.0
**Size**: 36 KB (9 files)
