---
name: codebase-architect
description: Analyze and reorganize project file structures, identify dependencies, clean technical debt, and establish architectural patterns. Use when users need to: organize messy codebases, understand file dependencies and import chains, refactor folder hierarchies, identify unused files or circular dependencies, detect cross-file connections, or establish consistent naming conventions and module boundaries for any programming language project.
---

# Codebase Architect

This skill provides comprehensive project structure analysis and reorganization capabilities for codebases of any size and language.

## Core Capabilities

- **Dependency Analysis**: Map import chains and cross-file relationships
- **Structure Assessment**: Evaluate current organization against best practices
- **Dead Code Detection**: Identify unused files, exports, and orphaned code
- **Refactoring Planning**: Generate safe migration strategies
- **Pattern Recognition**: Detect and apply architectural patterns

## Quick Start

For immediate analysis of a project:

```bash
# Basic project analysis
python scripts/analyze_structure.py --root . --output analysis_report.json

# Generate dependency graph
python scripts/dependency_mapper.py --root src --format visual

# Detect dead code
python scripts/dead_code_detector.py --root . --exclude node_modules,dist
```

## Analysis Workflow

### Phase 1: Discovery

Start with comprehensive project analysis:

```bash
# Analyze project structure
python scripts/analyze_structure.py --root . --output analysis_report.json
```

<!-- Coming Soon: project_scanner.py for enhanced framework detection -->

This identifies:
- Framework/library conventions (React, Vue, Django, Rails, etc.)
- Build configuration files
- Test structure
- Documentation organization

### Phase 2: Dependency Mapping

Map all file relationships:

```bash
python scripts/dependency_mapper.py --root . --output deps.json --detect-circular
```

For specific language analysis:
- **JavaScript/TypeScript**: Analyzes imports, requires, dynamic imports
- **Python**: Tracks imports, relative imports, __init__ patterns
- **Java/C#**: Namespace and package dependencies
- **Go**: Module and package imports

### Phase 3: Problem Identification

Analyze dependencies and identify issues:

```bash
# Detect circular dependencies and orphaned files
python scripts/dependency_mapper.py --root . --output deps.json --detect-circular

# Find unused code
python scripts/dead_code_detector.py --root . --exclude node_modules,dist
```

<!-- Coming Soon: issue_detector.py for unified issue detection -->

Common issues detected:
- Circular dependencies
- Deep nesting (>4 levels)
- Inconsistent naming patterns
- Misplaced files (utilities in components, etc.)
- God files (too many responsibilities)
- Orphaned code (no imports/exports)

### Phase 4: Restructuring

Generate reorganization plan:

```bash
python scripts/restructure_planner.py --root . --pattern <pattern> --output migration_plan.json
```

Available patterns:
- **feature-based**: Group by features/domains
- **mvc**: Model-View-Controller separation
- **clean**: Clean Architecture layers
- **modular**: Self-contained modules
- **ddd**: Domain-Driven Design

## Architectural Patterns

### Feature-Based Structure

Best for: Frontend applications, microservices

```
src/
├── features/
│   ├── auth/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── services/
│   │   ├── types/
│   │   └── index.ts
│   └── dashboard/
│       ├── components/
│       ├── hooks/
│       ├── services/
│       └── index.ts
├── shared/
│   ├── components/
│   ├── utils/
│   └── types/
└── core/
    ├── api/
    ├── config/
    └── constants/
```

### Clean Architecture

Best for: Enterprise applications, complex domains

```
src/
├── domain/           # Business logic
│   ├── entities/
│   ├── repositories/
│   └── use-cases/
├── application/      # Application services
│   ├── services/
│   └── dto/
├── infrastructure/   # External concerns
│   ├── database/
│   ├── api/
│   └── config/
└── presentation/     # UI layer
    ├── controllers/
    └── views/
```

### Modular Monolith

Best for: Large applications, gradual microservices migration

```
src/
├── modules/
│   ├── user/
│   │   ├── api/
│   │   ├── domain/
│   │   ├── infrastructure/
│   │   └── module.ts
│   └── billing/
│       ├── api/
│       ├── domain/
│       └── module.ts
├── shared-kernel/
└── composition-root/
```

## Advanced Features

### Custom Rules Configuration

Create `.codebase-architect.json` in project root (see `assets/example-config.json` for full template):

```json
{
  "rules": {
    "maxNestingDepth": 4,
    "enforceBarrelExports": true,
    "namingConvention": "kebab-case",
    "forbiddenDependencies": [
      {"from": "domain/*", "to": "infrastructure/*"}
    ]
  }
}
```

### Migration Safety

<!-- Coming Soon: migrate.py for automated file reorganization -->

The `restructure_planner.py` script generates a detailed migration plan in JSON format. Review this plan carefully before executing manual file moves. Best practices:

- Use version control (git) before any restructuring
- Move files incrementally (one module at a time)
- Update imports immediately after each move
- Run tests frequently to catch breaks early
- Consider using IDE refactoring tools for import updates

### Language-Specific Features

For detailed language-specific analysis:
- **JavaScript/TypeScript**: See references/javascript-patterns.md
- **Python**: See references/python-patterns.md
<!-- Coming Soon: Additional language pattern guides -->
<!-- - **Java/Kotlin**: See references/jvm-patterns.md -->
<!-- - **Go**: See references/go-patterns.md -->
<!-- - **C#/.NET**: See references/dotnet-patterns.md -->

### Reporting

<!-- Coming Soon: report_generator.py for HTML/Markdown report generation -->

All analysis scripts output JSON format for further processing:

```bash
# Analyze structure and generate JSON report
python scripts/analyze_structure.py --root . --output analysis.json

# Map dependencies with detailed output
python scripts/dependency_mapper.py --root . --output deps.json

# Detect dead code with results
python scripts/dead_code_detector.py --root . --output dead_code.json
```

Parse these JSON files or pretty-print with `jq` for human-readable output.

## Best Practices

### Before Reorganizing

1. **Backup everything**: Use version control or create archive
2. **Run tests**: Ensure all tests pass before changes
3. **Document current state**: Generate architecture documentation
4. **Communicate changes**: Inform team members

### During Reorganization

1. **Incremental changes**: Move one module at a time
2. **Update imports immediately**: Use automated tools
3. **Run tests frequently**: Catch breaks early
4. **Maintain compatibility**: Keep old paths with deprecation warnings

### After Reorganization

1. **Update documentation**: README, architecture docs, onboarding
2. **Update CI/CD**: Build paths, test configurations
3. **Team training**: Share new structure and conventions
4. **Monitor for issues**: Watch for import errors, build failures

## Scripts Reference

Currently available scripts in `scripts/` directory:

- `analyze_structure.py`: Main analysis engine
- `dependency_mapper.py`: Creates dependency graphs
- `dead_code_detector.py`: Finds unused code
- `restructure_planner.py`: Generates migration plans

<!-- Coming Soon: Additional scripts -->
<!-- - `issue_detector.py`: Identifies structural problems -->
<!-- - `migrate.py`: Executes file reorganization -->
<!-- - `project_scanner.py`: Initial project discovery -->
<!-- - `report_generator.py`: Creates analysis reports -->

Run any script with `--help` for detailed options.

## Troubleshooting

### Common Issues

**Large codebases (>10k files)**: Use `--sample` flag for initial analysis
**Binary files causing errors**: Add to `--exclude` patterns
**Permission errors**: Check file permissions or run with appropriate access
**Memory issues**: Use `--stream` mode for large projects

For additional patterns and detailed examples, see references/patterns-catalog.md